/*
 * flash.h
 *
 *  Created on: March 28th, 2011
 */
/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef FLASH_H_
#define FLASH_H_

void FLASH_EraseMemory(unsigned long address);

void FLASH_WriteMemory(unsigned long addr, unsigned char *data, unsigned char length);
void FLASH_ReadMemory (unsigned long addr, unsigned char *data);


#endif /* FLASH_H_ */
