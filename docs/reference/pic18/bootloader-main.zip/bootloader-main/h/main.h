/*********************************************************
*file name: main.h
*********************************************************/

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef MAIN_H_
#define MAIN_H_


#define APP_CODE_START_ADDRESS  0x3700UL
#define APP_CODE_END_ADDRESS	0xFFFFUL //pic18F46k22 


#define BAUD_RATE_RS485_DSPL   	9600		//19200 //  only 9600 and 19200 work

//digital inputs
#define Oil_Pressure		PORTBbits.RB5
#define Truck_Engine_State	PORTBbits.RB1

#define Engine_RPM			PORTCbits.RC1

//write to the pins
#define EVAPERATOR_PWM_ON()		(LATCbits.LATC2 = 1)  	//
#define EVAPERATOR_PWM_OFF()	(LATCbits.LATC2 = 0)  	//logic was reversed on the output drive circuit

#define SPARE_OUT_ON()			(LATBbits.LATB3 = 1)
#define SPARE_OUT_OFF()			(LATBbits.LATB3 = 0)
#define CONDENSOR_PWM_ON()		(LATDbits.LATD1 = 1)
#define CONDENSOR_PWM_OFF()		(LATDbits.LATD1 = 0)

#define FUEL_PUMP_ON()			(LATDbits.LATD0 = 1)  	//Rev 1.
#define FUEL_PUMP_OFF()			(LATDbits.LATD0 = 0)
#define	STARTER_ON()			(LATDbits.LATD2 = 1)  	//Rev 1.
#define	STARTER_OFF()			(LATDbits.LATD2 = 0)
#define COMPRESSOR_CLUTCH_ON()	(LATDbits.LATD3 = 1)	//Rev 1.
#define COMPRESSOR_CLUTCH_OFF()	(LATDbits.LATD3 = 0)
#define HEAT_MODE_ON()			(LATDbits.LATD4 = 1)	//Rev 1.
#define HEAT_MODE_OFF()			(LATDbits.LATD4 = 0)
#define GLOW_PLUG_ON()			(LATDbits.LATD5 = 1)	//Rev 1.
#define GLOW_PLUG_OFF()			(LATDbits.LATD5 = 0)
#define EVAPERATOR_FAN_ON()		(LATCbits.LATC3 = 1)	//Rev 1.
#define EVAPERATOR_FAN_OFF()	(LATCbits.LATC3 = 0)
#define COOL_MODE_ON()			(LATCbits.LATC4 = 1)	//Rev 1.
#define COOL_MODE_OFF()			(LATCbits.LATC4 = 0)



#define XMIT_485()			(LATCbits.LATC5 = 1)
#define RCV_485()			(LATCbits.LATC5 = 0)

#define COMPRESSOR_STATE  	PORTDbits.RD3
#define COOL_MODE_STATE		PORTCbits.RC4
#define HEAT_MODE_STATE  	PORTDbits.RD4
#define EVAP_FAN_STATE		PORTCbits.RC3
#define FUEL_PUMP_STATE		PORTDbits.RD0
#define GLOW_PLUG_STATE     PORTDbits.RD5
#define STARTER_STATE		PORTDbits.RD2


/************************************************************************************
*   Global Peripheral Declarations
*************************************************************************************/
//-----------------------------------------------------------------------------------
// Timer and counter defines														
//-----------------------------------------------------------------------------------

#define DIVIDE_FOR_100MS				99			// The number of 1ms timer interrupts per 100 ms

enum one_ms_timer_list
{
	FIRST=0,
	NUM_ONE_MS_TIMER
};
	
extern UINT16 one_ms_timer[NUM_ONE_MS_TIMER];

/************************************************************************************
*	Switch processing routines
*	The following code implements switch objects which abstracts processing and
*	debouncing algorithms for switches.
*
*************************************************************************************/

#define	ON	1
#define	OFF	0
#define CONTROL_OFF 0

enum operation_mode_state_list
{
	OFF_MODE = 0,
	CLIMATE_CONTROL_MODE,
	BATTERY_MONITOR_MODE,
	COLD_STORAGE_MODE
};

enum error_message_state_list
{
	NO_OP_ERROR = 0,
	STANDBY						//screen 22 -- key_switch interrupt	
};

/******************************************************************************
 *   Application Specific Globals
 ******************************************************************************/

//extern uint8_t eeprom_timer;

//State machine enums
enum machine_state_list
{
	STATE_INIT,				// 0
	STATE_WAIT_DATA,		// 1
	STATE_BOOTLOADING,		// 2
	STATE_ERROR,			// 3
	STATE_DONE,				// 4
	STATE_TEST_DONE			// 5
};

/************************************************************************************
*   Function prototypes
*************************************************************************************/
void InitializeSystem(void);
void UpdateOutputs(void);
void interrupt low_priority All_Boot_IRS(void);

void State_Machine(void);

uint8_t Boot_Init_Menu(void);
uint8_t BootLoading_Menu(void);
uint8_t Error_Menu(void);
uint8_t Done_Menu(void);


#endif /*MAIN_H_*/
