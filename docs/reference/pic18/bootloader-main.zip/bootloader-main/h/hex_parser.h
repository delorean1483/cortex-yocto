/*
 * hex_parser.h
 *
 *  Created on: Mar 30, 2009
 */

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef HEX_PARSER_H_
#define HEX_PARSER_H_

#include <types.h>

typedef enum {
	HEX_PARSER_ERROR_NONE = 0,
	HEX_PARSER_ERROR_FILE_ERROR = 1

} HEX_PARSER_ERROR_t;

typedef enum {

	HEX_PARSER_STATE_COLON,
	HEX_PARSER_STATE_LENGTH_1,
	HEX_PARSER_STATE_LENGTH_0,
	HEX_PARSER_STATE_ADDR_3,
	HEX_PARSER_STATE_ADDR_2,
	HEX_PARSER_STATE_ADDR_1,
	HEX_PARSER_STATE_ADDR_0,
	HEX_PARSER_STATE_TYPE_1,
	HEX_PARSER_STATE_TYPE_0,
	HEX_PARSER_STATE_DATA_0,
	HEX_PARSER_STATE_DATA_1,
	HEX_PARSER_STATE_CRC_1,
	HEX_PARSER_STATE_CRC_0,
	HEX_PARSER_STATE_DONE,
	HEX_PARSER_STATE_RESTART,
	HEX_PARSER_STATE_ERROR

} HEX_PARSER_STATE_t;

typedef struct {

	uint8_t		lengthASCI[2];
	uint8_t		length;
	uint8_t		addressASCI[4];
	uint32_t	address;
	uint8_t		typeASCI[2];
	uint8_t		type;
	uint8_t		data[64];
	uint8_t		crcASCI[2];
	uint8_t		crc;
	HEX_PARSER_STATE_t	state;
	uint8_t 	dataIndex;
	uint16_t	block;
	uint32_t	currentHexSegmentAddress;
	uint32_t	extendedAddress;

} HEX_PARSER_t;

extern HEX_PARSER_t HEX_PARSER;

HEX_PARSER_ERROR_t HEX_PARSER_IntelHexToFlash(HEX_PARSER_t * pThis, uint8_t *buf, uint8_t len, uint16_t currentBlock);
uint8_t HEX_PARSER_AsciiToHex(uint8_t asciiHex);
uint8_t HEX_PARSER_GetChecksum8(HEX_PARSER_t * pThis);
uint8_t HEX_PARSER_IsValidMemory(uint32_t addressStart, uint32_t length);

#endif /* HEX_PARSER_H_ */
