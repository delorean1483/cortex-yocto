/**
 * parameters.h
 *  Created on: Mar 30, 2010
 */

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef PARAMETERS_H_
#define PARAMETERS_H_


UINT16 get_cabin_temperature(void);

UINT16 get_battery_voltage(void);
UINT16 get_op_mode_bttn_value(void);
UINT16 get_engine_run_time(void);

UINT16 get_engine_oil_time(void);
UINT8  set_engine_oil_time(UINT16 value);

UINT16 get_machine_run_time(void);

UINT8  set_error_state(UINT16 value);
UINT16 get_error_state(void);

UINT8  set_oil_state(UINT16 value);

UINT16 get_truck_engine_state(void);
UINT16 get_engine_rpm_portstate(void);


UINT8 set_op_mode_bttn_value(UINT16 value);

UINT16  get_oil_state(void);


UINT16 get_engine_status(void);
UINT16 get_control_status(void);

UINT16 get_temperature_dspl_state(void);

UINT16 get_ready_boot_state(void);
UINT8 set_ready_boot_state(UINT16 value);

typedef enum {
	//The hardware level registers will start at 1 and end at 100
	HR_DSPL_CABIN_TEMP			= 1,	// Temperature for display
	HR_DSPL_ENGINE_TEMP			= 2,
	HR_DSPL_EXTERNAL_TEMP		= 3,
	HR_DSPL_LSIDE_PRESSURE		= 4,
	HR_DSPL_HSIDE_PRESSURE		= 5,
	HR_DSPL_BATT_VOLTAGE		= 6,

	HR_OIL_PRESSURE_STATE		= 7,	//ok/nok
	HR_TRUCK_ENGINE_STATE		= 8,	//on/off. APU stands by if truck engine is on 
	HR_ENGINE_RPM_PORTSTATE		= 9,
	HR_DSPL_OP_MODE				= 10,
	HR_DSPL_ENGINE_RUN_TIMER	= 11,  //fuel pump on timer
	HR_EVAP_FAN_SPEED_SETTING	= 12,	//high/low
	HR_DSPL_BATT_SETTING		= 13,	//battery monitor mode
	HR_DSPL_TEMP_SETTING		= 14,	//climate control mode
	HR_STORAGE_T_SETTING        = 15,   //store_t_setting.word  cold storage mode
    HR_STORAGE_V_SETTING        = 16,   //store_v_setting.word	cold storage mode
	HR_DSPL_OP_ERROR_STATE		= 17,	//to trig the error screens
	HR_DSPL_OIL_CHANGE_STATE	= 18,	//to switch to 3 different warning screens
	HR_DSPL_TEMP_UNIT			= 19,	//F/C
	
	HR_DSPL_ENGINE_OIL_TIMER	= 20, 	//engine oil timer
	HR_DSPL_MACHINE_RUN_TIMER	= 21, 	//machine run timer, also called APU timer

	HR_DSPL_ENGINE_STATUS		= 22,   //RUNNING/OFF
	HR_DSPL_CLIMATE_STATUS		= 23,	//climate control mode status	

 	HR_DSPL_CLND_STATE			= 24,		
	HR_DSPL_CLND_MODE			= 25,		
 	HR_DSPL_CLND_START_YEAR		= 26,
	HR_DSPL_CLND_START_MONTH	= 27,
 	HR_DSPL_CLND_START_DATE		= 28,
 	HR_DSPL_CLND_START_HOUR		= 29,
 	HR_DSPL_CLND_START_MIN		= 30,
	HR_DSPL_CLND_START_AMPM		= 31,

	HR_STANDBY_OVERRIDE_FLAG	= 32,

	HR_TEMP_DSPLY_STATE			= 33,

	HR_RELAY_RESET_MICRO        = 34,

    HR_RELAY_READY_BOOT         = 35,

	HR_CAL_VREF					= 36,
	HR_CAL_TEMPERATURE			= 37,
	
	MAX_HOLDING_REG_PARAMETER_DISP
}mb_holding_reg_disp_t;


#endif /* PARAMETERS_H_ */


