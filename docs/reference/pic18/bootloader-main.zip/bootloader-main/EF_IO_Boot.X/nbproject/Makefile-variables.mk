#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=EF_IO_Boot.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/EF_IO_Boot.X.production.hex
