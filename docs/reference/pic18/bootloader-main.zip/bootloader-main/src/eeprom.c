/*
 * eeprom.c
 */

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/
#include "include_all.h"


void write_eeprom_byte(unsigned int address,  char data)
{
    EEDATA = data;
	EEADRH = (address >> 8) & 0x03;
	EEADR = (address & 0x0ff);
    
    // start write sequence as described in datasheet, page 91
    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.WREN = 1; // enable writes to data EEPROM
    INTCONbits.GIE = 0;  // disable interrupts
    EECON2 = 0x55;
    EECON2 = 0x0AA;
    EECON1bits.WR = 1;   // start writing
    while(EECON1bits.WR)
    {Nop();}
          
    EECON1bits.WREN = 0;
    INTCONbits.GIE = 1;  // enable interrupts
}

unsigned char read_eeprom_byte(unsigned int address)
{  
	EEADRH = (address >> 8) & 0x03;
    EEADR = (address & 0x0ff);
    EECON1bits.CFGS = 0;
    EECON1bits.EEPGD = 0;
    EECON1bits.RD = 1;
    return EEDATA;
}


