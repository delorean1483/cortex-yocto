/*
 * hex_parser.c
 *
 *  Created on: Mar 30, 2009
 */
/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/
#include <include_all.h>

HEX_PARSER_t HEX_PARSER;

/*******************************************************************************
 * This function receives an ASCII intel hex file in blocks.  It converts
 * the ASCII to hex and memory addresses.  It writes those values to memory
 * as memory write buffers are filled. Send a block number 0 to start or reset
 * the internal state machine.
 *
 * Example hex format:
 *
 * Intel hex format :llaaaatt[dd....]cc
 *	tt - type = 00 - data record
 *				01 - end of file
 *				02 - extended segmaent address
 *				04 - extended linear address
 *
 ********************************************************************************/

HEX_PARSER_ERROR_t HEX_PARSER_IntelHexToFlash(HEX_PARSER_t * pThis, uint8_t *buf, uint8_t len, uint16_t currentBlock) {

	uint8_t index = 0;
	uint8_t error = HEX_PARSER_ERROR_NONE;

	// this block of code will revert the state machine in case of error
	if(currentBlock == pThis->block && currentBlock != 0) { // then we had an error becuase we are getting a block we already parsed

		error = HEX_PARSER_ERROR_NONE; // already started this block so retry maybe there was an error.

	} else if (currentBlock == pThis->block + 1) {

		pThis->block = currentBlock;


	} else if (currentBlock == 0) {

		memset(pThis,0,sizeof(HEX_PARSER_t));
		pThis->state = HEX_PARSER_STATE_COLON;


	} else {
		//state machine is corrupt!!!!!! because we got a block out of range
		error = HEX_PARSER_ERROR_FILE_ERROR;
		len = 0;

	}

	while(index < len && error == HEX_PARSER_ERROR_NONE) {

		switch(pThis->state) {

			case HEX_PARSER_STATE_COLON:

				if(buf[index++] == ':') {

					uint32_t currentHexSegmentAddress = pThis->currentHexSegmentAddress;
					uint32_t extendedAddress = pThis->extendedAddress;

					memset(pThis,0,sizeof(HEX_PARSER_t));

					pThis->currentHexSegmentAddress = currentHexSegmentAddress;
					pThis->extendedAddress = extendedAddress;
					pThis->state = HEX_PARSER_STATE_LENGTH_1;
					pThis->block = currentBlock;

				}

			break;

			case HEX_PARSER_STATE_LENGTH_1:

				pThis->lengthASCI[1] = buf[index++];
				pThis->state = HEX_PARSER_STATE_LENGTH_0;

			break;

			case HEX_PARSER_STATE_LENGTH_0:

				pThis->lengthASCI[0] = buf[index++];
				//convert asci to hex...

				pThis->length  = HEX_PARSER_AsciiToHex(pThis->lengthASCI[0]);
				pThis->length |= HEX_PARSER_AsciiToHex(pThis->lengthASCI[1]) << 4;

				pThis->state = HEX_PARSER_STATE_ADDR_3;

			break;

			case HEX_PARSER_STATE_ADDR_3:

				pThis->addressASCI[3] = buf[index++];

				pThis->state = HEX_PARSER_STATE_ADDR_2;

			break;

			case HEX_PARSER_STATE_ADDR_2:

				pThis->addressASCI[2] = buf[index++];

				pThis->state = HEX_PARSER_STATE_ADDR_1;

			break;

			case HEX_PARSER_STATE_ADDR_1:

				pThis->addressASCI[1] = buf[index++];

				pThis->state = HEX_PARSER_STATE_ADDR_0;

			break;

			case HEX_PARSER_STATE_ADDR_0:

				pThis->addressASCI[0] = buf[index++];

				pThis->address  =  (uint32_t)HEX_PARSER_AsciiToHex(pThis->addressASCI[0]);
				pThis->address |= ((uint32_t)HEX_PARSER_AsciiToHex(pThis->addressASCI[1]) << 4)  & 0x000000F0;
				pThis->address |= ((uint32_t)HEX_PARSER_AsciiToHex(pThis->addressASCI[2]) << 8)  & 0x00000F00;
				pThis->address |= ((uint32_t)HEX_PARSER_AsciiToHex(pThis->addressASCI[3]) << 12) & 0x0000F000;

				pThis->state = HEX_PARSER_STATE_TYPE_1;

			break;

			case HEX_PARSER_STATE_TYPE_1:

				pThis->typeASCI[1] = buf[index++];

				pThis->state = HEX_PARSER_STATE_TYPE_0;

			break;

			case HEX_PARSER_STATE_TYPE_0:

				pThis->typeASCI[0] = buf[index++];
				//convert asci to hex...

				pThis->type  = HEX_PARSER_AsciiToHex(pThis->typeASCI[0]);
				pThis->type |= HEX_PARSER_AsciiToHex(pThis->typeASCI[1]) << 4;

				if(pThis->type == 0x01) {
//					int a = 0; //debug trap
				}

				if(pThis->length == 0) {

					pThis->state = HEX_PARSER_STATE_CRC_1;
					break;

				}

				pThis->state = HEX_PARSER_STATE_DATA_1;

			break;

			case HEX_PARSER_STATE_DATA_1:

				pThis->data[pThis->dataIndex] = HEX_PARSER_AsciiToHex(buf[index++]) << 4;
				pThis->state = HEX_PARSER_STATE_DATA_0;


			break;

			case HEX_PARSER_STATE_DATA_0:

				pThis->data[pThis->dataIndex++] |= HEX_PARSER_AsciiToHex(buf[index++]);

				if(pThis->length == pThis->dataIndex) {

					pThis->state = HEX_PARSER_STATE_CRC_1;

				} else {
					pThis->state = HEX_PARSER_STATE_DATA_1;

				}

			break;

			case HEX_PARSER_STATE_CRC_1:

				pThis->crcASCI[1] = buf[index++];

				pThis->state = HEX_PARSER_STATE_CRC_0;

			break;

			case HEX_PARSER_STATE_CRC_0:

				pThis->crcASCI[0] = buf[index++];

				// convert crc asci to hex

				pThis->crc  = HEX_PARSER_AsciiToHex(pThis->crcASCI[0]);
				pThis->crc |= HEX_PARSER_AsciiToHex(pThis->crcASCI[1]) << 4;

				//calcualte crc and compare

				if(HEX_PARSER_GetChecksum8(pThis) == 0) {

					pThis->state = HEX_PARSER_STATE_DONE;

				} else {

					pThis->state = HEX_PARSER_STATE_RESTART;
					error = HEX_PARSER_ERROR_FILE_ERROR;
				}

			break;

			case HEX_PARSER_STATE_DONE:

				if(pThis->type == 0x00) { // type 00 then write data to page buffer

					if(pThis->currentHexSegmentAddress != 0) {
						pThis->address = pThis->address + (pThis->currentHexSegmentAddress<<4);

					} else if (pThis->extendedAddress != 0) {
						pThis->address = pThis->address + pThis->extendedAddress;

					}

					if(HEX_PARSER_IsValidMemory(pThis->address, pThis->length)) {
						FLASH_WriteMemory(pThis->address, pThis->data, pThis->dataIndex);
					}

					pThis->state = HEX_PARSER_STATE_RESTART;

				} else if(pThis->type == 0x01) { // end of file type

					if(pThis->length > 0) {
						if(HEX_PARSER_IsValidMemory(pThis->address, pThis->length)) {
							FLASH_WriteMemory(pThis->address, pThis->data, pThis->dataIndex);
						}
					}

					pThis->state = HEX_PARSER_STATE_RESTART;

				} else if(pThis->type == 0x02) { // ex segment

					//test this
					if(pThis->length == 2){
						pThis->currentHexSegmentAddress = pThis->data[0];
						pThis->currentHexSegmentAddress <<= 8;

						pThis->currentHexSegmentAddress |= pThis->data[1];

						pThis->extendedAddress = 0;

					} else {
						error = HEX_PARSER_ERROR_FILE_ERROR;
					}

					pThis->state = HEX_PARSER_STATE_RESTART;


				} else if(pThis->type == 0x04) { //  ex linear

					//test this
					if(pThis->length == 2){

						pThis->extendedAddress = pThis->data[0];
						pThis->extendedAddress <<= 8;

						pThis->extendedAddress |= pThis->data[1];
						pThis->extendedAddress = pThis->extendedAddress<<16;

						pThis->currentHexSegmentAddress = 0;

						pThis->state = HEX_PARSER_STATE_RESTART;

					} else {
						error = HEX_PARSER_ERROR_FILE_ERROR;
					}

				} else {

					pThis->state = HEX_PARSER_STATE_RESTART;
					error = HEX_PARSER_ERROR_FILE_ERROR;

				}

				//Reset the index for the data
				pThis->dataIndex = 0;

			break;

			case HEX_PARSER_STATE_RESTART:

				// restart
				pThis->state = HEX_PARSER_STATE_COLON;

			break;

			case HEX_PARSER_STATE_ERROR:

				error = HEX_PARSER_ERROR_FILE_ERROR;

			break;

			default:
				// restart
				pThis->state = HEX_PARSER_STATE_COLON;

			break;
		}
	}

	return error;
}

/**************************************************************************
* Function HEX_PARSER_IsValidMemory()
* Inputs: start address, byte count
* Output: 1-valid, 0-invalid
* Notes: 
* Either memory size or memory address could be used to validate the memory. 
* 1.(addressStart+length) is the size of the memory occupied. while 
*    APP_CODE_END_ADDRESS represents the maximum valid address of the memory.
* 2. Validate addresses: 
*    If we take (addressStart+length) as an address,it is the first address 
*    for next block.so we have:
*    (addressStart+length-1) is the last address of size(addressStart+length)
*    (APP_CODE_END_ADDRESS) is the maximum valid address  
* 3. Validate memory size:
*    (addressStart+length) is the size of the memory would be occupied.
*    (APP_CODE_END_ADDRESS+1) is the maximum size of available memory.
 
*****************************************************************************************/
uint8_t HEX_PARSER_IsValidMemory(uint32_t addressStart, uint32_t length) {

	if(addressStart < APP_CODE_START_ADDRESS) 
	{
		return 0;
	} 
	else if((addressStart + length)>(APP_CODE_END_ADDRESS+1)) //10/16/2015
	{  
		return 0;
	}

	return 1;
}

uint8_t HEX_PARSER_AsciiToHex(uint8_t asciiHex) {

	uint8_t hex = 0;

	if(asciiHex <= 0x39) {
		hex = asciiHex - 0x30;
	} else {
		hex = (asciiHex & 0x0F) + 0x09;
	}

	return hex;

}

uint8_t HEX_PARSER_GetChecksum8(HEX_PARSER_t * pThis)
{

	uint16_t temp = 0;
	uint8_t sum = 0;
	uint8_t i = 0;

	sum += pThis->length;

	temp = pThis->address & 0x00ff;
	sum += (uint8_t)temp;

	temp = (pThis->address >> 8) & 0x00ff;
	sum += (uint8_t)temp;

	sum += pThis->type;

	for(;i < pThis->length;i++) {
		sum += pThis->data[i];
	}

	sum += pThis->crc;

	return sum;

}
