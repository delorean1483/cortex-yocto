/***********************************************************************************
* File: main.c
* Description: Bootloader Source code of IO micro on Parks Industries display4.3
* Microcontroller: Microchip PIC18F46K22
* ToolSet: Microchip xc8 v1.10
* Author: Jintao Huang
*******************************************************************************/

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

/*******************************************************************************
* operation notice:
* 1. define modbus baudrate in main.h: 
*	 BAUD_RATE_RS485_DSPL
* 2. define application memory range in main.h and main.c
*	 APP_CODE_START_ADDRESS (main.h)
*	 APP_CODE_END_ADDRESS	(main.h)
*	 PROG_START   (main.c)
* 3. Project-> build options->Global 
* 	 Rom ranges: default,-0x3700-0xFFFF
* 4. ICD 3 setting: allow ICD 3 to select memories and ranges. 
*					preserve prgram memory range 0x3700 to FFFF
* 5. output hex file 80010902 = bootloader + application

***********************************************************************************/

/** C O N F I G U R A T I O N   B I T S **************************************/
//TO SEE WHAT THESE SETTINGS SHOULD BE GO TO:
//HELP->TOPICS->PIC18 CONFIG SETTINGS, THEN SELECT THE CORRECT PART AND
//YOU WILL BE ABLE TO SEE THE LIST OF ALL THE SETTING FOR THE SPECIFC PART :)
//PLLCFG=OFF -> oscillator used directly 
#pragma config FOSC = HSMP, PLLCFG = ON, PRICLKEN = ON, FCMEN = OFF, IESO = OFF // CONFIG1H 
#pragma config PWRTEN = ON, BOREN = NOSLP, BORV = 190                       	// CONFIG2L 
#pragma config WDTEN = ON, WDTPS = 32768                                    	// CONFIG2H
#pragma config /*MCLRE = ON, LPT1OSC = OFF,*/ PBADEN = OFF, CCP2MX = PORTC1		// CONFIG3H
#pragma config STVREN = ON, LVP = OFF, XINST = OFF, DEBUG = OFF            	 	// CONFIG4L
#pragma config CP0 = OFF, CP1 = OFF, CP2 = OFF, CP3 = OFF                   	// CONFIG5L
#pragma config CPB = OFF, CPD = OFF                                         	// CONFIG5H
#pragma config WRT0 = OFF, WRT1 = OFF, WRT2 = OFF, WRT3 = OFF              		// CONFIG6L
#pragma config WRTB = OFF, WRTC = OFF, WRTD = OFF                           	// CONFIG6H
#pragma config EBTR0 = OFF, EBTR1 = OFF, EBTR2 = OFF, EBTR3 = OFF           	// CONFIG7L
#pragma config EBTRB = OFF                                                  	// CONFIG7H

/** I N C L U D E S **********************************************************/

#include "include_all.h"

/******************************************************************************
*	Global Variable Definitions
******************************************************************************/
//#define DEBUG_BOOTLOADER

UINT16 divide_for_100ms;
UINT16 one_ms_timer[NUM_ONE_MS_TIMER];

UINT16 engine_run_timer=0;
UINT16 engine_oil_timer=0;
UINT16 machine_run_timer=0;

BYTE state=0;
BYTE error_state=0;
BYTE oil_state=0;  // OIL_CHANGE_SOON, OIL_CHANGE_NEEDED, OIL_CHANGE_PAST_DUE  needs to add code

BYTE engine_op_status = 0;
BYTE control_status = 0;
BYTE temp_dspl_state = 0;

BYTE mode_bttn_state=0;
BYTE mode_bttn_state_ck = 0;

BYTE i;

uint8_t machine_state = 0;
int8_t error_handle = 0;

/**************************************************************
 * Buffer for bulk file read of firmware
 * data was received one block of 64 bytes once at a time.
***************************************************************/
uint8_t buffer[100]; 
uint8_t block_length;
uint16_t block_number;  //debug only
BYTE slv_ready_receive;
BYTE data_ready_parser_flag;

/******************************************************************************
*	Function Prototypes
******************************************************************************/

/** V E C T O R  R E M A P P I N G *******************************************/
//On PIC18 devices, addresses 0x00, 0x08, and 0x18 are used for
//the reset, high priority interrupt, and low priority interrupt
//vectors.  However, the bootloader will occupy these addresses 
//therefore, the bootloader code remaps these vectors to new locations
//as indicated below.

/****** Remapped Vectors ********************
       _____________________
       |       RESET       |   0x000000
       |      LOW_INT      |   0x000008
       |      HIGH_INT     |   0x000018
       |       TRAP        |   0x000028
       |     Bootloader    |   0x00002E
       .                   .
       .                   .
       |     USER_RESET    |   0x003700
       |    USER_LOW_INT   |   0x003708
       |    USER_HIGH_INT  |   0x003718
       |      USER_TRAP    |   0x003728
       |                   |
       |   Program Memory  |
       .                   .
       |___________________|   0x000FFFF
**********************************************/

/*******************************************************************
* JTH:PIC18F has two interrupt vectors. To make things simple
* (that might be the only working way)
* The bootloader uses the low-priority interrupt and 
* redirects the high_priority interrupt to the application.
* The application uses the high_priority interrupt and 
* defines an empty low_priority interrupt.
********************************************************************/
#ifdef DEBUG_BOOTLOADER

#define PROG_START 0x00
#asm
PSECT intcode
		goto PROG_START+0x08
#endasm

#else

#define PROG_START 0x3700
#asm
PSECT intcode
		goto PROG_START+0x08
#endasm

#endif



void main(void)
{

#ifndef DEBUG_BOOTLOADER
    if(read_eeprom_byte(EE_BOOTLOADER_FLAG) != 0xA5)
    {		
		/* transfer control to the application */
		asm("GOTO " ___mkstr(PROG_START));
    }
#endif
	CLRWDT();
	InitializeSystem();
	UpdateOutputs();
	
	slv_ready_receive = 0;  //slave is not ready to receive data yet
	machine_state = STATE_INIT;  //for State_Machine()

	while(1)
	{
		CLRWDT();			
		MB_Display_ProcessModbus((MODBUS_SERVER_t*) &MB_SERVER_DISPLAY);

		State_Machine();
//		UpdateOutputs();
			
	}
}//end of main()


void InitializeSystem(void)
{
	//Set the oscillator
	OSCCONbits.SCS = 0;	//Set to primary clock,determined by CONFIG1H

	//Configure the TRIS: 1 for input, 0 for output
	PORTA = 0x00;	//clearing output
	LATA = 0x00;	// clear output data latches
	ANSELA = 0x2F;	//setting RA5,RA<3:0> as analog. 1-analog, 0-digital
	TRISA = 0xFF;	//set all pins as inputs

	PORTB = 0x00;	//clearing output data latches
	LATB = 0x00;	//same as the one before-alternate
	ANSELB = 0x00;	//all pins as digital I/O
	TRISB = 0xF7;	//RB3 is output. The rests are input
	
	PORTC = 0x00;	//clearing output
	TRISC = 0xC3;	//RC0-open,digital-I, RC1,Input,RC2-5 digital-O. RC6-7,TX1/RX1,
					//RC2 is CCP1-Evap PWM output
	ANSELC = 0x00;	//all pins are digital
	
	PORTD = 0x00;	//clearing output
	TRISD = 0xC0;	//RD<0,5> - digital output,RD6-7 TX2/RX2
	ANSELD = 0x00;	//all are digital pins

	PORTE = 0x00;	//clearing output
	TRISE = 0x0F;	//RE<0,3> input
	ANSELE = 0x07;  // RE<0,2>analog input

	/*ADC initializtion*/
	//ADCON1 = 0x00;        //vref-=Vss, Vref+ = Vdd,
	ADCON1 = 0x04;   //0b00000100 vref-=Vss,Vref+=external pin
	ADCON2 = 0xBE;        //right justified, 20Tad, Fosc/64


    //Timer1 initializtion -- 1ms general timer
    //T1CON = 0b00110011;	//Fosc=8M,timer1 is always counting,11-1:8 prescale,internal Fosc/4,enable timer1.   
    T1CONbits.T1RD16 = 1;  	//enable 16bit mode
	T1CONbits.T1CKPS1 = 1;	//Prescale = 1:8
    T1CONbits.T1CKPS0 = 1;
	T1CONbits.TMR1CS1 = 0;	//Use the instruction clock (FOSC/4)
    T1CONbits.TMR1CS0 = 0;
    T1CONbits.TMR1ON =  1;  //TMR1 on       
    
	  //if FOSC=4x8M=32M. 0xD8F0+9999 = 0xFFFF; 10ms
	  //if Fosc=4x8M=32M, 0xFC18+999 = 0xFFFF; 1ms

	TMR1H = 0xFC;  //Fosc = 32MHZ, 0xFC18+999 = 0xFFFF, 1ms
	TMR1L = 0x18; 
    IPR1bits.TMR1IP = 0;  	//TMR1 low priority     
    PIE1bits.TMR1IE = 1;  	//enable timer1 overflow interrupt of PIE1 ;

	MB_Display_InitializeModbus((MODBUS_SERVER_t*) &MB_SERVER_DISPLAY,0x01);

	RCONbits.IPEN = 0x01;   //Enable priority levels on interrupts
	INTCONbits.GIEH = 1;    //Enable high priority interrupts
	INTCONbits.GIEL = 1;    //Enable low priority interrupts

	//assign modbus requested variables fixed value
	mode_bttn_state = OFF_MODE;
	error_state = NO_OP_ERROR;
	engine_op_status = CONTROL_OFF;
 	control_status = CONTROL_OFF;
}

//called in while loop.
void UpdateOutputs(void)
{	
	EVAPERATOR_FAN_OFF();
	EVAPERATOR_PWM_OFF();	
	FUEL_PUMP_OFF();				 
	STARTER_OFF();			
	COMPRESSOR_CLUTCH_OFF();
	GLOW_PLUG_OFF();				 
	HEAT_MODE_OFF();				
	COOL_MODE_OFF();		
	SPARE_OUT_OFF();

	CONDENSOR_PWM_OFF(); //-not use on Rev1				
}



//Function to handle the menu state machine
void State_Machine(void)
{
	switch(machine_state) {

	case STATE_INIT:
		machine_state = Boot_Init_Menu();//go to SATE_WAIT_DATA
		//set flag here, so master can start to send 1st page of data
		//this flag is cleared by the master after one page of data transmitted
		slv_ready_receive = 1;  //HR_RELAY_READY_BOOT. Slave is ready 
		break;

	case STATE_WAIT_DATA:
		if(data_ready_parser_flag == 1)
		{
			//modbus received 64 bytes of data in the buffer. 
			//proceed to parser the intel hex format data
			machine_state = STATE_BOOTLOADING;
			data_ready_parser_flag = 0; //reset the flag for next page of data
		}
		break;

	case STATE_BOOTLOADING:
		machine_state = BootLoading_Menu();
		break;

	case STATE_ERROR:
		machine_state = Error_Menu();
		break;

	case STATE_DONE:
		machine_state = Done_Menu();  //reset the flag in EE
		Reset();
		break;

	case STATE_TEST_DONE:
		break;

	default:
		break;
	}//End Switch
}

/**********************************************************
* name: Boot_Init_Menu()
* input: None
* output: return state of State Machine
**********************************************************/
//Init menu function
uint8_t Boot_Init_Menu(void)
{
	uint8_t ret_state = STATE_INIT; 	// Assume we dispatch ourself
	//static unsigned long address = APP_CODE_START_ADDRESS;//0x3700;
	unsigned long address = APP_CODE_START_ADDRESS;//0x3700;
	//Erase flash 64 bytes at a time
	//Once we are done, go to the next state and start getting the new firmware
	for(; address < APP_CODE_END_ADDRESS; address += 64)
	{
		FLASH_EraseMemory(address);  //page erase
		CLRWDT();
	}
	
	ret_state = STATE_WAIT_DATA;   
	return ret_state;
}

//Bootloading menu function
uint8_t BootLoading_Menu(void)
{
	uint8_t ret_state = STATE_BOOTLOADING; 	// Assume we dispatch ourself

	int8_t status = 0;
	int8_t len = 0;
	uint8_t i;
	static uint16_t block = 0;
	HEX_PARSER_ERROR_t error = HEX_PARSER_ERROR_NONE;

	//If we have an error, increment the error counter
	//If we have 10 sequential errors during the boot process
	//then drop into the appropriate error state.
	//If we had a successful read, reset the error counters

	//block_length holds received data length.It was updated in modbus write file function.
	len = block_length;  //data bytes in one block
	error = HEX_PARSER_IntelHexToFlash(&HEX_PARSER, buffer, len, block);

	if(error != HEX_PARSER_ERROR_NONE)
	{
		error_handle = -4;
		ret_state = STATE_ERROR;
	}
	else
	{	
		slv_ready_receive = 1; //ready for next block
		//Increment the block for the next read through
		block++;
		//block_parsered = block; //debug only
		//JTH: len will hold the length of the data from the file transfer, 		
		//When we receive a file that's less than 64 byes long,
		//we are done and can go to the done state

		if(len == 64)		
			ret_state = STATE_WAIT_DATA;
		else
			ret_state = STATE_DONE;			
	}		
	return ret_state;
}// end bootloader_menu

//Error menu function
uint8_t Error_Menu(void)
{
	uint8_t ret_state = STATE_ERROR; 	// Assume we dispatch ourself
	return ret_state;
}

//Done menu function
uint8_t Done_Menu(void)
{
	uint8_t ret_state = STATE_DONE; 	// Assume we dispatch ourself
	write_eeprom_byte(EE_BOOTLOADER_FLAG,0x00);
	return ret_state;
}




/*****************************************************************************************
* interrupt service routine function: All_Int_Services()
* interupt function default to being high priority. To create a low-priority interrupt
* function, use the qualifier low_priority interrupt in the function definition
******************************************************************************************/
//void interrupt All_Int_Services(void)
void interrupt low_priority
All_Boot_IRS(void)
{   
     
	BYTE i = 0;   
	
	if(TMR2IE && TMR2IF)  
	{//pic18F45k22

		PIR1bits.TMR2IF = 0; //clear interrupt flag	

		if(MB_SERVER_DISPLAY.modbus_timer == 1)
			MB_Display_ServiceModbusTimers((MODBUS_SERVER_t*) &MB_SERVER_DISPLAY);	
	}

	/************************************************************************
 	*	This interrupt gets fired when there is an unread character in the 
 	*  receive buffer 
 	************************************************************************/
	if( RC1IE && RC1IF ) //USART1 receive interrupts
	{
		BYTE data;
		modbus_errors_t error = NO_ERROR;
		if(RCSTA1bits.FERR==1)
		{
			BYTE dummy;
			Nop();
			dummy = RCREG1;
			error = SLAVE_FAILURE;
		}
		else if(RCSTA1bits.OERR == 1)	//If we had an overrun error (OERR)
		{	//toggle CREN to start it up again
			RCSTA1bits.CREN = 0;
			Nop();
			RCSTA1bits.CREN = 1;
			error = SLAVE_BUSY;
		}
		while(PIR1bits.RC1IF == 1)
		{
		//	MB_SERVER_DISPLAY.modbus_inactivity_timer = 4;
			data = RCREG1;
			MB_Display_CharacterReceived((MODBUS_SERVER_t*) &MB_SERVER_DISPLAY, data, 0); // disregard error
		}
	}//end of if(PIR1bits.RC1IF) //USART1 receive interrupts
	
	/************************************************************************
	 *	This interrupt gets fired when the transmit buffer is empty.
	 ************************************************************************/
	if(TX1IE && TX1IF)  //USART1 transmit interrupt
	{
		static UINT16 tx_buffer_ndx = 1;

	//	MB_SERVER_DISPLAY.modbus_inactivity_timer = 4;

		if(MB_SERVER_DISPLAY.tx_size > 0)
		{
		//*** send next byte, increment the ndx     ***//
		//*** PIR1bits.TX1IF is read only on pic18f ***//
		
			TXREG1 = MB_SERVER_DISPLAY.data[tx_buffer_ndx++];		
			MB_SERVER_DISPLAY.tx_size -= 1;
		}
		else
		{
			while(!TXSTA1bits.TRMT); //wait until TSR is empty

			PIE1bits.TX1IE = 0;     // Disable TX interrupt for USART 1
			TXSTA1bits.TXEN = 0;    // Transmitter off		
			tx_buffer_ndx = 1; //reset the ndx for next time
			MB_SERVER_DISPLAY.last_byte = 1;
			MB_SERVER_DISPLAY.sending_response = 0;			
			RCV_485();	//output low			
		}
	}//end of if(PIR1bits.TX1IF)

	//general use timer--1ms
	if(TMR1IE && TMR1IF)
	{     /*timer1 overflow interrupt ,1ms */
 		PIR1bits.TMR1IF = 0; //clear interrupt flag
   
		TMR1H = 0xFC;  //Fosc = 32MHZ, 0xFC18+999 = 0xFFFF, 1ms
		TMR1L = 0x18; 
        		   	  
	      // 1ms code
		for(i=0; i<NUM_ONE_MS_TIMER; i++)
			if(one_ms_timer[i]) 
				one_ms_timer[i]--;

	} //end of if(TMR1IE && TMR1IF)

} //end of interrupt function


