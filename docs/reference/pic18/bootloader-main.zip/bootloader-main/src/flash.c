/*
 * fflash.c
 *
 *  Created on: March 28th, 2011
 */
/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/
#include <include_all.h>

/* compiler xc8 */
#define TableRead_PostInc()	 {asm("TBLRDPOSTINC");}  // table read with post increment 
#define TableRead_PostDec()  {asm("TBLRDPOSTDEC");}  // table read with post decrement 
#define TableWrite_PreInc()  {asm("TBLWTPREINC");}   // table write with pre increment

void FLASH_EraseMemory(unsigned long address)
{
	while (EECON1bits.WR) {}               // wait for any eeprom write to finish 
    INTCONbits.GIEL = 0;                   // disable low priority interrupts 
    INTCONbits.GIEH = 0;                   // disable high priority interrupts

    // set table pointer to desired page address.... 
    TBLPTRU = *((unsigned char *)&address+2); // set up table pointer register (upper byte) 
    TBLPTRH = *((unsigned char *)&address+1); // set up table pointer register (high byte) 
    TBLPTRL = *((unsigned char *)&address);   // set up table pointer register (low byte) 
	TBLPTRL &= 0xE0;                       // make sure address points to first byte in page
 
    // erase page.... 
    EECON1bits.EEPGD = 1;                  // point to flash code space 
    EECON1bits.CFGS = 0;                   // do not access config space 
    EECON1bits.WREN = 1;                   // enable write to memory 
    EECON1bits.FREE = 1;                   // enable page erase operation 
    EECON2 = 0x55;                         // write entry sequence step 1 
    EECON2 = 0xAA;                         // write entry sequence step 2 
    EECON1bits.WR = 1;                     // erase page of code memory (CPU stalls until complete) 
    Nop();                                 // NOP instruction immediately after CPU stall 

	// re-enable interrupts.... 
	INTCONbits.GIEH = 1;                   // enable high priority interrupts 
	INTCONbits.GIEL = 1;                   // enable low priority interrupts
}

/******************************************************************************
 * FLASH_WriteMemory() 
 * Note(JTH): One write block is 64byte in this function. Some devices have   *
 *            blocks of 32. Make changes accordingly. 
 *    when address_offset+data_length>64, the valid data in the arrayread[]	  * 
 *    must be more than 64 elements,so we need to write one more page     	  *
 *    even though the valid data is far more less than 64byte in the 2nd page *
 *****************************************************************************/ 

void FLASH_WriteMemory (unsigned long addr, unsigned char *data, unsigned char length) 
{ 
    signed char    i, j;
	uint8_t read[128]; //63+16=79 should be the least size of this array,make it two pages. --JTH
	uint8_t k = 0;
	uint32_t starting_address;
	uint32_t address_offset;

	//Check the address to see where we line up at:
	address_offset = addr % 64;
	starting_address = addr - address_offset;

	//Read out a page of memory, and change the values that need updating
	FLASH_ReadMemory(starting_address, &read[0]);

	for(k=address_offset; k<(address_offset + length); k++)
	{
		read[k] = data[k-address_offset];
	}

	//Once we are ready, erase the page, and write in the new values
	FLASH_EraseMemory(starting_address);
		
    //make sure everything is ready, then disable interrupts.... 
    while (EECON1bits.WR) {}               // wait for any eeprom write to finish 
    INTCONbits.GIEL = 0;                   // disable low priority interrupts 
    INTCONbits.GIEH = 0;                   // disable high priority interrupts

    // set up starting addresses (FSR0 & TBLPTR).... 
    FSR0H = ((((unsigned int)&read[0])>>8)&0xFF);  // starting address of data array (hi byte) 
    FSR0L = (((unsigned int)&read[0])&0xFF);       // starting address of data array (lo byte) 
    TableRead_PostDec();                   		   // dummy table read decrements TBLPTR
 
    // fill holding registers from data array .... 
   	for (i=64;i!=0;i--) { 
        TABLAT = (POSTINC0);               // move byte from data array to TABLAT register 
        TableWrite_PreInc();               // write data from TABLAT into holding register 
    }
   	 
    EECON1bits.EEPGD = 1;                  // point to flash code space 
    EECON1bits.CFGS = 0;                   // do not access config space 
   	EECON1bits.WREN = 1;                   // enable write to memory 
   	EECON2 = 0x55;                         // write entry sequence step 1 
    EECON2 = 0xAA;                         // write entry sequence step 2 
    EECON1bits.WR = 1;                     // write page of code memory (CPU stalls until complete) 
    Nop();                                 // NOP instruction immediately after CPU stall
  	
    if(address_offset+length > 64)
	{
		//erase one more page. it also set table pointer to desired page address....  		
		FLASH_EraseMemory(starting_address+64);
		// set up starting addresses (FSR0 & TBLPTR).... 
    	FSR0H = ((((unsigned int)&read[64])>>8)&0xFF);  // starting address of data array (hi byte) 
    	FSR0L = (((unsigned int)&read[64])&0xFF);       // starting address of data array (lo byte) 
    	TableRead_PostDec();                   		   // dummy table read decrements TBLPTR

    	// fill holding registers from data array .... 
    	for (i=64;i!=0;i--) { 
        	TABLAT = (POSTINC0);               // move byte from data array to TABLAT register 
        	TableWrite_PreInc();               // write data from TABLAT into holding register 
    	}
    		
    	EECON1bits.EEPGD = 1;                  // point to flash code space 
   		EECON1bits.CFGS = 0;                   // do not access config space 
    	EECON1bits.WREN = 1;                   // enable write to memory 
    	EECON2 = 0x55;                         // write entry sequence step 1 
    	EECON2 = 0xAA;                         // write entry sequence step 2 
    	EECON1bits.WR = 1;                     // write page of code memory (CPU stalls until complete) 
    	Nop();                                 // NOP instruction immediately after CPU stall 
	}   
                
    EECON1bits.WREN = 0;                   // disable write to memory

    // re-enable interrupts.... 
    INTCONbits.GIEH = 1;                   // enable high priority interrupts 
    INTCONbits.GIEL = 1;                   // enable low priority interrupts
	
} 

void FLASH_ReadMemory (unsigned long addr, unsigned char *data) 
{ 
	signed char    i;

	// set table pointer to desired page address.... 
	TBLPTRL = *((unsigned char *)&addr);   // set up table pointer register (low byte) 
	TBLPTRH = *((unsigned char *)&addr+1); // set up table pointer register (high byte) 
	TBLPTRU = *((unsigned char *)&addr+2); // set up table pointer register (upper byte) 
	TBLPTRL &= 0xC0;                       // make sure address points to first byte in page 
	
	// read 64-byte page into data array.... 
	for (i=0;i<=63;i++) { 
		TableRead_PostInc(); // read byte from code space into TABLAT register & increment table pointer 
		data[i] = TABLAT;    // put byte into ram array 
	} 
} 

