/**
 * parameters.c
 *
 * Created on: Mar 03, 2011
 *
 */

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#include <include_all.h>
 
extern UINT16 	engine_run_timer;
extern UINT16	engine_oil_timer;
extern UINT16 	machine_run_timer;
extern BYTE 	mode_bttn_state;
extern BYTE		mode_bttn_state_ck;

extern BYTE 	engine_op_status;
extern BYTE 	control_status;
extern BYTE 	temp_dspl_state;

extern BYTE     error_state;
extern BYTE 	oil_state;

extern BYTE slv_ready_receive;

modbus_errors_t MB_Display_HoldingReg(MODBUS_SERVER_t * pThis, uint16_t regNumber, int16_t * data, uint8_t write)
{
	modbus_errors_t error = NO_ERROR;
	//this is for the usb error codes.
	static uint8_t temp = 0;		//for relay boot
	static uint8_t temp_disp = 0;	//for display boot
	static uint8_t exportTemp = 0;	//for export all
	static uint8_t temp_table = 0;	//for import shot table (all)
	static uint8_t exportSuccess = FALSE;

	switch(regNumber) 
	{
		case HR_DSPL_CABIN_TEMP:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
			
				*data = get_cabin_temperature();
				
			}
		break;
							
		case	HR_DSPL_BATT_VOLTAGE:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_battery_voltage();
			}
		break;
		
		case HR_DSPL_OP_MODE:	
			if(write)
			{				
				error = set_op_mode_bttn_value(*data);
			}
			else
			{
				*data = get_op_mode_bttn_value();
			}
		break;	

		case HR_DSPL_ENGINE_RUN_TIMER:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_engine_run_time();
			}			
		break;	
		
		case HR_DSPL_ENGINE_OIL_TIMER:
			if(write)
			{
				error = set_engine_oil_time(*data);
			}
			else
			{
				// Perform read function.
				*data = get_engine_oil_time();
			}
		break;

		case HR_DSPL_MACHINE_RUN_TIMER:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
					// Perform read function.
				*data = get_machine_run_time();
			}
		break;

		case HR_DSPL_ENGINE_STATUS:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
					// Perform read function.
				*data = get_engine_status();
			}
		break;

		case HR_DSPL_CLIMATE_STATUS:	//climate control mode status
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
					// Perform read function.
				*data = get_control_status();
			}
		break;

		case HR_DSPL_OP_ERROR_STATE:
			if(write)
			{				
				error = set_error_state(*data);
				
			}
			else
			{
				// Perform read function.
				*data = get_error_state();
			}
		break;

		case HR_DSPL_OIL_CHANGE_STATE:
			if(write)
			{
				//oil warning screen was manually dismissed
				error = set_oil_state(*data);
			}
			else
			{
				// Perform read function.
				*data = get_oil_state();
			}
		break;

		case HR_TRUCK_ENGINE_STATE:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_truck_engine_state();
			}
		break;

		case HR_ENGINE_RPM_PORTSTATE:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_engine_rpm_portstate();
			}
		break;

		case HR_TEMP_DSPLY_STATE:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_temperature_dspl_state();
			}

		break;

		case HR_RELAY_RESET_MICRO:
			if(write)
			{
				Reset();
			}
			
		break;

		case HR_RELAY_READY_BOOT:
			if(write)
			{
				error = set_ready_boot_state(*data);
			}
			else
			{
				*data = get_ready_boot_state();
			}
		break;

		default:
		error = ILLEGAL_DATA_ADDRESS;
		break;
	}

	return(error);

} //end of function MB_Display_HoldingReg()


UINT16 get_ready_boot_state(void)
{
	return (uint16_t) slv_ready_receive;
}

UINT8 set_ready_boot_state(UINT16 value)
{
	UINT8 error = NO_ERROR;
	slv_ready_receive = (BYTE)value;
	return error;
}

UINT16 get_cabin_temperature(void)
{
	return (uint16_t)72;
}



UINT16 get_battery_voltage(void)
{
	return (uint16_t)1200;
}

UINT16 get_op_mode_bttn_value(void)
{
	return mode_bttn_state;
}

UINT8 set_op_mode_bttn_value(UINT16 value)
{
	UINT8 error = NO_ERROR;
	mode_bttn_state_ck = value;	
	return error;
}

UINT16 get_engine_run_time(void)
{
	return (uint16_t)100;
}

UINT16 get_engine_oil_time(void)
{
	return (uint16_t)100;
}

UINT8 set_engine_oil_time(UINT16 value)
{
	UINT8 error = NO_ERROR;
	return error;
}

UINT16 get_machine_run_time(void)
{
	return (uint16_t)100;
}
	
UINT8 set_oil_state(UINT16 value)
{
	UINT8 error = NO_ERROR;
	return error;
}

UINT16  get_oil_state(void)
{
	return (uint16_t)oil_state;
}

UINT8 set_error_state(UINT16 value)
{
	UINT8 error = NO_ERROR;
	return error;
}

UINT16 get_error_state(void)
{
	return (uint16_t)error_state; 
}


UINT16 get_truck_engine_state(void)
{
	return (uint16_t)Truck_Engine_State;
}

UINT16 get_engine_rpm_portstate(void)
{
	return (uint16_t)Engine_RPM ;
}

UINT16 get_engine_status(void)
{
	return (UINT16)engine_op_status;
}

UINT16 get_control_status(void)
{
	return (UINT16)control_status;
}
	

UINT16 get_temperature_dspl_state(void)
{
	return (UINT16)temp_dspl_state;
}
	


