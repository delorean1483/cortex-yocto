/*******************************************************************************
 *	modbus_server_rs232.c
 *******************************************************************************/
/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#include "include_all.h"

BYTE mb_rs232_slave_id[] = "Parks RS232 Port";

void MB_RS232_InitializeModbus(MODBUS_SERVER_t * pThis, BYTE address)
{		
	UINT16 baudrate;
	baudrate = BAUD_RATE_RS232_DSPL;

	MB_RS232_UARTInit(BAUD_RATE_RS232_DSPL);
	MB_RS232_TimerInit(BAUD_RATE_RS232_DSPL);

	pThis->mb_my_address = address;

	pThis->sending_response = 0;
	pThis->last_byte = 0;

	pThis->rx_index = 0; //this effectively clears the buffer
	pThis->mb_state = MB_INITIAL_STATE;
	/*the following part is application specific, beacause PR2 is an 8bit register.*/
	if(baudrate == 9600)
	{
		pThis->inter_frame_timeout = 2* INTER_FRAME_MAX_TMR;
		pThis->inter_char_timeout = 2*INTER_CHAR_MAX_TMR;
	}
	else
	{
		pThis->inter_frame_timeout = INTER_FRAME_MAX_TMR;
		pThis->inter_char_timeout = INTER_CHAR_MAX_TMR;
	}
	

	MB_RS232_StartTimers(pThis); 

}

void MB_RS232_ProcessModbus(MODBUS_SERVER_t * pThis)
{

	//Check if we have a frame that needs to be processed
	if(pThis->mb_state == MB_CNTRL_WAITING && pThis->mb_frame_status == MB_NEEDS_CHECKING)
	{
		_mbm_disable_interrupts_rs232(); //disable tx,rcv interrupts

		pThis->mb_frame_status = MB_RS232_CheckFrame(pThis);

		if(pThis->mb_frame_status == MB_OK) //check if the frame should be processed
		{
			pThis->tx_size = MB_RS232_ProcessFrame(pThis);
		}

		_mbm_enable_interrupts_rs232();
	}
	//This signals that we have processed the current frame (if any)
	pThis->mb_processing_pending = 0;
}


BYTE MB_RS232_CheckFrame(MODBUS_SERVER_t * pThis)
{
	UINT16 received_crc;
	UINT16 calculated_crc;
	//first, check if this packet is for me
	if(pThis->data[MB_SLAVE_ADDR_FIELD] == pThis->mb_my_address )	
	{
		//calculate the crc of the recv'd data (don't include recv'd crc)
		received_crc = MB_RS232_GetCRC(pThis, &pThis->data[0], pThis->rx_index - 2);

		calculated_crc = pThis->data[pThis->rx_index - 1];
		calculated_crc <<= 8;
		calculated_crc |= (pThis->data[pThis->rx_index - 2] & 0x00FF);

		if(calculated_crc == received_crc) //check if crc's match
			return MB_OK;
		else
			return MB_NOK;
	}
	else
		return MB_NOK;
}

/*******************************************************************************
 *	MB_GetCRC() returns the CRC of the buffer that is passed to it.
 *******************************************************************************/


UINT16 MB_RS232_GetCRC(MODBUS_SERVER_t * pThis, BYTE *buffer, BYTE buffer_size)
{
	BYTE i;
	BYTE j;
	BYTE lsbit;
	UINT16 crc_value = INIT_REMAINDER;

	for(i = 0; i < buffer_size; i++)
	{
		crc_value ^= buffer[i];
		for(j = 0; j < 8; j++)
		{
			lsbit = crc_value & 0x01;
			crc_value >>= 1;
			if(lsbit)
				crc_value ^= 0xA001;
		}
	}
	crc_value ^= FINAL_XOR;
	return crc_value;
}


void MB_RS232_CharacterReceived(MODBUS_SERVER_t * pThis, BYTE uart_data, BYTE error)
{
	//Check if a communication error has been detected
	if(error)
	{
		//here we create a condition that will cause the frame not to be processed
		pThis->mb_state = MB_CNTRL_WAITING;
		pThis->mb_frame_status = MB_NOK;
	}
	else
	{
		switch(pThis->mb_state) {
		case MB_IDLE:
		case MB_RECEPTION:
			pThis->mb_state = MB_RECEPTION;
			//save the new byte into the buffer

			pThis->data[pThis->rx_index++] = uart_data;
			//start the timers
			MB_RS232_StartTimers(pThis);
			pThis->mb_frame_status = MB_NEEDS_CHECKING;
			break;

		case MB_INITIAL_STATE:
			MB_RS232_StartTimers(pThis);
			break;

		case MB_CNTRL_WAITING:
			//We shouldn't receive any data while in MB_CNTRL_WAITING state
			pThis->mb_frame_status = MB_NOK;
			break;

		default:

			break;
		}
	}
}


void MB_RS232_ServiceModbusTimers(MODBUS_SERVER_t * pThis)
{
	if(pThis->mb_inter_char_tmr < pThis->inter_char_timeout)
	{
		pThis->mb_inter_char_tmr++;
		/*If the following is true, then we just hit 1.5 char times*/
		if(pThis->mb_inter_char_tmr == pThis->inter_char_timeout)
			if(pThis->mb_state == MB_RECEPTION)
			{
				pThis->mb_state = MB_CNTRL_WAITING;
				pThis->mb_processing_pending = 1;
			}
	}
	if(pThis->mb_inter_frame_tmr < pThis->inter_frame_timeout && !pThis->mb_processing_pending)
	{
		pThis->mb_inter_frame_tmr++;
		if(pThis->mb_inter_frame_tmr == pThis->inter_frame_timeout)
		{
			/*The following happens when inter-frame timer times-out*/
			if(pThis->mb_state == MB_CNTRL_WAITING && pThis->mb_frame_status == MB_OK)
				//check if there is something to send
				if(pThis->tx_size > 0)
				{
					MB_RS232_XmitFrame(pThis); //send the response frame
				}
			pThis->rx_index = 0;
			pThis->mb_state = MB_IDLE; //reset the MODBUS state machine to IDLE
			MB_RS232_StopModbusTimer(pThis);
		}
	}
}

void MB_RS232_StartTimers(MODBUS_SERVER_t * pThis)
{
	pThis->mb_inter_char_tmr = 0;
	pThis->mb_inter_frame_tmr = 0;
	MB_RS232_ResetModbusTimer(pThis);
}

void MB_RS232_StopInterCharTimer(MODBUS_SERVER_t * pThis)
{
	//we stop the timer by setting the count variable past it's max value
	pThis->mb_inter_char_tmr = pThis->inter_char_timeout;
}

/*******************************************************************************
 *	MB_StopInterFrameTimer() stops the inter-character timer.
 *******************************************************************************/

void MB_RS232_StopInterFrameTimer(MODBUS_SERVER_t * pThis)
{
	//we stop the timer by setting the count variable past it's max value
	pThis->mb_inter_frame_tmr = pThis->inter_frame_timeout;
}

/******************************************************************************
 *------------------------------------------------------------------------------
 *	ALL OF THE FOLLOWING FUNCTIONS ARE TARGET/APPLICATION SPECIFIC!!!
 *	These functions must be modified to work with your target device and app.
 *------------------------------------------------------------------------------
 ******************************************************************************/


void MB_RS232_StopModbusTimer(MODBUS_SERVER_t * pThis)
{//pic18f45k22
	T4CONbits.TMR4ON = 0; //control it
	pThis->modbus_timer = 0;
}


BYTE MB_RS232_ProcessFrame(MODBUS_SERVER_t * pThis)
{
	BYTE frame_len = 0; //this is the number of bytes that are to be sent
	modbus_errors_t error_code = NO_ERROR;
	modbus_errors_t ERROR_SAVE = NO_ERROR;

	UINT16 temp_word1;
	UINT16 temp_word2;

	INT16 data;
	UINT16 crc;
	BYTE i;
	BYTE ndx, ndx2;


	pThis->mb_counter[RTRN_BUS_MESSAGE_CNT - MB_FIRST_COUNTER_OFFSET]++;
	
	temp_word1 = pThis->data[MB_START_ADDR_HI];
	temp_word1 <<= 8;
	temp_word1 |= pThis->data[MB_START_ADDR_LOW];
	
	temp_word2 = pThis->data[MB_QTY_HI];
	temp_word2 <<= 8;
	temp_word2 |= pThis->data[MB_QTY_LOW];

	switch(pThis->data[MB_FUNCTION_FIELD]) {

#ifdef MB_USE_HOLDING_REG

	case WRITE_SINGLE_REG: //this request writes only one holding register
	case WRITE_MULTIPLE_REGS:

		ERROR_SAVE = NO_ERROR;

		switch(pThis->data[MB_FUNCTION_FIELD]) 
		{
			case WRITE_SINGLE_REG: //this request writes only one holding register
			ndx = MB_FUNCTION_FIELD + 3; // Points to the value.
			temp_word2 = 1;
			break;

			case WRITE_MULTIPLE_REGS:
			ndx = MB_FUNCTION_FIELD + 3; // Points to the number of registers
			temp_word2 = (UINT16)(pThis->data[ndx++]) << 8;
			temp_word2 |= (UINT16)(pThis->data[ndx++]);
			ndx2 = pThis->data[ndx++]; // This byte contains the data byte count.
			break;

			default:
			ndx = 0; // Gets rid of compiler warning about ndx being uninitialized with higher optimization settings
			break;
		}
		if(temp_word2 >= 0x0001 && temp_word2 <= 0x007D)
		{
			if((temp_word1 + temp_word2) <= MAX_HOLDING_REG_PARAMETER_DISP)
			{
				for(ndx2 = 0; ndx2 < temp_word2; ndx2++)
				{				
					data = (UINT16)(pThis->data[ndx++]) << 8; //for mplabc18 compiler
					data |= (UINT16)(pThis->data[ndx++]);

					error_code = MB_Display_HoldingReg(pThis, (temp_word1 + ndx2 + 1), &data, 1);							
					if(error_code)
					{	// If an error occurs, save it.
						ERROR_SAVE = error_code;
					}
				}
				if(WRITE_SINGLE_REG == pThis->data[MB_FUNCTION_FIELD])	// Added for Standard MB compatibility 2011 - RCB
				{
					frame_len = ndx;
				}
				else	// Must be WRITE_MULTIPLE_REGS
				{	// So don't include count or data in response.
					frame_len = MB_MESSAGE_HEADER_SIZE;
				}

			  if(!error_code) // Keep the last one if there is one.
			  {	// otherwise restore a previous error if one occurred.
				 error_code= ERROR_SAVE;
				 if(!error_code) // Check again..
				 {
					Nop();
				 }
			  }
			}
			else
				error_code = ILLEGAL_DATA_ADDRESS;
		}
		else
			error_code = ILLEGAL_DATA_VALUE; // Too long for MB Buffer

		break;
#endif

		/*This function reads the number of holding registers specified in
		 * temp_word2 starting with the register specified in temp_word1*/
#ifdef MB_USE_HOLDING_REG
	case READ_HOLDING_REG:

		if(temp_word2 >= 0x0001 && temp_word2 <= 0x007D)
		{
			if((temp_word1 + temp_word2) <= MAX_HOLDING_REG_PARAMETER_DISP)
			{
				ndx = MB_FUNCTION_FIELD + 1;
				pThis->data[ndx++] = temp_word2 * 2;
				for(ndx2 = 0; ndx2 < temp_word2; ndx2++)
				{
					error_code = MB_Display_HoldingReg(pThis, temp_word1 + ndx2 + 1, &data, 0);					
					if(!error_code)
					{
						pThis->data[ndx++] = (BYTE) (data >> 8);					
						pThis->data[ndx++] = (BYTE) (data);
					}
				}
				frame_len = ndx;				
			}
			else
				error_code = ILLEGAL_DATA_ADDRESS;
		}
		else
			error_code = ILLEGAL_DATA_VALUE;
		break;

#endif

		/*This function returns an application defined exception code*/
	case READ_EXCEPTION_STATUS:
		pThis->data[MB_FUNCTION_FIELD + 1] = 0;
		frame_len = MB_START_ADDR_HI + 1;
		break;

		/*This function reports the application-specific slave ID*/
		
		 // LONWorks Gateway doesn't need this.
	case REPORT_SLAVE_ID:
		 //mb_slave_id must be NULL terminated
		 for(i = 0; mb_rs232_slave_id[i] != 0; i++)
			pThis->data[i + MB_START_ADDR_HI + 1] = mb_rs232_slave_id[i];		
		 pThis->data[MB_START_ADDR_HI] = i; //byte-count of data payload
		 frame_len = MB_START_ADDR_HI + 1 + i;
		 break;
		 

		/*This function reads the number of input registers specified in
		 * temp_word2 starting with the register specified in temp_word1*/

#ifdef MB_USE_INPUT_REG
	case READ_INPUT_REG:
		/*temp_word1 is the starting address, temp_word2 is the quantity*/
		if(temp_word2 >= 0x0001 && temp_word2 <= 0x007D)
		{		
			if((temp_word1 + temp_word2) <= MAX_HOLDING_REG_PARAMETER_DISP)
			{
				ndx = MB_FUNCTION_FIELD + 1;
				pThis->data[ndx++] = temp_word2 * 2;

				for(ndx2 = 0; ndx2 < temp_word2; ndx2++)
				{
					error_code = MB_Display_HoldingReg(pThis, temp_word1 + ndx2 + 1, &data, 0);
					if(!error_code)
					{
						pThis->data[ndx++] = (BYTE) (data >> 8);
						pThis->data[ndx++] = (BYTE) (data);
					}
				}
				frame_len = ndx;
				
			}
			else
				error_code = ILLEGAL_DATA_ADDRESS;
		}
		else
			error_code = ILLEGAL_DATA_VALUE;
		break;
#endif

#ifdef MB_USE_HOLDING_REG	
        
	case WRITE_HOLDING_REG_BROADCAST:
		break;

#endif

	case DIAGNOSTICS:
		//temp_word1 is the diagnostic sub-function, temp_word2 is data
		switch(temp_word1) {
		case RETURN_QUERY_DATA:
			frame_len = pThis->rx_index - 2;
			break;

		case RESTART_COMM_OPTIONS:		
			frame_len = pThis->rx_index - 2;
			break;

		case RETURN_DIAGNOSTIC_REG:
		case FORCE_LISTEN_MODE:
			break;

		case CLEAR_COUNTERS:
			MB_Display_ResetCounters(pThis);
			break;

			//the following commands return counters
		case RTRN_BUS_MESSAGE_CNT:
		case RTRN_BUS_COMM_ERR_CNT:
		case RTRN_BUS_EXCEPTN_CNT:
		case RTRN_SLAVE_MSG_CNT:
		case RTRN_SLAVE_NO_RESP_CNT:
		case RTRN_SLAVE_NAK_CNT:
		case RTRN_SLAVE_BUSY_CNT:
		case RTRN_BUS_OVRRUN_CNT:  
			pThis->data[MB_QTY_HI]
					= (BYTE) (pThis->mb_counter[temp_word1 - MB_FIRST_COUNTER_OFFSET] >> 8);
			pThis->data[MB_QTY_LOW]
					= (BYTE) pThis->mb_counter[temp_word1 - MB_FIRST_COUNTER_OFFSET];
			frame_len = MB_QTY_LOW + 1;
			break;
		
		case CLR_OVERRUN_CNT_FLAG:
			break;

			/*the following are application specific sub-functions*/
		case PRODUCTION_TEST_MOD: //enter test mode
			if(Process_MB_TestCmd(temp_word2))
				frame_len = pThis->rx_index - 2;
			else
				error_code = ILLEGAL_FUNCTION;						
			break;

		default:
			break;
		}
		break; //end of diagnostic case statement

	default:
		//the function is unknown to us!
		error_code = ILLEGAL_FUNCTION;
		break;
	}

	//This 'if' is so the device doesn't respond to a file broadcast unless it
	//is the device that is supposed to respond.

	if(pThis->data[MB_SLAVE_ADDR_FIELD] == pThis->mb_my_address)
	{
		if(error_code != NO_ERROR)
		{
			pThis->data[MB_FUNCTION_FIELD] |= ERROR_RESPONSE;
			pThis->data[MB_FUNCTION_FIELD + 1] = error_code;
			frame_len = MB_FUNCTION_FIELD + 2;

			// Set an alert - this will get time stamped in the service time based tasks function
		}
		else
		{
			//ALERT_CNT_RS485_COMM = 0;
		}
		crc = MB_RS232_GetCRC(pThis, &pThis->data[0], frame_len);
		pThis->data[frame_len++] = (BYTE) crc;
		pThis->data[frame_len++] = (BYTE) (crc >> 8);
	}
	else
	{
		frame_len = 0;

	}

	return frame_len;
}





