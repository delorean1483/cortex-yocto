/**
 * modbus_server_portable.c
 *
**/

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#include <include_all.h>

volatile MODBUS_SERVER_t MB_SERVER_DISPLAY;

BYTE boot_buffer[20];

void MB_Display_UARTInit(int32_t baudRate)
{
	TRISCbits.TRISC6 = 1; //RC6 digital input 	//TX
	TRISCbits.TRISC7 = 1; //RC7 digital input	//RX
	TRISCbits.TRISC5 = 0; //RC5 digital output
	//UART1 RS485  PIC18F initialization
	//turn off
	PIE1bits.RC1IE = 0;   	//USART reciver interupt disabled
    PIE1bits.TX1IE = 0;   	//Transmit interrupt disabled
	
	switch(baudRate)
	{
	  
	   case 9600:
			BAUDCON1bits.BRG16 = 0;
			TXSTA1bits.BRGH = 1;   	//High speed 
			SPBRG1 = 207;
			break;
	  case 19200:
			BAUDCON1bits.BRG16 = 0;
			TXSTA1bits.BRGH = 1;   	//High speed 
			SPBRG1 = 103;
			break;
	  case 57600:
			BAUDCON1bits.BRG16 = 0;
			TXSTA1bits.BRGH = 1;   	//High speed 
			SPBRG1 = 34;
			break;
	  case 115200:
			BAUDCON1bits.BRG16 = 0;
			TXSTA1bits.BRGH = 1;   	//High speed 
			SPBRG1 = 16;
			break;
	  default:  // Default for 19200
			BAUDCON1bits.BRG16 = 0;
			TXSTA1bits.BRGH = 1;   	//High speed 
			SPBRG1 = 103;
			break;
	}

    TXSTA1bits.SYNC = 0;   	//Asynchronous mode
    RCSTA1bits.SPEN = 1;   	//Serial Port enabled

 	RCSTA1bits.CREN = 1;   	//USART1 receiver enabled 
    PIE1bits.RC1IE = 1;   	//USART reciver interupt enabled

    PIE1bits.TX1IE = 0;    //Transmit interrupt disabled
	RCV_485();  //receive mode

	//set IP
    IPR1bits.RC1IP = 1;  	//Receive interrupt high priority
	IPR1bits.TX1IP = 1;  	//Transmit interrupt high priority

}

void MB_Display_XmitFrame(MODBUS_SERVER_t * pThis)
{
	PIE1bits.RC1IE = 1;     // Enable receive interrupt
	RCSTA1bits.CREN = 1;    // Enable receiver
	TXSTA1bits.SYNC = 0;    // Asynchronous mode
	RCSTA1bits.SPEN = 1;    // Enable serial port
	PIE1bits.TX1IE = 1;     // Enable transmit interrupt for USART 1
	TXSTA1bits.TXEN = 1;    // Transmitter on
	XMIT_485(); //set directiion to transmit. output 1

	//**** send next byte, increment the ndx ****//
	pThis->sending_response = 1;
	pThis->last_byte = 0; 

	TXREG1 = pThis->data[0];

	pThis->tx_size -= 1;
}

/******************************************************************************
 *   ResetModbusTimers() simply starts the timer counting from zero
 ******************************************************************************/
 
void MB_Display_ResetModbusTimer(MODBUS_SERVER_t * pThis)
{  	//pic18F45K22
	
	TMR2 = 0;
	T2CONbits.TMR2ON = 1; //control it
	pThis->modbus_timer = 1;
}


//void MB_Display_TimerInit(MODBUS_SERVER_t * pThis)
void MB_Display_TimerInit(int32_t baudRate)
{
	TMR2 = 0;

	T2CONbits.T2CKPS1 = 1;
	T2CONbits.T2CKPS0 =0;

	switch(baudRate)
	{
	  //TODO: change max_char and max frame counter
	   case 9600: //260 will be overflow
			PR2 = 130;  //half charater time is 520us
			break;
	  case 19200:
			PR2 = 130; //half charater is 260us
			break;
	  case 57600:
			PR2 = 43; //half character time is 86us
			break;
	  case 115200:			 
			PR2 = 22; //half charater time is 44us
			break;
	  default:  // Default for 19200
			PR2 = 130;
			break;
	}

	IPR1bits.TMR2IP = 1; 	//TMR2 high priority
	PIE1bits.TMR2IE = 1;	//enalbe timer2-TMR2 to PR2 match interrupt
	
}

uint8_t BulkFileBlock_Display(
		uint8_t writeFlag,
		uint16_t file,  //temp_word1
		uint16_t block, //temp_word2
		uint8_t * data,
		uint8_t * data_len)
{

	uint8_t mbError = 0;
	uint8_t file_in;
    file_in = (uint8_t)file; //have to cast the data type

	if(file_in == BF_CURRENT_DATE)
	{
		if(writeFlag)
		{
		
		}
		else
		{
		
		}
	}
	else if(file_in == BF_RLY_BOOTLOAD)
	{
		if(writeFlag)
		{
			*data_len = 10;
			if(block == 0) //only block 0 is available
			{
				for(BYTE i = 0;  i < 10; i++)
					boot_buffer[i] = data[i];					
			}	
		}
		else
		{
			mbError = ERROR_RESPONSE;								
		}
	}
	else
	{
		mbError = ERROR_RESPONSE;
	}
	return mbError;
}
