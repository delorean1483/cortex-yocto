/*
 * modbus_server_portable_rs232.c
 *
 **/

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#include <include_all.h>

volatile MODBUS_SERVER_t MB_SERVER_RS232;


//void MB_Display_UARTInit(MODBUS_SERVER_t * pThis)
void MB_RS232_UARTInit(int32_t baudRate)
{
	TRISDbits.TRISD6 = 1; //RD6 digital input 	//TX2
	TRISDbits.TRISD7 = 1; //RD7 digital input	//RX2

	//UART2 RS485  PIC18F initialization
	//turn off
	PIE3bits.RC2IE = 0;   	//USART reciver interupt disabled
    PIE3bits.TX2IE = 0;   	//Transmit interrupt disabled
	//setup UART

	switch(baudRate)
	{	  
	   case 9600:
			BAUDCON2bits.BRG16 = 0;
			TXSTA2bits.BRGH = 1;   	//High speed 
			SPBRG2 = 207;
			break;
	  case 19200:
			BAUDCON2bits.BRG16 = 0;
			TXSTA2bits.BRGH = 1;   	//High speed 
			SPBRG2 = 103;
			break;
	  case 57600:
			BAUDCON2bits.BRG16 = 0;
			TXSTA2bits.BRGH = 1;   	//High speed 
			SPBRG2 = 34;
			break;
	  case 115200:
			BAUDCON2bits.BRG16 = 0;
			TXSTA2bits.BRGH = 1;   	//High speed 
			SPBRG2 = 16;
			break;
	  default:  // Default for 19200
			BAUDCON2bits.BRG16 = 0;
			TXSTA2bits.BRGH = 1;   	//High speed 
			SPBRG2 = 103;
			break;
	}

    TXSTA2bits.SYNC = 0;   	//Asynchronous mode
    RCSTA2bits.SPEN = 1;   	//Serial Port enabled

 	RCSTA2bits.CREN = 1;   	//USART1 receiver enabled 
    PIE3bits.RC2IE = 1;   	//USART reciver interupt enabled
	
    PIE3bits.TX2IE = 0;    //Transmit interrupt disabled

	//set IP
    IPR3bits.RC2IP = 1;  	//Receive interrupt high priority
	IPR3bits.TX2IP = 1;  	//Transmit interrupt high priority
}


void MB_RS232_XmitFrame(MODBUS_SERVER_t * pThis)
{

	PIE3bits.RC2IE = 1;     // Enable receive interrupt
	RCSTA2bits.CREN = 1;    // Enable receiver
	TXSTA2bits.SYNC = 0;    // Asynchronous mode
	RCSTA2bits.SPEN = 1;    // Enable serial port
	PIE3bits.TX2IE = 1;     // Enable transmit interrupt for USART 1
	TXSTA2bits.TXEN = 1;    // Transmitter on

	//send next byte, increment the ndx
	pThis->sending_response = 1;//--jintao com out
	pThis->last_byte = 0;   //--jintao com out

	TXREG2 = pThis->data[0];

	//after this byte leaves the tx buffer, an interrupt will fire which will
	//cause the next byte in mb_buffer to be transmitted.
	pThis->tx_size -= 1;
}

/******************************************************************************
 *   ResetModbusTimers() simply starts the timer counting from zero
 ******************************************************************************/

void MB_RS232_ResetModbusTimer(MODBUS_SERVER_t * pThis)
{  	//pic18F45K22	
	TMR4 = 0;
	T4CONbits.TMR4ON = 1;  //control it
	pThis->modbus_timer = 1;
}

void MB_RS232_TimerInit(int32_t baudRate)
{
	TMR4 = 0;
	T4CONbits.T4CKPS1 = 1;
	T4CONbits.T4CKPS0 = 0;

	switch(baudRate)
	{
	  //TODO: change max_char and max frame counter
	   case 9600:
			PR4 = 130;
			break;
	  case 19200:
			PR4 = 130;
			break;
	  case 57600:
			PR4 = 43;
			break;
	  case 115200:			 
			PR4 = 22;
			break;
	  default:
			PR4 = 130;
			break;
	}
	
	IPR5bits.TMR4IP = 1; 	//TMR2 high priority
	PIE5bits.TMR4IE = 1;	//enalbe timer4-TMR4 to PR4 match interrupt
}

