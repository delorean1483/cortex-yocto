/**
 * parameters.c
 *
 */
/**
 *  file: analog.c
 **/

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#include <include_all.h>


extern UINT16 	cabin_temperature;
extern UINT16	engine_temperature;
extern INT16	external_temperature;
extern UINT16   ext_temp_adcreading;
extern UINT16	low_side_pressure;
extern UINT16	high_side_pressure;
extern UINT16	battery_voltage; 
extern UINT16 	batt_monitor_setting;
extern UINT16 	clmt_temp_setting;  //needs to be initialized
extern UINT16 	engine_run_timer;
extern UINT16	engine_oil_timer;
extern UINT16 	machine_run_timer;
extern BYTE 	mode_bttn_state;
extern BYTE		mode_bttn_state_ck;

extern BYTE 	engine_op_status;
extern BYTE 	control_status;
extern BYTE 	temp_dspl_state;

extern BYTE     error_state;
extern BYTE 	oil_state;

extern BYTE 	evap_fan_speed;
extern BYTE     temperature_unit;
extern UINT16	batt_setting_storage;
extern UINT16 	temp_setting_storage;
extern UINT16 	storage_t_setting;	 //needs to be initialized
extern UINT16 	storage_v_setting;	 //needs to be initialized

extern BYTE stand_by_overide_flag;
extern BYTE high_ac_overide_flag;
extern BYTE low_ac_overide_flag;

extern UINT16   vref_calibration;
extern signed int	temperature_calibration;

extern UINT16 rpm_engine;
extern UINT16 rpm_average;

extern UINT16 relay_fmwr_rev;
extern UINT16 dspl_fmwr_rev;

extern BYTE product_test_mod_enabled;

UINT16 rtcc_mod_second;
UINT16 rtcc_mod_minute;
UINT16 rtcc_mod_hour;
UINT16 rtcc_mod_weekday;
UINT16 rtcc_mod_day;
UINT16 rtcc_mod_month;
UINT16 rtcc_mod_year;

UINT16 rtcc_ee_read_id;


modbus_errors_t MB_Display_HoldingReg(MODBUS_SERVER_t * pThis, uint16_t regNumber, int16_t * data, uint8_t write)
{
	modbus_errors_t error = NO_ERROR;
	//this is for the usb error codes.
	static uint8_t temp = 0;		//for relay boot
	static uint8_t temp_disp = 0;	//for display boot
	static uint8_t exportTemp = 0;	//for export all
	static uint8_t temp_table = 0;	//for import shot table (all)
	static uint8_t exportSuccess = FALSE;


	switch(regNumber) 
	{
		case HR_DSPL_CABIN_TEMP:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
			
				*data = get_cabin_temperature();
				
			}
		break;
			
		case	HR_DSPL_ENGINE_TEMP:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_engine_temperature();
			}

		break;	
	
		case	HR_DSPL_EXTERNAL_TEMP:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_ext_temperature();
			}
		break;	

		case	HR_DSPL_LSIDE_PRESSURE:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_low_side_pressure();
			}	
		break;

		case	HR_DSPL_HSIDE_PRESSURE	:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_high_side_pressure();
			}
		break;
	
		case	HR_DSPL_BATT_VOLTAGE:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_battery_voltage();
			}
		break;
		
		case HR_DSPL_OP_MODE:	
			if(write)
			{				
				error = set_op_mode_bttn_value(*data);
			}
			else
			{
				*data = get_op_mode_bttn_value();
			}
		break;	

		case HR_DSPL_ENGINE_RUN_TIMER:
			if(write)
			{
				// Read Only, So error
				//error = ILLEGAL_DATA_ADDRESS;
                		error = set_engine_run_time(*data);
			}
			else
			{
				// Perform read function.
				*data = get_engine_run_time();
			}			
		break;	
		
		case HR_DSPL_ENGINE_OIL_TIMER:
			if(write)
			{
				error = set_engine_oil_time(*data);
			}
			else
			{
				// Perform read function.
				*data = get_engine_oil_time();
			}
		break;

		case HR_DSPL_MACHINE_RUN_TIMER:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
					// Perform read function.
				*data = get_machine_run_time();
			}
		break;

		case HR_DSPL_ENGINE_STATUS:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
					// Perform read function.
				*data = get_engine_status();
			}
		break;

		case HR_DSPL_CLIMATE_STATUS:	//climate control mode status
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
					// Perform read function.
				*data = get_control_status();
			}
		break;

		

		case HR_EVAP_FAN_SPEED_SETTING:
			if(write)
			{
				
				error = set_evap_fan_speed(*data);
			}
			else
			{
				// Perform read function.
				*data = get_evap_fan_speed();
			}
		break;	

		case HR_DSPL_BATT_SETTING:  //battery monitor mode
			if(write)
			{
				error = set_battery_setting(*data);
			}
			else
			{
				*data = get_battery_setting();
			}
		break;	

		case HR_DSPL_TEMP_SETTING:		//climate control mode
			if(write)
			{
				error = set_temp_setting(*data);
			}
			else
			{
				*data = get_temp_setting();
			}
		break;	

		case HR_STORAGE_T_SETTING:      //store_t_setting.word  cold storage mode    
			if(write)
			{
				error = set_storage_temp(*data);
			}
			else
			{
				*data = get_storage_temp();
			}
		break;

		case HR_STORAGE_V_SETTING:
			if(write)
			{
				error = set_storage_volt(*data);
			}
			else
			{
				*data = get_storage_volt();
			}
		break;

		case HR_DSPL_TEMP_UNIT:
			if(write)
			{
				error = set_temperature_unit(*data);
			}
			else
			{
				*data = get_temperature_uint();
			}
		break;

		case HR_DSPL_OP_ERROR_STATE:
			if(write)
			{
				// Read Only, So error
				//error = ILLEGAL_DATA_ADDRESS;
				//if the error was overridden by display
				error = set_error_state(*data);
				
			}
			else
			{
				// Perform read function.
				*data = get_error_state();
			}
		break;

		case HR_DSPL_OIL_CHANGE_STATE:
			if(write)
			{
				//oil warning screen was manually dismissed
				error = set_oil_state(*data);
			}
			else
			{
				// Perform read function.
				*data = get_oil_state();
			}
		break;
		
		case HR_OIL_PRESSURE_STATE:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_oil_pressure();
			}
		break;

		case HR_TRUCK_ENGINE_STATE:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_truck_engine_state();
			}
		break;

		case HR_ENGINE_RPM_PORTSTATE:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_engine_rpm_portstate();
			}
		break;

		case HR_DSPL_CLND_STATE:
			if(write)
			{
				error = set_clnd_start_state(*data);
			}
			else
			{
				*data = get_clnd_start_state();
			}
		break;
		
		case HR_DSPL_CLND_MODE:
			if(write)
			{
				error = set_clnd_start_mode(*data);
			}
			else
			{
				*data = get_clnd_start_mode();
			}
		break;
			
 		case HR_DSPL_CLND_START_YEAR:
			if(write)
			{
				error = set_clnd_start_year(*data);
			}
			else
			{
				*data = get_clnd_start_year();
			}
		break;

		case HR_DSPL_CLND_START_MONTH:
			if(write)
			{
				error = set_clnd_start_month(*data);
			}
			else
			{
				*data = get_clnd_start_month();
			}
		break;

 		case HR_DSPL_CLND_START_DATE:
			if(write)
			{
				error = set_clnd_start_date(*data);
			}
			else
			{
				*data = get_clnd_start_date();
			}
		break;

 		case HR_DSPL_CLND_START_HOUR:
			if(write)
			{
				error = set_clnd_start_hour(*data);
			}
			else
			{
				*data = get_clnd_start_hour();
			}
		break;

 		case HR_DSPL_CLND_START_MIN:
			if(write)
			{
				error = set_clnd_start_min(*data);
			}
			else
			{
				*data = get_clnd_start_min();
			}
		break;

		case HR_DSPL_CLND_START_AMPM:
			if(write)
			{
				error = set_clnd_start_ampm(*data);
			}
			else
			{
				*data = get_clnd_start_ampm();
			}
		break;

		case HR_STANDBY_OVERRIDE_FLAG:
			if(write)
			{				
				error = set_standby_override_flag(*data);
			}
			else
			{
				*data = get_standby_override_flag();
			}
				
		break;
		case HR_TEMP_DSPLY_STATE:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_temperature_dspl_state();
			}

		break;

		case HR_RELAY_RESET_MICRO:
			if(write)
			{//write 0xA5 to EE to indicate start bootloader
				write_eeprom_byte(EE_BOOTLOADER_FLAG,0xA5);
				Reset();
			}
			
		break;

		case HR_CAL_VREF:
			if(write)
			{
				error = set_vref_calibration(*data);
			}
			else
			{
				*data = get_vref_calibration();
			}
		break;

		case HR_CAL_TEMPERATURE:
			if(write)
			{
				error = set_temp_calibration(*data);
			}
			else
			{
				*data = get_temp_calibration();
			}
		break;
		
		case HR_RELAY_ENGINE_RPM:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_engine_rpm();
			}
		break;

		case HR_RELAY_FMWR_REV:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_relay_fmwr_rev();
			}
			
		break;

		case HR_DSPL_FMWR_REV:
			if(write)
			{
				error = set_dspl_fmwr_rev(*data);
			}
			else
			{
				*data = get_dspl_fmwr_rev();
			}
		break;

		case HR_PRODUCTION_TEST_MODE:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_prd_test_mode();
			}
		break;

		case HR_RTCC_SET_YR:
			if(write)
			{
				error = set_rtcc_year(*data);
			}
			else
			{
				*data = get_rtcc_year();
			}
		break;

		case HR_RTCC_SET_MTH:
			if(write)
			{
				error = set_rtcc_month(*data);
			}
			else
			{
				*data = get_rtcc_month();
			}
		break;

		case HR_RTCC_SET_DAY:
			if(write)
			{
				error = set_rtcc_day(*data);
			}
			else
			{
				*data = get_rtcc_day();
			}
		break;

		case HR_RTCC_SET_WKD:
			if(write)
			{
				error = set_rtcc_weekday(*data);
			}
			else
			{
				*data = get_rtcc_weekday();
			}
		break;

		case HR_RTCC_SET_HR:
			if(write)
			{
				error = set_rtcc_hour(*data);
			}
			else
			{
				*data = get_rtcc_hour();
			}
		break;

		case HR_RTCC_SET_MIN:
			if(write)
			{
				error = set_rtcc_minute(*data);
			}
			else
			{
				*data = get_rtcc_minute();
			}
		break;

		case HR_RTCC_SET_SEC:
			if(write)
			{
				error = set_rtcc_second(*data);
			}
			else
			{
				*data = get_rtcc_second();
			}
		break;

		case HR_HIGHAC_OVERRIDE_F:
			if(write)
			{
				error = set_highac_override_flag(*data);
			}
			else
			{
				*data = get_highac_override_flag();
			}
		break;

		case HR_LOWAC_OVERRIDE_F:
			if(write)
			{
				error = set_lowac_override_flag(*data);
			}
			else
			{
				*data = get_lowac_override_flag();
			}
		break;	

        case HR_DSPL_EXT_TEMP_ADC:
			if(write)
			{
				// Read Only, So error
				error = ILLEGAL_DATA_ADDRESS;
			}
			else
			{
				// Perform read function.
				*data = get_ext_temp_adc();
			}

		break;
        case HR_RTC_EE_FLAG:
            if(write)
			{
				error = set_RTC_ID_flag(*data);
			}
			else
			{
				*data = get_RTC_ID_flag();
			}
            break;

		default:
		error = ILLEGAL_DATA_ADDRESS;
		break;
	}

	return(error);

} //end of function MB_Display_HoldingReg()


UINT16 get_cabin_temperature(void)
{
	return (uint16_t)cabin_temperature; // display temperature
}

UINT16 get_engine_temperature(void)
{
	return (uint16_t)engine_temperature;; // display 
}

UINT16 get_ext_temperature(void)
{
	return (uint16_t)external_temperature ; // display 
}

UINT16 get_ext_temp_adc(void)
{
	return  ext_temp_adcreading;  //raw adc reading for testing only
}

UINT16 get_low_side_pressure(void)
{
	return (uint16_t)low_side_pressure; // display 
	//return discrete_inputs[L_SIDE_PRESSURE].debounced_state;
}

UINT16 get_high_side_pressure(void)
{
	return (uint16_t)high_side_pressure; // display 
	//return discrete_inputs[H_SIDE_PRESSURE].debounced_state;
}

UINT16 get_battery_voltage(void)
{
	return (uint16_t)battery_voltage; // display 
}

UINT16 get_op_mode_bttn_value(void)
{
	//return (uint16_t)mode_bttn_state;
	return mode_bttn_state;
}

UINT8 set_op_mode_bttn_value(UINT16 value)
{
	UINT8 error = NO_ERROR;
	mode_bttn_state_ck = value;	
	return error;
}

UINT16 get_engine_run_time(void)
{
	//return engine_run_timer;
	return read_eeprom_word(ENGINE_RUNTIME_START);
}
UINT8 set_engine_run_time(UINT16 value)
{
    UINT8 error = NO_ERROR;
    engine_run_timer = value;
    write_eeprom_word(ENGINE_RUNTIME_START,engine_run_timer);
    return error;
}

UINT16 get_engine_oil_time(void)
{
	return read_eeprom_word(ENGINE_OILTIME_START);
}

UINT8 set_engine_oil_time(UINT16 value)
{
	UINT8 error = NO_ERROR;
	engine_oil_timer = value;	//the value should be 0 only reset oil timer.
	write_eeprom_word(ENGINE_OILTIME_START,engine_oil_timer);
	return error;
}

UINT16 get_machine_run_time(void)
{
	return read_eeprom_word(MACHINE_RUNTIME_START);
}
	
UINT8 set_evap_fan_speed(UINT16 value)
{
	UINT8 error = NO_ERROR;
	evap_fan_speed = (BYTE)value;
	write_eeprom_byte(EE_EVAP_FAN_SPEED,evap_fan_speed);
	return error;
}

UINT16 get_evap_fan_speed(void)
{
	return (UINT16)evap_fan_speed;
}


UINT8 set_temp_setting(UINT16 value)
{
	UINT8 error = NO_ERROR;
	clmt_temp_setting = value;
	write_eeprom_word(EE_CLIMATE_TEMP_SETTING, value);
	return error;
}
		
UINT16 get_temp_setting(void)
{
	return clmt_temp_setting;
}

UINT8 set_battery_setting(UINT16 value)
{
	UINT8 error = NO_ERROR;
	batt_monitor_setting = value;
	write_eeprom_word(EE_MONITOR_BATT_SETTING, value);  //save it
	return error;
}
			
UINT16 get_battery_setting(void)
{
	return batt_monitor_setting;
}


UINT8 	set_storage_temp(UINT16 value)
{
	UINT8 error = NO_ERROR;
	storage_t_setting = value;
	write_eeprom_word(EE_STORAGE_TEMP_SETTING, value);
	return error;
}
UINT16 	get_storage_temp(void)
{
	return storage_t_setting;
}

UINT8 	set_storage_volt(UINT16 value)
{
	UINT8 error = NO_ERROR;
	storage_v_setting = value;
	write_eeprom_word(EE_STORAGE_BATT_SETTING, value);
	return error;
}
UINT16 	get_storage_volt(void)
{
	return storage_v_setting;
}

UINT8  set_temperature_unit(UINT16 value)
{
	UINT8 error = NO_ERROR;
	temperature_unit = (BYTE)value;
	write_eeprom_byte(EE_TEMP_UNIT,temperature_unit);
	return error;
}
	
UINT16	get_temperature_uint(void)
{
	return temperature_unit;
}

UINT8 set_oil_state(UINT16 value)
{
	UINT8 error = NO_ERROR;
	oil_state = (BYTE)value;
	return oil_state;
}

UINT16  get_oil_state(void)
{
	return (uint16_t)oil_state;
}

UINT8 set_error_state(UINT16 value)
{
	UINT8 error = NO_ERROR;
	error_state = (BYTE)value;
	return error;
}

UINT16 get_error_state(void)
{
	return (uint16_t)error_state; 
}


UINT16 get_oil_pressure(void)
{
	return (uint16_t)discrete_inputs[OIL_PRESSURE].debounced_state;
}

UINT16 get_truck_engine_state(void)
{
	return (uint16_t)discrete_inputs[TRUCK_ENGINE_STATE].debounced_state;
}

UINT16 get_engine_rpm_portstate(void)
{
	return (uint16_t)Engine_RPM_State ;
}

UINT16 get_engine_status(void)
{
	return (UINT16)engine_op_status;
}

UINT16 get_control_status(void)
{
	return (UINT16)control_status;
}
	


UINT8 	set_clnd_start_state(UINT16 value)
{
	UINT8 error = NO_ERROR;
	write_eeprom_byte(EE_CLND_START_ONOFF,(BYTE)value);
	return error;
}	

UINT16	get_clnd_start_state(void)
{
	return (UINT16)read_eeprom_byte(EE_CLND_START_ONOFF);
}

UINT8 	set_clnd_start_mode(UINT16 value)
{
	UINT8 error = NO_ERROR;
	write_eeprom_byte(EE_CLND_START_MODE,(BYTE)value);
	return error;
}	
UINT16	get_clnd_start_mode(void)
{
	return (UINT16)read_eeprom_byte(EE_CLND_START_MODE);
}

UINT8 	set_clnd_start_year(UINT16 value)
{
	UINT8 error = NO_ERROR;
	write_eeprom_byte(EE_CLND_START_YEAR,(BYTE)value);
	return error;
}	
UINT16	get_clnd_start_year(void)
{
	return (UINT16)read_eeprom_byte(EE_CLND_START_YEAR);
}

UINT8 	set_clnd_start_month(UINT16 value)
{
	UINT8 error = NO_ERROR;
	write_eeprom_byte(EE_CLND_START_MONTH,(BYTE)value);
	return error;
}	
UINT16	get_clnd_start_month(void)
{
	return (UINT16)read_eeprom_byte(EE_CLND_START_MONTH);
}

UINT8 	set_clnd_start_date(UINT16 value)
{
	UINT8 error = NO_ERROR;
	write_eeprom_byte(EE_CLND_START_DATE,(BYTE)value);
	return error;
}	
UINT16	get_clnd_start_date(void)
{
	return (UINT16)read_eeprom_byte(EE_CLND_START_DATE);
}

UINT8 	set_clnd_start_hour(UINT16 value)
{
	UINT8 error = NO_ERROR;
	write_eeprom_byte(EE_CLND_START_HOUR,(BYTE)value);
	return error;
}	
UINT16	get_clnd_start_hour(void)
{
	return (UINT16)read_eeprom_byte(EE_CLND_START_HOUR);
}

UINT8 	set_clnd_start_min(UINT16 value)
{
	UINT8 error = NO_ERROR;
	write_eeprom_byte(EE_CLND_START_MIN,(BYTE)value);
	return error;
}
		
UINT16	get_clnd_start_min(void)
{
	return (UINT16)read_eeprom_byte(EE_CLND_START_MIN);
}

UINT8 	set_clnd_start_ampm(UINT16 value)
{
	UINT8 error = NO_ERROR;
	write_eeprom_byte(EE_CLND_START_AMPM,(BYTE)value);
	return error;
}	
	
UINT16	get_clnd_start_ampm(void)
{
	return (UINT16)read_eeprom_byte(EE_CLND_START_AMPM);
}

UINT8  set_standby_override_flag(UINT16 value)
{
	UINT8 error = NO_ERROR;
	//error_state = (BYTE)value;
	stand_by_overide_flag = (BYTE)value;
	return error;
}

UINT16 get_standby_override_flag(void)
{
	return (UINT16)stand_by_overide_flag;
}

UINT16 get_temperature_dspl_state(void)
{
	return (UINT16)temp_dspl_state;
}

UINT8 set_vref_calibration(UINT16 value)
{
	UINT8 error = NO_ERROR;
	vref_calibration = value;
	write_eeprom_word(EE_VREF_CALIBRATION, value);  //save it
	return error;
}

UINT16 get_vref_calibration(void)
{
	return vref_calibration;
}

UINT8 set_temp_calibration(UINT16 value)
{
	UINT8 error = NO_ERROR;
	temperature_calibration = value;
	write_eeprom_word(EE_TEMP_CALIBRATION, value);  //save it
	return error;
}
			
UINT16 get_temp_calibration(void)
{
	return temperature_calibration;
}

UINT16 get_engine_rpm(void)
{
	return rpm_average;	//rpm_engine;
}


UINT16 get_relay_fmwr_rev(void)
{
	return relay_fmwr_rev;
}

UINT8 set_dspl_fmwr_rev(UINT16 value)
{
	UINT8 error = NO_ERROR;
	dspl_fmwr_rev = value;
	return error;
}

UINT16 get_dspl_fmwr_rev(void)
{
	return dspl_fmwr_rev;
}

UINT16 get_prd_test_mode(void)
{
	return product_test_mod_enabled;
}


UINT8 set_rtcc_year(UINT16 value)
{
	UINT8 error = NO_ERROR;
	rtcc_mod_year = value;
	return error;
}
UINT16 get_rtcc_year(void)
{
	return rtcc_mod_year;
}

UINT8 set_rtcc_month(UINT16 value)
{
	UINT8 error = NO_ERROR;
	rtcc_mod_month = value;
	return error;
}
UINT16 get_rtcc_month(void)
{
	return rtcc_mod_month;
}

UINT8 set_rtcc_day(UINT16 value)
{
	UINT8 error = NO_ERROR;
	rtcc_mod_day = value;
	return error;
}
UINT16 get_rtcc_day(void)
{
	return rtcc_mod_day;
}

UINT8 set_rtcc_weekday(UINT16 value)
{
	UINT8 error = NO_ERROR;
	rtcc_mod_weekday = value;
	return error;
}
UINT16 get_rtcc_weekday(void)
{
	return rtcc_mod_weekday;
}

UINT8 set_rtcc_hour(UINT16 value)
{
	UINT8 error = NO_ERROR;
	rtcc_mod_hour = value;
	return error;
}
UINT16 get_rtcc_hour(void)
{
	return rtcc_mod_hour;
}

UINT8 set_rtcc_minute(UINT16 value)
{
	UINT8 error = NO_ERROR;
	rtcc_mod_minute = value;
	return error;
}
UINT16 get_rtcc_minute(void)
{
	return rtcc_mod_minute;
}

UINT8 set_rtcc_second(UINT16 value)
{
	UINT8 error = NO_ERROR;
	rtcc_mod_second = value;
	return error;
}
UINT16 get_rtcc_second(void)
{
	return rtcc_mod_second;
}

UINT8 set_highac_override_flag(UINT16 value)
{
	UINT8 error = NO_ERROR;
	//error_state = (BYTE)value;
	high_ac_overide_flag = (BYTE)value;
	return error;
}		
UINT16 get_highac_override_flag(void)
{
	return (UINT16)high_ac_overide_flag;
}
		
UINT8 set_lowac_override_flag(UINT16 value)
{
	UINT8 error = NO_ERROR;
	//error_state = (BYTE)value;
	low_ac_overide_flag = (BYTE)value;
	return error;
}		
UINT16 get_lowac_override_flag(void)
{
	return (UINT16)low_ac_overide_flag;
}


UINT8 set_RTC_ID_flag(UINT16 value)
{
    UINT8 error = NO_ERROR;
    rtcc_ee_read_id = value;
    return error;
}
			
UINT16 get_RTC_ID_flag(void)
{
    return rtcc_ee_read_id;
}

