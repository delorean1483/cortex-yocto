/***************************************************************************
* File: main.c
* Description: Source code file for IO application on Parks Industries
* Microcontroller: Microchip PIC18F46K22
* ToolSet: Microchip xc8 v1.10
* IDE: MPLAB X v5.10
* Author: Jintao Huang
*******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
******************************************************************************
***************************************************************************** 
* bootloader code + application code = 80010902
* About application  code
* 1.With Bootloader added. 
*	Project->Built options:
*	Linker, Codeoffset: 0x3700 
*	Global, Rom ranges: default,-0000-36FF
* 2.ICD settings allow ICD 3 select memories and range,
*	preserve program memory range from 0 to 0x36FF
* 3.All interrupts priority levels are set to high priority in application
*
******************************************************************************
******************************************************************************
* A note about the high side and low side AC pressure
* Due to the historic reason, the high AC pressure and low AC pressure were  
* swapped in schematics, application and display code. 
******************************************************************************
******************************************************************************
* Release notes --- Application :
******************************************************************************
* high side and low side AC pressure is switched in the code from wiring
******************************************************************************
* 2.01  Only high side refrigerant pressure was used in the first release. 
* 2.02  1. fixed small fonts has on negative sign issue
*       2. added flag2  bit1 and bit2 
* Test1.09 
*	    1. Added low side AC pressure error check code(actually it is high side 
*		   ac pressure)	
*		2. added RPM reading, RPM error and anti_stall detection
*		3. added external temperature sensor reading and different glow plug on 
*          time according the different external temperature.
* Test1.10
*		1. added six available selections for evaporator speed. 
* Test1.11
*		1. changed external temperature sensor to Kohler engine's built-in 
*		   thermistor.the temperature table was generated from Kohler's Manual
*		2. changed glow plug energized time according to the Kohler's table
*		3. changed the RPM low limit to 1000
*		4. changed the time of detected battery low voltage (CC_LOW_V_LIMIT)
*		   to 30min 
*		5. changed the allowed failure count on high side pressure to 
*		   10(refrigerant_check_counter)  
*		6. changed the offset of clmt_temp_setting on start/stop heating/cooling 
*          search for clmt_temp_setting for details
*		7. added function CabTempAdjustment() and related code to 
*		   compensate cab temperature. //10/17/2013`
*		8. added read firmware Rev. and set RTCC by modbus  1/3/2014
* Test1.12
*		1. changed reengage time of compressor (compressor_off_timer) 
*		   from 30s to 15s
*		2. changed the glow plug run time to the up end of the recommended
*		   range,ln1261-1288
*		3. added detected RPM being low for 10s to report an error ln1780-1794
*		4. changed starter engage time to 3s.ln1323
*		5. changed delay 10s to check oil_pressure after starter is off ln1336
*		6. added 5s glow plug post-heat when external temp is lower than 122�F
*		   after starter is off.ln 1332-1345
*		7. made Cold Storage mode active off of Coolant temp(external_temperature)
*		   instead of cabin_temperature ln2028-2041 and ln2166-2181
*		8. averaged rpm_engine value(rpm_average) at do_2s() routine ln899-910.
*		9. changed external coolant temp table to Kohler engine's data sheet T2, 
*		   display range -4�F to 248�F
*		10.high pressure error allows for endless retries(recorded at event log).
*		   Fan and reversing valve kept unchanged during high pressure retries.
*		   ln1752-1756
*		   if high pressure reoccurrence within 3s of compressor reengage, then
*	       error of "High pressure fail"(screen). ln1566-1573
*		11.Low pressure error allows for 10 retries ln1553-1563. 
*		   error of "Low pressure fail"(screen). 
*Test1.13 
*		1. same as test 1.12. because display updated. keep the same revision  
*Test1.14  1/24/2014
*		1. moved the average rpm to 1s routine and average every 5 samples
*       2. high/low ac pressure failure state will go back and retry the process 
*	       after the failure was overridden.ln2424-2465  
*	    3. low battery detect changed to 10min instead of 30min at climate control
*		   mode
*       4. changed the 30mins charging cycles to three in battery monitor mode ln1938
* 	 	5. changed STORAGE_T_INIT default to 30
*		6. changed the offset of clmt_temp_setting on start/stop heating/cooling
*		   to a defined constant CC_TEMP_OFFSET=2 instead of 3 
*Test1.15  4/23/2014
*		1. added define use_24vdc_battery at main.h     
*Test1.16  4/29/2014		
*		1. added  battery setting boundaries definition in main.h ln29-34, ln44-48
*		2. added battery setting boundary checking code in InitFactorySettings()
*		4/30/2014
*		3. changed High side pressure detection process.  added ln1787-1800. ln 2325-2332 
*Test1.17 5/13/2014
*        No change from test1.16	
*Test1.19 10/2/2014
*       1. added a modbus register HR_DSPL_EXT_TEMP_ADC to read adc raw reading for
*          production test 
*          The same rev of display firmware changed to new Orient display.  
*Test1.20	12/15/2014 change requested by Cam phone call on 12/12/2014
*		   when high side pressure error happens, do not record the error in the log
*          and do not display high pressure failure screen. 
*		1. search 12-15-2014 to see the changes
*1.20   12/17/2014 
*       1. no change on IO code.  
*1.21  1/12/2015  --- released rev. 80010902B
* 		1. added initialize pwm at lines 391,392
*		2. high side pressure debounce time changed to 100ms ln632
*		3. added line1874,1869 turn off compressor 
*		4. changed the high_side_p/low_side_p readings to average to 2
*       5. Cold storage mode: added running engine only when external coolant 
*          temperature is available to read.ln2178-2182, ln2368-2377
*       6. added 50ms delay before r/w eeprom,PWRTEN = ON
*1.22  5/05/2015
*		1. added code for spare output pin13(B7)of J6.ln555-ln560
*		   it connects to a LED as a indicator of battery monitor mode and 
*	       code storage mode
*1.23  6/15/2015
*		1. add ln781-793, turn off evap fan whenever engine is off
*       2. remove No RPM code,ln1485-1490,ln1925-1929,ln2085-2089,ln2471-2475
*		3. remove low rpm anti_stall code. ln1822-1835,ln1878-1897
*                                          ln2370-2384,ln2431-2450
*		4. change evaporator delay time to 3s ln1620,1855,2245,2398
*1.24  6/18/2015 --released rev. 80010902C
*       1. The machine seems having evaporator initial starting issue, 
*          force evap running for 10s whenever evap_on is called.
*          search EVAP_FORCED_ON_TMR.
*		2. COMP_EVAP_DELAY_TMR to 0.
*1.25  7/01/2016 --no change on IO control. changes are on display
*1.26  1/27/2017-
*       1. changed CC_TEMP_OFFSET to 3 instead of 2. main.h ln70
*       2. created a macro HEAT_COOL_TRANS_TIME at main.h ln71 for the waiting
*          time of transfer from cool to heat or from heat to cool
*       3. changed the HEAT_COOL_TRANS_TIME to 30s instead of 5s  
*          at ln1587 and ln1609 
*1.27 8/02/2017- release rev. 80010902D
*       1. set CC_TEMP_OFFSET = 2,HEAT_COOL_TRANS_TIME = 500 
*          This is the same as rev1.24. because customer did not approve 1.26. 
*1.28 10/09/2017-release rev. 80010902E
*       1. set  CC_TEMP_OFFSET = 3,HEAT_COOL_TRANS_TIME = 3000
*          This is the same as rev1.26. 
*1.30 11/19/2018-release rev. 80010902F
*       1. changed  HEAT_COOL_TRANS_TIME = 6000, 60seconds    
*       2. eliminated LOW and L_ALWAYS of evap_fan_speed and 
*          commended out related code 
*       3. deleted cold storage button and commented out related code
 *1.31 4/11/2019 --released rev.80010902G
 *      1. removed heat mode on and lengthened starter on time to 10s 
 *         in engine start mode
 *      2. increased mode switch time. 
 * 1.32 1/3/2020 -- released rev. 80010902H
 *      1. decrease the engine start time from 10s to 4s.ln1434 
 * 1.33 3/30/2020
 *      1. defrost mode, eliminated reversing valve in cool mode
 *      2. increased defrost time to 60s.
 *      3. eliminated energizing reversing valve in engine start mode
 *      4. engine start time 4s is for Perkins engine
 * 1.34 4/1/2020
 *      1. all 1-3 changes of v1.33
 *      1. increased the engine start time from 4s to 8s for Kubota units. ln1441
 * 1.35 9/21/2020--released rev. 80010902J
 *      1. added to turn off evap fan when defrost mode starts
 *      2. added to turn evap fan back on when defrost mode ends
 *      3. decreased defrost mode time to 45s from 60s
 *      4. when temperature satisfies with setpoint, the waiting time
 *         from compressor off to evap fan off decreased to 15s from 60s
 *      5. the engine start time changed to 4s for Perkins engine
 * 1.36 9/21/2020
 *      1. all 1-4 changes of v1.35
 *      2. the engine start time changed to 8s for Kubota units. ln1453
 *         This rev is generated for customer only. it's not for our production.
 * 1.37 6/23/2021--released rev.
 *      1. the engine start time is 4s for Perkins engine -line1456
 *      2. display changed temperature range to 50-85 from 60-85
 * 1.38 8/31/2022 -- released 80010902K
 *      1. blower settings: remove medium_always and high_always, add back low,
 *         medium, high
 * 1.39 12/15/2022 -- released 80010902L
 *      1. this rev. code works with new Rev. 6513F boards(RTC changed to MCP79410)
 *         and old 6513E boards
 *      2. added a MODBUS register HR_RTC_EE_FLAG to read MCP79410 EEPROM's
 *         content of address 0x00.
******************************************************************************/

/** C O N F I G U R A T I O N   B I T S **************************************/
//TO SEE WHAT THESE SETTINGS SHOULD BE GO TO:
//HELP->TOPICS->PIC18 CONFIG SETTINGS, THEN SELECT THE CORRECT PART AND
//YOU WILL BE ABLE TO SEE THE LIST OF ALL THE SETTING FOR THE SPECIFC PART :)
//PLLCFG=OFF -> oscillator used directly 
#pragma config FOSC = HSMP, PLLCFG = ON, PRICLKEN = ON, FCMEN = OFF, IESO = OFF // CONFIG1H 
#pragma config PWRTEN = ON, BOREN = NOSLP, BORV = 190                       	// CONFIG2L 
#pragma config WDTEN = ON, WDTPS = 32768                                    	// CONFIG2H WDTPS = 32768,WDT reset is 2min
#pragma config /*MCLRE = EXTMCLR, */ PBADEN = OFF, CCP2MX = PORTC1				// CONFIG3H WDTEN = ON,
#pragma config STVREN = ON, LVP = OFF, XINST = OFF, DEBUG = OFF            	 	// CONFIG4L 
#pragma config CP0 = OFF, CP1 = OFF, CP2 = OFF, CP3 = OFF                   	// CONFIG5L
#pragma config CPB = OFF, CPD = OFF                                         	// CONFIG5H
#pragma config WRT0 = OFF, WRT1 = OFF, WRT2 = OFF, WRT3 = OFF              		// CONFIG6L
#pragma config WRTB = OFF, WRTC = OFF, WRTD = OFF                           	// CONFIG6H
#pragma config EBTR0 = OFF, EBTR1 = OFF, EBTR2 = OFF, EBTR3 = OFF           	// CONFIG7L
#pragma config EBTRB = OFF                                                  	// CONFIG7H

/** I N C L U D E S **********************************************************/

#include "include_all.h"

/******************************************************************************
*	Global Variable Definitions
******************************************************************************/

UINT16 relay_fmwr_rev = 143;  //update it at every new release

UINT16 dspl_fmwr_rev; //it will be loaded at power up by modbus

UINT16 divide_for_10ms;
UINT16 divide_for_50ms;
UINT16 divide_for_100ms;
UINT16 divide_for_1second;
UINT16 divide_for_5second;
UINT16 divide_for_1minute;

UINT16 one_ms_timer[NUM_ONE_MS_TIMER];
UINT16 ten_ms_timer[NUM_TEN_MS_TIMER];
UINT16 one_hundred_ms_timer[NUM_100_MS_TIMER];
UINT16 one_second_timer[NUM_ONE_SECOND_TIMER];
UINT16 one_minute_timer[NUM_ONE_MINUTE_TIMER];

UINT16 engine_run_timer=0;
UINT16 engine_oil_timer=0;
UINT16 machine_run_timer=0;

bittype flag0=0,flag1=0,flag2 = 0;
discrete_input_t discrete_inputs[NUMBER_OF_INPUTS];

BYTE compressor_on_timer = 0;
BYTE compressor_off_timer=0; 
BYTE glow_plug_on_timer=0;
BYTE starter_on_timer=0;

op_type op_state = 0,op_state_previous = 0;

BYTE state=0,engine_start_state=0;
BYTE error_state=0;
BYTE oil_state=0;  

BYTE engine_op_status = 0;
BYTE control_status = 0;
BYTE temp_dspl_state = 0;

BYTE mode_bttn_state=0;
BYTE mode_bttn_state_ck = 0;
BYTE evap_fan_speed=0;
BYTE temperature_unit=0;

BYTE i;

BYTE attempted_start_counter=0;
BYTE attempted_charging_counter=0;
BYTE refregerant_check_counter=0;

UINT16 vref_calibration;
signed int temperature_calibration;

signed int user_temp_adjustment;	//1/10/2014

BYTE cab_temp_offset = 0;		//10/17/2013

UINT16	cabin_temperature=0;
UINT16	engine_temperature=0;
INT16	external_temperature=0 ;
UINT16	low_side_pressure=0;
UINT16	high_side_pressure=0;
UINT16	battery_voltage=0; 
UINT16  ext_temp_adcreading=0;

UINT16 batt_monitor_setting=0;  //needs to be initialized 
UINT16 clmt_temp_setting=0;  //needs to be initialized
UINT16 storage_t_setting=0;	 //needs to be initialized
UINT16 storage_v_setting=0;	 //needs to be initialized

UINT16 batt_setting_storage=0;
UINT16 temp_setting_storage=0;

BYTE stand_by_overide_flag = 0;
BYTE high_ac_overide_flag = 0;
BYTE low_ac_overide_flag = 0;

BYTE product_test_mod_enabled = 0;

//read engine RPM
UINT16 leading,capture;
UINT16 freq, rpm_engine;
BYTE  cap_entry;

WORD cabin_accum;
char cabin_count;
WORD cabin_average;
WORD cabin_data[8];

UINT16 rpm_data[8];
char rpmDataCount;
UINT16 rpm_average;
UINT32 rpm_accum;

BYTE ext_temp_sensor_state;
/******************************************************************************
*	Function Prototypes
******************************************************************************/

//void InterruptHandler (void);

/** V E C T O R  R E M A P P I N G *******************************************/
//On PIC18 devices, addresses 0x00, 0x08, and 0x18 are used for
//the reset, high priority interrupt, and low priority interrupt
//vectors.  However, the bootloader will occupy these addresses 
//therefore, the bootloader code remaps these vectors to new locations
//as indicated below.

/****** Remapped Vectors ********************
       _____________________
       |       RESET       |   0x000000
       |      LOW_INT      |   0x000008
       |      HIGH_INT     |   0x000018
       |       TRAP        |   0x000028
       |     Bootloader    |   0x00002E
       .                   .
       .                   .
       |     USER_RESET    |   0x003700
       |    USER_LOW_INT   |   0x003708
       |    USER_HIGH_INT  |   0x003718
       |      USER_TRAP    |   0x003728
       |                   |
       |   Program Memory  |
       .                   .
       |___________________|   0x000FFFF
**********************************************/
///#define REMAPPED_RESET_VECTOR_ADDRESS			0x3700
///#define REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS	0x3708
///#define REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS	0x3718

///extern void _startup (void);        //See c018i.c in the C18 compiler dir

///#pragma code REMAPPED_RESET_VECTOR = REMAPPED_RESET_VECTOR_ADDRESS

///void _reset (void)
///{
///	_asm
///		goto _startup
///	_endasm
///}

//Removed since high interrupts are used in the bootloader for timing and communication
//#pragma code REMAPPED_HIGH_INTERRUPT_VECTOR = REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS
//void Remapped_High_ISR (void)
//{
//	_asm
//		goto InterruptHandler       //Jump to interrupt routine
//	_endasm
//}

///#pragma code REMAPPED_LOW_INTERRUPT_VECTOR = REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS
///void Remapped_Low_ISR (void)
///{
///	_asm
///		goto InterruptHandler       //Jump to interrupt routine
///	_endasm
///}

//If the output hex file is not programmed with
//the bootloader, addresses 0x08 and 0x18 would end up programmed with 0xFFFF.
//As a result, if an actual interrupt was enabled and occured, the PC would jump
//to 0x08 (or 0x18) and would begin executing "0xFFFF" (unprogrammed space).  This
//executes as nop instructions, but the PC would eventually reach the REMAPPED_RESET_VECTOR_ADDRESS
//and would execute the "goto _startup".  This would effective reset the application.

//To fix this situation, we should always deliberately place a 
//"goto REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS" at address 0x08, and a
//"goto REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS" at address 0x18.  When the output
//hex file of this project is programmed with the bootloader, these sections do not
//get bootloaded (as they overlap the bootloader space).  If the output hex file is not
//programmed using the bootloader, then the below goto instructions do get programmed,
//and the hex file still works like normal.  The below section is only required to fix this
//scenario.	
/*
#pragma code HIGH_INTERRUPT_VECTOR = 0x08
void High_ISR (void)
{
	_asm
		goto REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS
	_endasm
}

#pragma code LOW_INTERRUPT_VECTOR = 0x18
void Low_ISR (void)
{
	_asm
		goto REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS
	_endasm
}
*/

#if(0)
#pragma code high_vector = 0x08   //0x002008
void interrupt_at__high_ISR (void)
{
    _asm
        goto InterruptHandler       // jump to interrupt routine
    _endasm
}

#pragma code low_vector = 0x18      //0x002018
void Interrupt_at_low_vector (void)
{
    _asm
        goto InterruptHandler       // jump to interrupt routine
    _endasm
}
#endif
// (0xF0,0x01,0xFD,0xFF,0x00,0x00,0x00,0x00)   496 = 0x01F0, -3 = 0xFFFD,
//__EEPROM_DATA(0xF7,0x00,0x00,0x00,0x00,0x00,0x00,0x00);  // 00--Vref, 02-temp_calibration

/** D E C L A R A T I O N S **************************************************/

void main(void)
{
	InitializeTimerDivides();
	InitializeSystem();


	InitFactorySettings();

	op_state = POWER_UP_STATE;
	state = 0;
	while(1)
	{
		MB_Display_ProcessModbus((MODBUS_SERVER_t*) &MB_SERVER_DISPLAY);
		//MB_Display_ProcessModbus((MODBUS_SERVER_t*) &MB_SERVER_RS232);  //RS232 will share timer, registers with RS485
		MB_RS232_ProcessModbus((MODBUS_SERVER_t*) &MB_SERVER_RS232);

		CheckTimerInterrupts();  //timer based tasks
		if(product_test_mod_enabled != 0xAA)
		{
			StateMachine();
			UpdateOutputs();
		}
		BackGroundTasks();
		Refresh_TRIS();
		CLRWDT();
		//cabin_temperature = Read_ADC(7);//debug
	}
	
}//end of main()

void InitializeTimerDivides(void)
{
	divide_for_10ms = DIVIDE_FOR_10MS;
	divide_for_50ms = DIVIDE_FOR_50MS;
	divide_for_100ms = DIVIDE_FOR_100MS;	
	divide_for_1second = DIVIDE_FOR_1SECOND;
	divide_for_5second = DIVIDE_FOR_5SECOND;
	divide_for_1minute = DIVIDE_FOR_1MIN;

	one_ms_timer[EVAP_PWM_PERIOD_TMR] = 0;		//12/22/14
	one_ms_timer[EVAP_PWM_ON_TMR] = 0;			//12/22//14
}

/**************************************************************
 * Function: InitializeSystme()
 * T1: General 1ms timer. 
 * T2: RS485 modbus timer. 
 * T4: RS232 modbus timer. 
 * T5: CCP2 module Capture mode timer. 1Mhz free running	
***************************************************************/
void InitializeSystem(void)
{
	//Set the oscillator
	OSCCONbits.SCS = 0;	//Set to primary clock,determined by CONFIG1H

	//Configure the TRIS: 1 for input, 0 for output
	PORTA = 0x00;	//clearing output
	LATA = 0x00;	// clear output data latches
	ANSELA = 0x2F;	//setting RA5,RA<3:0> as analog. 1-analog, 0-digital
	TRISA = 0xFF;	//set all pins as inputs

	PORTB = 0x00;	//clearing output data latches
	LATB = 0x00;	//same as the one before-alternate
	ANSELB = 0x00;	//all pins as digital I/O
	TRISB = 0xF7;	//RB3 is output. The rests are input
	
	PORTC = 0x00;	//clearing output
	ANSELC = 0x00;	//all pins are digital
	TRISC = 0xC3;	//RC0-open,digital-I, RC1,Input,RC2-5 digital-O. RC6-7,TX1/RX1,
					//RC2 is CCP1-Evap PWM output
		
	PORTD = 0x00;	//clearing output
	ANSELD = 0x00;	//all are digital pins
	TRISD = 0xC0;	//RD<0,5> - digital output,RD6-7 TX2/RX2
	
	PORTE = 0x00;	//clearing output
	ANSELE = 0x07;  // RE<0,2>analog input
	TRISE = 0x0F;	//RE<0,3> input

	/*ADC initializtion*/
	//ADCON1 = 0x00;        //vref-=Vss, Vref+ = Vdd,
	ADCON1 = 0x04;   //0b00000100 vref-=Vss,Vref+=external pin
	ADCON2 = 0xBE;        //right justified, 20Tad, Fosc/64

    //Timer1 initializtion -- 1ms general timer
    //T1CON = 0b00110011;	//Fosc=8M,timer1 is always counting,11-1:8 prescale,internal Fosc/4,enable timer1.   
    T1CONbits.T1RD16 = 1;  	//enable 16bit mode
	T1CONbits.T1CKPS1 = 1;	//Prescale = 1:8
    T1CONbits.T1CKPS0 = 1;
	T1CONbits.TMR1CS1 = 0;	//Use the instruction clock (FOSC/4)
    T1CONbits.TMR1CS0 = 0;
    T1CONbits.TMR1ON =  1;  //TMR1 on       
    
	  //if FOSC=4x8M=32M. 0xD8F0+9999 = 0xFFFF; 10ms
	  //if Fosc=4x8M=32M, 0xFC18+999 = 0xFFFF; 1ms
//	TMR1H = 0xFF;  //Fosc = 8MHZ, 0xFF06+250 =0xFFFF--1ms
//	TMR1L = 0x0A;   //0xFF0A works better for 1ms interrupt
	TMR1H = 0xFC;  //Fosc = 32MHZ, 0xFC18+999 = 0xFFFF, 1ms
	TMR1L = 0x18; 
    IPR1bits.TMR1IP = 1;  	//TMR1 high priority     
    PIE1bits.TMR1IE = 1;  	//enable timer1 overflow interrupt of PIE1 ;

	InitializeCCP_CaptureMode();  //define CCP2 Capture mode. read RPM 

	MB_Display_InitializeModbus((MODBUS_SERVER_t*) &MB_SERVER_DISPLAY,0x01);
	MB_RS232_InitializeModbus((MODBUS_SERVER_t *) &MB_SERVER_RS232, 0x02);


	RCONbits.IPEN = 0x01;   //Enable priority levels
	INTCONbits.GIEH = 1;    //Enable high priority interrupts
	INTCONbits.GIEL = 1;    //Enable low priority interrupts

	//test only
	mode_bttn_state = OFF_MODE;
	evap_fan_speed = HIGH;
	error_state = NO_OP_ERROR;
	
	for(i=0; i<NUM_TEN_MS_TIMER; i++)		
		ten_ms_timer[i] = 0;

	for(i=0; i<NUM_100_MS_TIMER; i++)		
		one_hundred_ms_timer[i] = 0;

	for(i=0; i<NUM_ONE_SECOND_TIMER; i++)
		 one_second_timer[i] = 0;

	for(i=0; i<NUM_ONE_MINUTE_TIMER; i++)
		one_minute_timer[i] = 0;

	analog_data[INDEX_CABIN_TEMP].avg_accum = 0;
	analog_data[INDEX_CABIN_TEMP].avg_count = 0;

	analog_data[INDEX_BATTERY_V].avg_accum = 0;
	analog_data[INDEX_BATTERY_V].avg_count = 0;

	InitializeSwitchObjects();
	
}

void Refresh_TRIS(void)
{	
	ANSELA = 0x2F;	//setting RA5,RA<3:0> as analog. 1-analog, 0-digital
	TRISA = 0xFF;	//set all pins as inputs
	
	ANSELB = 0x00;	//all pins as digital I/O
	TRISB = 0xF7;	//RB3 is output. The rests are input

	ANSELC = 0x00;	//all pins are digital	
	TRISC = 0xC3;	//RC0-open,digital-I, RC1,Input,RC2-5 digital-O. RC6-7,TX1/RX1,
					//RC2 is CCP1-Evap PWM output
	
	ANSELD = 0x00;	//all are digital pins
	TRISD = 0xC0;	//RD<0,5> - digital output,RD6-7 TX2/RX2
	
	ANSELE = 0x07;  // RE<0,2>analog input
	TRISE = 0x0F;	//RE<0,3> input	
}

void InitializeCCP_CaptureMode(void)
{
	PIE2bits.CCP2IE = 0;	  		// CCP2 interrupt disable
	PIE5bits.TMR5IE = 0;  	  		// disable TMR5 overflow interrupt of PIE5 ;

	TRISCbits.TRISC1 = 1; 			//reassure RC1 is digital input
	//CCP2CON = 0; 					//turn the ccp module off
	//CCP2CONbits.CCP2M = 0b0111;  	//capture mode, every 16th rising edge , f=266--900hz
 	CCP2CONbits.CCP2M = 0b0110;		//capture mode, every 4th rising edge. f=66hz-1000hz
	CCPTMRS0bits.C2TSEL = 0b10 ;		//CCP2 capture/compare modes use timer5.
	PIR2bits.CCP2IF = 0;  	  		//clear to avoid false interrupt/flag 

	PIE2bits.CCP2IE = 0;	  		// CCP2 interrupt disable or enable 
	//IPR2bits.CCP2IP = 1; 	  		// CCP2 high priority interrupt

	T5CONbits.T5RD16 = 1;  	  		// enable 16 bits mode
	T5CONbits.TMR5CS = 0b00;  		// in order to make capture mode to recognize the trigger event on 
									// theCCP2 pin, have to use the instruction clock Fosc/4 = 8Mhz
	T5CONbits.T5CKPS = 0b11;  		// prescale = 1:8, so f=1Mhz and T=1us
	TMR5H = 0;
	TMR5L = 0;
	PIR5bits.TMR5IF = 0; 			//clear to avoid false interrupt/flag

	PIE5bits.TMR5IE = 0;  	  		// disable or enable  TMR5 overflow interrupt of PIE5 ;
	//IPR5bits.TMR5IP = 1;	  		// TMR5 high priority interrupt
	T5CONbits.TMR5ON =  1;    		// TMR5 on
	
	cap_entry = 0;
}


void BackGroundTasks(void)
{
	ReadEngineRPM();
	CabTempAdjustment(); 
	//spare output pin13(B7)of J6 connected to a LED as a indicator 
 	//if((op_state == BATTERY_MONITOR_STATE)||(op_state == COLD_STORAGE_STATE))
    if(op_state == BATTERY_MONITOR_STATE)
	{
		Spare_Out = ON;
	}
	else 
		Spare_Out = OFF;
	//tested the cycle time 32us	 
}

/********************************************************************************
* Function : ReadEngineRPM()
* Read the signals on every 4th rising edge.  when the tick time was set to 1MHZ,
* The lowest frequency can be detected is around 62.5HZ. f=600hz with 0.2% error
* Parks 375RPM to 3600RPM
*********************************************************************************/

void ReadEngineRPM(void)
{
	UINT32 s_to_us = 1000000;  // second to micro-second convert
	
	if(PIR2bits.CCP2IF ==1)
	{//an capture occurred;
		PIR2bits.CCP2IF = 0;  //reset the flag
		no_rpm_tmr_start_flag = 0;  //clear the engine is not running flag
		switch(cap_entry)
		{
			case 0:				
				//leading = CCPR2L | (CCPR2H << 8) ;
				T5CONbits.TMR5ON =  0;    // TMR5 off
				TMR5H = 0;
				TMR5L = 0;
				PIR5bits.TMR5IF = 0; 	  //clear to avoid false interrupt/flag
				T5CONbits.TMR5ON =  1;    // TMR5 on
				cap_entry++;
			break;

			case 1:				
				if(PIR5bits.TMR5IF == 0)
				{//TMR5 did not overflow
					capture = CCPR2L | (CCPR2H << 8);
					//capture = capture - leading;
					//capture >>= 4;  //divide by 16, get the period in us
					capture >>= 2;  //divide by 4, get the period in us
					freq =(UINT16)(s_to_us/capture);
					if(freq < 62 )	//t=65536us/4,f=1/t= 62hz
					{
						rpm_engine = 360;
					}
					else
					{
						rpm_engine = freq * 6;  //get the RPM 
					}
				}
				else
				{//ignore the reading if TMR5 overflowed to avoid doing more math. 
					PIR5bits.TMR5IF = 0; //clear the overflow flag
				} 
				cap_entry = 0;
			break;

			default:
				cap_entry = 0;
			break;
		}
	}	//end of if(PIR2bits.CCP2IF ==1)
	else
	{
		if(no_rpm_tmr_start_flag == 0)
		{
			no_rpm_tmr_start_flag = 1;
			ten_ms_timer[RPM_STOP_TMR]=100;	//1s
		}
		else
		{
			if(ten_ms_timer[RPM_STOP_TMR]==0)
			{
				rpm_engine = 0;
			}
		}
	}
}

/************************************************************
 *      Initializes several switch objects		      		*
 ***********************************************************/
void InitializeSwitchObjects(void)
{
	BYTE temp_val = 0;

	InitializeSwitch(&discrete_inputs[OIL_PRESSURE],50,temp_val);  //50x10ms, now checkswitches() is 10ms IR
	InitializeSwitch(&discrete_inputs[ENGINE_TEMP],50,temp_val);	//0.5s debounce time
	InitializeSwitch(&discrete_inputs[H_SIDE_PRESSURE],10,temp_val);	//10x10ms debounce time  12-22-14
		//the follow two are comment out
	InitializeSwitch(&discrete_inputs[L_SIDE_PRESSURE],10,temp_val);	//50 debounce time
	InitializeSwitch(&discrete_inputs[TRUCK_ENGINE_STATE],50,temp_val);	//.5ss debounce time
	
}


void InitializeSwitch(discrete_input_t *obj, unsigned int debounce_time, unsigned char current_state)
{
	obj->debounce_time = debounce_time;
	obj->debounce_tmr = debounce_time;
	obj->debounced_state = current_state;
	obj->previous_state = !current_state;
	obj->service_state = SERVICE_NOT_NEEDED;
	obj->hold_timer = 0;
}


//***********************************************************
//	Check Swithces reads the current state of the switch	*
//	and executes the debounce routines		    			*
//***********************************************************
void CheckSwitches(void)
{
	BYTE temp_val = 0;
	temp_val = (Oil_Pressure) ? 0x00 : 0x01;  // GND indicates fault change on 1/8/2013 email
	ServiceSwitch(&discrete_inputs[OIL_PRESSURE], temp_val);
	//next two were commented out 
	temp_val = (Truck_Engine_State) ? 0x00 : 0x01;	//active low circuitry
	ServiceSwitch(&discrete_inputs[TRUCK_ENGINE_STATE], temp_val);	

	//analog readings
	temp_val = (analog_data[INDEX_LOW_SIDE_P].average_value > 200) ? 0x01 : 0x00; //need redefine the limit,use this one if only one requested
	ServiceSwitch(&discrete_inputs[L_SIDE_PRESSURE], temp_val);

	temp_val = (analog_data[INDEX_HIGH_SIDE_P].average_value > 200) ? 0x01 : 0x00;	//loss of GND indicates fault 
	ServiceSwitch(&discrete_inputs[H_SIDE_PRESSURE], temp_val);

	temp_val = (analog_data[INDEX_ENGINE_TEMP].average_value > 200) ? 0x00 : 0x01;	//GND indicates fault --test 1.11
	ServiceSwitch(&discrete_inputs[ENGINE_TEMP], temp_val);

}


//*******************************************************************************
//*	ServiceSwitch() should be called by application every 10ms		*
//*	This function should be passed a pointer to the structure associated 	*
//*	with the switch being processed. The actual state of the switch should	*
//*	be passed to the function as current_pin_state.				*
//*******************************************************************************
void ServiceSwitch(discrete_input_t *obj, BYTE current_pin_state)
{
	if(current_pin_state != obj->previous_state)         	// Checking for stability
	{ // Switch is not stable
		obj->debounce_tmr = obj->debounce_time;
		obj->previous_state = current_pin_state;
		obj->hold_timer = 0;
	}
	else
	{
		if(obj->debounce_tmr)
			obj->debounce_tmr--;  //debouncing defined time, this time was set in Initialize process
		else
		{   // Switch has been stable for debounce time
			if(current_pin_state && !obj->debounced_state)	// Is button still being held?
				obj->service_state = SERVICE_NEEDED;
			obj->debounced_state = current_pin_state;
			if(current_pin_state)
			{     //switch is hold
				if(obj->hold_timer != 0xFFFF)
					obj->hold_timer++;  //count holding time
				obj->release_timer = 0;
			}
			else
			{   //switch is released
				if(obj->release_timer != 0xFFFF)
					obj->release_timer++;   //count releasing time
				obj->hold_timer = 0;
			}
		}
	}
}


/*****************************************************
 * UpdateSwitches() should be called in timer routine,
 * put it in do 50ms now

******************************************************/

void UpdateSwitches(void)
{
	if(mode_bttn_state != mode_bttn_state_ck)
	{
		mode_bttn_state = mode_bttn_state_ck;
		if (mode_bttn_state == OFF_MODE)
		{
		error_state = 0;
		op_state = OFF_STATE;
		op_state = OFF_STATE;
		state = 0;
		}
		else if(mode_bttn_state == CLIMATE_CONTROL_MODE)
		{
			op_state = CLIMATE_CONTROL_STATE;
			//state = 0;
			state = CC_START_SETTLE;
		}
		else if(mode_bttn_state == BATTERY_MONITOR_MODE)
		{		
			op_state = BATTERY_MONITOR_STATE;
			//state = 0;
			state = BM_START;
		}
		
		else
		{
			op_state = OFF_STATE;
			state = 0;
		}
	}
}

//called in while loop.
void UpdateOutputs(void)
{
	//it seems evap has problem at initial starting, force it run 10s whenever evap was called on. 6-18-2015
	
    if((Evaporator_Fan == ON)||one_second_timer[EVAP_FORCED_ON_TMR]) //8-31-2022
	{	//the the Pwm timers whenever the evaporator is set to on
 
		EVAPORATOR_FAN_ON();
        if(one_ms_timer[EVAP_PWM_ON_TMR])
			{
				EVAPORATOR_PWM_ON();			
			}
			else
			{
				if(one_ms_timer[EVAP_PWM_PERIOD_TMR])
				{
					EVAPORATOR_PWM_OFF();			
				}	
				else
				{
					EVAPORATOR_PWM_ON();

					one_ms_timer[EVAP_PWM_PERIOD_TMR] = EVAPORATOR_PWM_PERIOD;
                    if(evap_fan_speed == HIGH)
                    {
						one_ms_timer[EVAP_PWM_ON_TMR] = EVAP_PWM_PULSE_WIDTH_HIGH;
                    }
                    else if(evap_fan_speed == MEDIUM)
                    {
						one_ms_timer[EVAP_PWM_ON_TMR] = EVAP_PWM_PULSE_WIDTH_MEDIUM;
                    }
					else if(evap_fan_speed == LOW)
                    {
						one_ms_timer[EVAP_PWM_ON_TMR] = EVAP_PWM_PULSE_WIDTH_LOW;
                    }
				}
            }
	}
	else
	{
		EVAPORATOR_FAN_OFF();
		EVAPORATOR_PWM_OFF();
	}

	if(Fuel_Pump == ON)	
	{
		FUEL_PUMP_ON();
	}
	else
	{
		FUEL_PUMP_OFF();	
	}
			
 	if(Starter == ON)
	{
		STARTER_ON();
	}
	else
	{
		STARTER_OFF();
	}			
 	if(Compressor_Clutch == ON)
	{
		COMPRESSOR_CLUTCH_ON();
	}
	else
	{
		COMPRESSOR_CLUTCH_OFF();
	}
 	if(Glow_Plug == ON)
	{
		GLOW_PLUG_ON();
	}
	else
	{
		GLOW_PLUG_OFF();
	}
			
 	if(Heat_Mode == ON)
	{
		HEAT_MODE_ON();	
	}
	else
	{
		HEAT_MODE_OFF();
	}
			
 	if(Cool_Mode == ON)
	{
		COOL_MODE_ON();
	}
	else
	{
		COOL_MODE_OFF();	
	}

	if(Spare_Out == ON)
	{
		SPARE_OUT_ON();			
	}
	else
	{
		SPARE_OUT_OFF();
	}
			
}

//*******************************************************************************
//*	CheckTimerInterrupts() Checks timer flags and executes routines		*
//*******************************************************************************
void CheckTimerInterrupts(void)
{	
	if(do_10ms_flag)
		Do_10ms();
	if(do_50ms_flag)
		Do_50ms();
	if(do_100ms_flag)
		Do_100ms();	
	if(do_1second_flag)
		Do_1second();
	if(do_5second_flag)
		Do_5second();
	if(do_1minute_flag)
		Do_1minute();
}


void Do_10ms(void)
{
	BYTE i;
	do_10ms_flag = OFF;
	divide_for_10ms = DIVIDE_FOR_10MS;

	CheckSwitches();  //so the debounce time for switches is 10ms based
	     	      	
	for(i=0; i<NUM_TEN_MS_TIMER; i++)
		if( ten_ms_timer[i] ) 
			ten_ms_timer[i]--;	
}

void Do_50ms(void)
{
	do_50ms_flag = OFF;
	divide_for_50ms = DIVIDE_FOR_50MS;
          	
	if(one_second_timer[POWER_UP_TMR] == 0)
		UpdateSwitches();  //make sure if need this during production test state       
}

void Do_100ms(void)
{
	BYTE i;	
	do_100ms_flag = OFF;
	divide_for_100ms = DIVIDE_FOR_100MS;

	for(i=0; i<NUM_100_MS_TIMER; i++)
		if(one_hundred_ms_timer[i])
			one_hundred_ms_timer[i]--;

	//this channel was commented out
	analog_data[INDEX_LOW_SIDE_P].readings_to_average = 2;  //8
	Read_And_Store_Analog(INDEX_LOW_SIDE_P,LOW_SIDE_P_ANCH);
	//AC pressure
	analog_data[INDEX_HIGH_SIDE_P].readings_to_average = 2;	//8
	Read_And_Store_Analog(INDEX_HIGH_SIDE_P,HIGH_SIDE_P_ANCH);

	analog_data[INDEX_BATTERY_V].readings_to_average = 8;
	Read_And_Store_Analog(INDEX_BATTERY_V,BATTERY_V_ANCH);      	
	
}
void Do_5second(void)  //2s 
{
	do_5second_flag = OFF;
	divide_for_5second = DIVIDE_FOR_5SECOND;

	Read_And_Update_Cabin_Temp(CABIN_TEMP_ANCH);//sample and average
	//the unit of cabin_temperature is F, the convertion to celsius will be in display micro.
	cabin_temperature = (UINT16)Find_Cabin_Temperature();
	cabin_temperature = cabin_temperature - cab_temp_offset;	//10/17/2013

	external_temperature = ReadNTCTemperature();  //get external temperature

}


void Do_1second(void)
{
	BYTE index = 0;
		
	do_1second_flag = OFF;
	divide_for_1second = DIVIDE_FOR_1SECOND;
  	
	// 1sec code
	for(index=0; index<NUM_ONE_SECOND_TIMER; index++)
	{
		if(one_second_timer[index]) 
			one_second_timer[index]--;
	}

	// Compressor needs to be off for a minimum amount of time since it has last ran
	if( COMPRESSOR_STATE == OFF )		
	{                                       // Compressor is OFF
	    compressor_on_timer = 0;
		if(compressor_off_timer < 255)
			compressor_off_timer++;
	}
	else
	{
	    compressor_off_timer = 0;
		if(compressor_on_timer < 255)
			compressor_on_timer++;
	}
	//glow plug is on
	if(GLOW_PLUG_STATE == ON)
	{
		if(glow_plug_on_timer < 255)
			glow_plug_on_timer++;
	}
	else
	{
		glow_plug_on_timer = 0;
	}

	// starter is on
	if(STARTER_STATE == ON)
	{
		if(starter_on_timer<255)
			starter_on_timer++;
	}
	else
	{
		starter_on_timer = 0;
	}

	//temperatures were moved to 5second routine

	analog_data[INDEX_ENGINE_TEMP].readings_to_average = 8;
	Read_And_Store_Analog(INDEX_ENGINE_TEMP,ENGINE_TEMP_ANCH);
	//this channel was commented out
	analog_data[INDEX_EXT_TEMP].readings_to_average = 8;
	Read_And_Store_Analog(INDEX_EXT_TEMP,EXT_TEMP_ANCH);
	
	ReadAnalog();  //get value of battery, high/low side ac pressure
	//=============================================
	//average the rpm value
	rpm_accum += rpm_engine;
	rpmDataCount++;
	if(rpmDataCount >= 5)
	{
		rpm_average = (UINT16)(rpm_accum / 5);
		rpm_accum = 0;
		rpmDataCount = 0;
	}	
	
}

void Do_1minute(void)
{
	BYTE i = 0;
	
	do_1minute_flag = OFF;
	divide_for_1minute = DIVIDE_FOR_1MIN;
	
	// 1 min code
	for(i=0; i<NUM_ONE_MINUTE_TIMER; i++)
		if(one_minute_timer[i]) one_minute_timer[i]--;
	
	// Machine run timer
	machine_run_timer++;
	
	if(machine_run_timer >=60)		// If machine_run_timer equals one hour, increment MACHINE_RUNTIME eeprom variable
	{
		inc_long_term_counter(MACHINE_RUNTIME_START, MACHINE_RUNTIME_END);              
		machine_run_timer = 0;
	}
	
	// Add TIME TO CLEAN MACHINE RUN TIME here, works with machine_run_timer		
	// Engine run timer

	if(FUEL_PUMP_STATE == ON)		// Compressor is ON
	{
		engine_run_timer++;
		engine_oil_timer++;
	}
	if(engine_run_timer >=60)	// If compressor_run_timer equals one hour, increment COMPRESSOR_RUNTIME eeprom variable
	{
		inc_long_term_counter(ENGINE_RUNTIME_START, ENGINE_RUNTIME_END);
		engine_run_timer = 0;
	}
	if(engine_oil_timer >= 60 )
	{
		inc_long_term_counter(ENGINE_OILTIME_START, ENGINE_OILTIME_END);
		engine_oil_timer = read_eeprom_word(ENGINE_OILTIME_START); //use engine oil timer as temporary value holder
        if(engine_oil_timer < HOURS_OIL_CHANGE_SOON) //500hrs
		{ 
			oil_state = OIL_GOOD;
		}
		else if((engine_oil_timer < HOURS_OIL_CHANGE_NOW)&&(one_minute_timer[NEXT_OIL_WARNING_TMR]==0)) //580hrs
		{
			if(oil_state != OIL_WARNING_DISMISSED)
				oil_state = OIL_CHANGE_SOON;	//screen 21,start at 500, warning appears every 20 hrs
			else
			{			
				one_minute_timer[NEXT_OIL_WARNING_TMR] = 1200;
			}
		}
		else if((engine_oil_timer < HOURS_OIL_CHANGE_MISSED)&&(one_minute_timer[NEXT_OIL_WARNING_TMR]==0))  //700hrs
		{
			if(oil_state != OIL_WARNING_DISMISSED)
			{
				oil_state = OIL_CHANGE_NEEDED;	//screen 19,start at 580, warning appears every 20 hrs
			}
			else
			{			
				one_minute_timer[NEXT_OIL_WARNING_TMR] = 1200;
			}
		}
		else if(one_minute_timer[NEXT_OIL_WARNING_TMR]==0)
		{
			if(oil_state != OIL_WARNING_DISMISSED)
			{
				oil_state = OIL_CHANGE_PAST_DUE;	//screen 20, start at 700. warning appears every 5 hrs
			}		
			else
			{			
				one_minute_timer[NEXT_OIL_WARNING_TMR] = 300;
			}
		}		
		engine_oil_timer = 0; //reset the time counter
	
	} //end of if(engine_oil_timer >= 60 )	
}//end of Do_1minute(void)

/*
	Read a long term timer / counter chain
	This function will start adding EEPROM word values together
	starting at addr and ending with end_addr. Counter upper word and
	counter lower are global variables that form the final 24 bit count
*/
unsigned long read_long_term_counter(unsigned int addr, unsigned int end_addr)
{
	union
	{
		WORD word;
		struct	
		{
			BYTE low;
			BYTE high;
		}byte;
	}temp_data;

	unsigned long counter = 0;

	while(addr < end_addr)
	{
		temp_data.byte.low = read_eeprom_byte(addr);
		temp_data.byte.high = read_eeprom_byte(addr+1);
		addr += 2;
		counter += temp_data.word;
	}
	return counter;
}


/*
	Increment a long term timer / counter chain
	The counter chain starts at addr and ends at end_addr
*/
void inc_long_term_counter(unsigned int addr, unsigned int end_addr)
{
	union
	{
		WORD word;
		struct	
		{
			BYTE low;
			BYTE high;
		}byte;
	}temp_data;
	
	while(addr < end_addr)
	{
		temp_data.byte.low = read_eeprom_byte(addr);
		temp_data.byte.high = read_eeprom_byte(addr+1);
		if(temp_data.word < 65535)
		{
			temp_data.word++;
			write_eeprom_byte(addr, temp_data.byte.low);
			write_eeprom_byte(addr+1, temp_data.byte.high);
			break;
		}
		addr += 2;
	}
}

void StateMachine(void)
{
	switch(op_state)
	{
		case POWER_UP_STATE:
		PowerUpMode();
		break;

		case OFF_STATE:
		OffMode();
		break;

		case ENGINE_START_STATE:
		EngineStartMode();					
		break;

		case CLIMATE_CONTROL_STATE:		
		ClimateControlMode();				
		break;

		case BATTERY_MONITOR_STATE:
		BatteryMonitorMode();
		break;

		//case COLD_STORAGE_STATE:
		//ColdStorageMode();
	    //break;

		case ERROR_SHUTDOWN_STATE:
		ErrorShutdownMode();
		break;

		default:
		break;		
	}
}

void PowerUpMode(void)
{	
	switch(state)
	{
		case 0:	
			//turn off everything for the first 5 seconds	
			Starter	= OFF;
			Compressor_Clutch = OFF;
			Heat_Mode = OFF;
			Cool_Mode = OFF;
			Glow_Plug = OFF;
			Evaporator_Fan = OFF;
			Fuel_Pump = OFF;

			Spare_Out = OFF;	//-not use on Rev1
			
			EVAPORATOR_PWM_OFF();
			CONDENSOR_PWM_OFF(); //-not use on Rev1

			engine_op_status = CONTROL_OFF;
 			control_status = CONTROL_OFF;
			
			one_minute_timer[CABIN_TEMP_WARMUP_TMR] = 10;//	timer for the temp sensor settle in the enclosure						
			//get temperature and voltage initial values to display
			analog_data[INDEX_BATTERY_V].average_value = Read_ADC(BATTERY_V_ANCH);
			analog_data[INDEX_CABIN_TEMP].average_value = Read_ADC(CABIN_TEMP_ANCH);
			analog_data[INDEX_ENGINE_TEMP].average_value = Read_ADC(ENGINE_TEMP_ANCH);
			analog_data[INDEX_LOW_SIDE_P].average_value = Read_ADC(LOW_SIDE_P_ANCH);
			analog_data[INDEX_HIGH_SIDE_P].average_value = Read_ADC(HIGH_SIDE_P_ANCH);
			one_second_timer[POWER_UP_TMR] = 1; //5 seconds
			state++;
		break;

		case 1:
			if(one_second_timer[POWER_UP_TMR]==0)
			{
				//get temperature and voltage initial values to display

				analog_data[INDEX_BATTERY_V].average_value = Read_ADC(BATTERY_V_ANCH);
				analog_data[INDEX_EXT_TEMP].average_value = Read_ADC(EXT_TEMP_ANCH);

				cabin_average = Read_ADC(CABIN_TEMP_ANCH);
				//initialize the temperature array
				for(cabin_count=0; cabin_count< 8;++cabin_count)
				{
					cabin_data[cabin_count]= cabin_average;
				}
				op_state = OFF_STATE;
				state = 0;
			}
		break;
		
		default:
			op_state = OFF_STATE;
			state = 0;	
		break;

	}

}

void OffMode(void)
{
	//1. monitor battery
	//check entering mode
	switch(state)
	{
		case 0:
			Starter	= OFF;
			Compressor_Clutch = OFF;
			Heat_Mode = OFF;
			Cool_Mode = OFF;
			Glow_Plug = OFF;
			Evaporator_Fan = OFF;
			Fuel_Pump = OFF;
			
			////CONDENSOR_PWM_OFF();
			EVAPORATOR_PWM_OFF();	

			engine_op_status = CONTROL_OFF;
 			control_status = CONTROL_OFF;
			error_state = 0;  //reset all error state
			evap_fan_always_on_flag = OFF;
		break;		
	}
}


/************************************************************
* EngineStartMode()--- function	                            *
* exit: engine is on, return to calling mode or 			*
*  	    engine failed, go to error_shutdown_mode			*
************************************************************/
void EngineStartMode(void)
{
	switch(engine_start_state)
	{
		case ES_GLOWPLUG_ON:	
		Glow_Plug = ON; // turn on glow plug 30 seconds
		control_status = WARMING_UP;
		if(ext_temp_sensor_state == OFF )
		{
			one_hundred_ms_timer[GLOW_PLUG_ON_TMR] = 280;  //25s+3s
		}
		else
		{
			if (external_temperature >= 122) //50�C
			{
				one_hundred_ms_timer[GLOW_PLUG_ON_TMR] = 0;	//0s
				Glow_Plug = OFF;
			}
			else if(external_temperature >= 104)	//40�C
			{
				one_hundred_ms_timer[GLOW_PLUG_ON_TMR] = 80;	//8s
			}
			else if(external_temperature >= 68)	// 20�C
			{
				one_hundred_ms_timer[GLOW_PLUG_ON_TMR] = 100;	//10s
			}
			else if(external_temperature>= 32)	//0�C
			{
				one_hundred_ms_timer[GLOW_PLUG_ON_TMR] = 160;	//16
			}
			else 	//external_temperature < 32�F
			{
				one_hundred_ms_timer[GLOW_PLUG_ON_TMR] = 290;	//29s
			}
		}
		attempted_start_counter++;//add on the start attempts
		engine_start_state = ES_FUEL_ON;
		break;

		case ES_FUEL_ON:
		if(one_hundred_ms_timer[GLOW_PLUG_ON_TMR] == 0)
		{
			Glow_Plug = OFF;
            if(ten_ms_timer[SHORT_DELAY_TMR]==0)
            {
                Fuel_Pump = ON;
                ten_ms_timer[SHORT_DELAY_TMR] = 100;  //1s
                engine_start_state = ES_STARTER_ON;
            }
        }
		break;

		case ES_STARTER_ON:	
		if(ten_ms_timer[SHORT_DELAY_TMR]==0)
		{ //after fuel pump is on for 1s, turn on the starter
			Starter = ON;
			control_status = STARTING;
		
			ten_ms_timer[SHORT_DELAY_TMR] = 400; //400-4s //800-8s change to 10s(1000) rev1.31
            //changed to 4s(400), rev1.32, 1/3/2020
			engine_start_state = ES_ENGINE_ON;
		}
		break;

		case ES_ENGINE_ON:
		if(ten_ms_timer[SHORT_DELAY_TMR]==0)
		{
			Starter = OFF; //the starter has been on for 4s,turn it off
			if(external_temperature < 122)
			{//if temp is lower than 122�F, post-heat 5s (glow plug)
				Glow_Plug = ON; // turn on glow plug 5 seconds
				one_hundred_ms_timer[GLOW_PLUG_ON_TMR] = 50;  //post heat for 5s
			}			
			ten_ms_timer[SHORT_DELAY_TMR]= 1000;//10s Cam 1/14/2014
			engine_start_state = ES_CHECK_PRESSURE;			
		}
		break;

		case ES_CHECK_PRESSURE:	
		if(one_hundred_ms_timer[GLOW_PLUG_ON_TMR]==0 )
		{
			Glow_Plug = OFF;
		}

		if( ten_ms_timer[SHORT_DELAY_TMR] == 0 )
		{
			if (discrete_inputs[OIL_PRESSURE].debounced_state == NOK)
			{//oil pressure is low
				if(attempted_start_counter >= 5)  //3, change to 5 attempts 3/20/2019
				{ //3 attempts,go to shut down the system and flash LOW OIL in red
					attempted_start_counter = 0; //reset counter
				
					error_state = STARTING_FAILURE;
					op_state = ERROR_SHUTDOWN_STATE;
				}
				else
				{
					Fuel_Pump = OFF;
					//go back to repeat the start process
					engine_start_state = ES_GLOWPLUG_ON;
				}
			}
			else
			{ //oil pressure is normal
				/*go to pressure is normal routine*/
				//ten_ms_timer[SHORT_DELAY_TMR]= 500;//5s
				ten_ms_timer[SHORT_DELAY_TMR]= 0;  //3-30-2020, don't need to energize reversing valve
				attempted_start_counter = 0; //reset counter
				engine_op_status = RUNNING;
				control_status = RUNNING;
				engine_start_state = ES_COOL_ON;
			}			
		}
		break;
		case ES_COOL_ON:	
		if( ten_ms_timer[SHORT_DELAY_TMR] == 0 )
		{
			/*3-30-2020, don't need to energize reversing valve*/
			//Cool_Mode = ON; //turn on condenser fan to cool the engine
			if(op_state_previous == CLIMATE_CONTROL_STATE)
			{
				op_state = CLIMATE_CONTROL_STATE;
				control_status = COOLING;
				state = CC_MONITOR_TEMP;
			}
			else if(op_state_previous == BATTERY_MONITOR_STATE)
			{
				//go to battery monitoring mode
				op_state = BATTERY_MONITOR_STATE;			
				state = BM_CHARGING;
			}
			
		}
		else
		{
			if(discrete_inputs[OIL_PRESSURE].debounced_state == NOK)
			{//oil pressure is low, go to shut down the system and display LOW OIL
				error_state = LOW_OIL_PRESSURE;
				op_state = ERROR_SHUTDOWN_STATE;
			}
			if(discrete_inputs[ENGINE_TEMP].debounced_state == NOK)
			{//engine temperature is too high, shut down the system and display HIGH ENGINE TEMPERATURE
				error_state = HIGH_ENGINE_TEMPERATURE;
				op_state = ERROR_SHUTDOWN_STATE;
			}
		}
		break;
		default:
		break;
	}//end of switch(engine_start_state)
#ifdef TRUCK_ENGINE_INTERRUPT
	//Do not check the stand-by signal anymore if stand_by was overridden 
	if(stand_by_overide_flag == FALSE)
	{
		if(discrete_inputs[TRUCK_ENGINE_STATE].debounced_state == ON)
		{//the truck engine is on
			attempted_start_counter = 0;
			error_state = STANDBY;
			op_state = ERROR_SHUTDOWN_STATE;
		}
	}
	else
	{//Reset the override flag in the case of the +12V voltage is lost after overriden the stand-by
		if(get_truck_engine_state()==OFF)
			stand_by_overide_flag = FALSE;
	}
#endif
}//end of void EngineStartMode(void)



void ClimateControlMode(void)
{
	switch(state)
	{
		//add one second for display to settle, it's necessary because 
		//modbus master polls error info. every second
		case CC_START_SETTLE: 
			temp_dspl_state = REAL_TIME_TEMP;
			ten_ms_timer[SHORT_DELAY_TMR] = 100;  //1s,
			state = CC_START_ENGINE;
		break;

		case CC_START_ENGINE:	  //start engine first  
			if(ten_ms_timer[SHORT_DELAY_TMR]==0){
				if(FUEL_PUMP_STATE == OFF)
				{
					op_state_previous = op_state; // so the program will come back to ClimateControlMode
					op_state = ENGINE_START_STATE;				
					engine_start_state = ES_GLOWPLUG_ON;
					attempted_start_counter=0;
				}
				else
				{//engine is running
					state = CC_MONITOR_TEMP;
				}
			}	
		break;

		case CC_MONITOR_TEMP:	 //engine is running normally 
						
			if(cabin_temperature <= (clmt_temp_setting - CC_TEMP_OFFSET))	//2F	10/16/2013
			{
				temp_dspl_state = REAL_TIME_TEMP;
				state = CC_MONITOR_TEMP;
				control_status = CHILLIN;
			}	
			if(cabin_temperature >= (clmt_temp_setting + CC_TEMP_OFFSET))	//2F	10/16/2013
			{ 
				temp_dspl_state = REAL_TIME_TEMP;
				state = CC_START_COOL; //calling cool
				control_status = COOLING;
			}		
		break;

		case CC_START_COOL:	 //cooling starts 
				Cool_Mode = ON; //turn on the cool mode relay
				state = CC_COMP_ON; //go to start compressor
		break;
	
		case CC_COMP_ON:	 //turn on the compressor 
			if(compressor_off_timer >= 15)  //timer in one second routine
			{
				Compressor_Clutch = ON; //turn on the compressor
				one_second_timer[COMP_EVAP_DELAY_TMR] = 0;	//3; //10, changed to 3 on 6-16-2015						
				state = CC_EVAP_ON;	
			}
		break;

		case CC_AC_LOW_PRESSURE_RECHK:
			Compressor_Clutch = OFF; // turn off the compressor
			refregerant_check_counter++;
			if(refregerant_check_counter > 10)  //allowed to try 10 time
			{
				state = CC_AC_LOW_PRESSURE_FAIL;	//display ac error
				refregerant_check_counter = 0;  //reset counter							
			}
			else
			{  // pressure recheck
				state = CC_COMP_ON;	
			}			
		break;

		case CC_EVAP_ON:	//coolant pressure is normal routine
				if(one_second_timer[COMP_EVAP_DELAY_TMR] == 0) //3s,10s
				{
					ac_high_pres_happened_flag = 0; //clear flag
					Evaporator_Fan = ON; //turn on the evaporator
                    one_second_timer[EVAP_FORCED_ON_TMR] = 10;  //6-18-2015 Force the evap on for 10s
					one_minute_timer[DEFROST_CYCLE_TMR] = DEFROST_INTERVAL ;  //30min
					//monitor the temperature and the AC pressure
					state = CC_CTRL_RUNNING;				
				}
		break;
		
		case CC_CTRL_RUNNING:	 //normal heating/cooling process,
			if(one_minute_timer[DEFROST_CYCLE_TMR] > 0)
			{										
				if(COOL_MODE_STATE == ON)
				{
					if(cabin_temperature <= (clmt_temp_setting+1))	//0, 10/16/2013
					{
						Compressor_Clutch = OFF;				
						state = CC_EVAP_OFF;	
						temp_dspl_state = CC_TEMP_SETTING;
					}
				}
			}
			else
			{ //start defrost cycle				
				control_status = DEFROST;
				temp_dspl_state = REAL_TIME_TEMP;
				if(COOL_MODE_STATE == ON)
				{//cooling cycle
					Compressor_Clutch = OFF;
					Cool_Mode = OFF;
					Evaporator_Fan = OFF; //8/20/2020

					one_second_timer[EVENT_INTERVAL_TMR] = 45;  //15,8/20/2020. //60s, 3-30-2020
					state = CC_COOL_DEFROST_END;	 //3-30-2020,eliminate reverse valve
				}
			}
		break;

		case CC_COOL_DEFROST_END:	//continue cooling cycle 
			if(one_second_timer[EVENT_INTERVAL_TMR] ==0) //8s
			{
				Compressor_Clutch = ON;
				Cool_Mode = ON; 
				Evaporator_Fan = ON;    //8/20/2020
				control_status = COOLING;
				one_minute_timer[DEFROST_CYCLE_TMR] = DEFROST_INTERVAL ;  //reload defrost cycle time 				
				state = CC_CTRL_RUNNING;  //go back to heating/cooling cycle			
			}
		break;
		case CC_EVAP_OFF:  // from state 11CC_CTRL_RUNNING
			if(compressor_off_timer>=15)    //compressor has been off for 60s. 8/20/2020 changed to 15s
			{
				if(COOL_MODE_STATE == ON)
				{
					Cool_Mode = OFF;
				}
                Evaporator_Fan = OFF;
				state = CC_MONITOR_TEMP;
			}
			else
			{
				if(cabin_temperature <= (clmt_temp_setting - CC_TEMP_OFFSET))	//2,10/16/2013
                {
					temp_dspl_state = REAL_TIME_TEMP;
					if(COOL_MODE_STATE == ON)
					{						
						Cool_Mode = OFF;
					}
				}
			}
		break;

		case CC_AC_LOW_PRESSURE_FAIL:	 //failure state
			//send info to display REFRIGERANT_FAILED,
			//disabling the compressor,engine keeps running	
			op_state_previous = CLIMATE_CONTROL_STATE;	
			error_state = AC_LOW_PRESSURE_FAILURE;
			op_state = ERROR_SHUTDOWN_STATE;						
		break;

		case CC_AC_HIGH_PRESSURE_FAIL:
			op_state_previous = CLIMATE_CONTROL_STATE;
			error_state = AC_HIGH_PRESSURE_FAILURE;
			op_state = ERROR_SHUTDOWN_STATE;
		break;

		case CC_AC_HIGH_PRESSURE_RECHK: //it's high pressure check
			Compressor_Clutch = OFF;
			//ac_high_pres_happened_flag = 1; //set a flag  //12-15-2014 comment out
			//error_state = HIGH_AC_PRESSURE_ERROR; //to record in event log //12-12-2014 comment out
			state = CC_WAIT_HIGH_PRESSURE_NORMAL;
		break;
		
		case CC_WAIT_HIGH_PRESSURE_NORMAL:  //added 4/30/2014
			//Once high side High A/C pressure is detected(OPEN at 400psi),
			//disengage clutch. Reengage clutch when high A/C pressure is 
		   	//not detected(closed at 200psi). 
		   	//only detect fault if high A/C pressure occurs in less than 2s of 
		   	//clutch reengage
			//wait until high side pressure is back to normal
			if((discrete_inputs[H_SIDE_PRESSURE].debounced_state == OK))
			{
				Compressor_Clutch = ON; // turn on the compressor	
				//in case the evap fan is not on yet		
				one_second_timer[COMP_EVAP_DELAY_TMR] = 0; //3; //10//change to 3 on 6-16-2015						
				state = CC_EVAP_ON;	
			}
		break;

		default:
		break;
	}//end of switch(state)

	if((COMPRESSOR_STATE == ON)&&(compressor_on_timer >= 2))	//3
	{
    	 //start to check refrigerant pressure
		if((discrete_inputs[L_SIDE_PRESSURE].debounced_state == NOK))
		{ // refrigerant pressure check failed	
			Compressor_Clutch = OFF; // turn off the compressor					
			state = CC_AC_LOW_PRESSURE_RECHK;	//AC pressure is low
		}	
		else if((discrete_inputs[H_SIDE_PRESSURE].debounced_state == NOK))
		{
			Compressor_Clutch = OFF;//12-22-14
			state = CC_AC_HIGH_PRESSURE_RECHK; //AC pressure is high
		}
		else  
		{  //pressure is normal
			refregerant_check_counter = 0; //reset counter				
			if((error_state == ENGINE_STALLED)||(error_state == HIGH_AC_PRESSURE_ERROR))
				error_state = NO_OP_ERROR;
		}
	}// end of if((CCOMPRESSOR_STATE == ON)&&(compressor_on_timer >= 2))

	//monitoring battery, engine temperature
	if(discrete_inputs[ENGINE_TEMP].debounced_state == NOK)
	{//engine temperature is too high, go to shut down the system and display HIGH ENGINE TEMPERATURE
			error_state = HIGH_ENGINE_TEMPERATURE;
			op_state = ERROR_SHUTDOWN_STATE;
	}
	else if((FUEL_PUMP_STATE==ON) && (discrete_inputs[OIL_PRESSURE].debounced_state == NOK))
	{//oil pressure is low, go to shut down the system and display LOW OIL
		error_state = LOW_OIL_PRESSURE;
		op_state = ERROR_SHUTDOWN_STATE;
	}
	else if(battery_voltage <= CC_LOW_V_LIMIT )  // 11.7V
	{		
		if(clmt_low_batt_tmr_flag == 0)
		{
			clmt_low_batt_tmr_flag = 1;
			one_minute_timer[CLMT_LOW_BATT_TMR] = 10; //10min 1-24-14, 30min 10-16-2013.   15 //15mins
		}
		else
		{  //battery has been low more than 15 mins
			if(one_minute_timer[CLMT_LOW_BATT_TMR] == 0)
			{
				clmt_low_batt_tmr_flag = 0;
				error_state = LOW_BATTERY;
				op_state = ERROR_SHUTDOWN_STATE;
			}
		}		
	}
	else
	{
		clmt_low_batt_tmr_flag = 0; //reset the flag
	}

#ifdef TRUCK_ENGINE_INTERRUPT
	if((stand_by_overide_flag == FALSE)&&(control_status != OFF))
	{
		if(discrete_inputs[TRUCK_ENGINE_STATE].debounced_state == ON)
		{//the truck engine is on
		//reset all flags
			clmt_low_batt_tmr_flag = 0;	
			op_state_previous = CLIMATE_CONTROL_STATE;
			error_state = STANDBY;
			op_state = ERROR_SHUTDOWN_STATE;	
		}
	}
	else
	{//Reset the override flag in the case of the +12V voltage is lost after overriden the stand-by
		if(get_truck_engine_state()==OFF)
			stand_by_overide_flag = FALSE;
	}
#endif	
}//end of function void ClimateControlMode(void)

/******************************************************************

*******************************************************************/

void BatteryMonitorMode(void)
{
	switch(state)
	{
		case BM_START: //turn off everything 	
			Fuel_Pump = OFF;			
 			Starter	= OFF;			
 			Compressor_Clutch = OFF;	
 			Glow_Plug = OFF;			
 			Heat_Mode = OFF;			
 			Cool_Mode = OFF;
			Evaporator_Fan = OFF;

			engine_op_status = CONTROL_OFF;
 			control_status = CONTROL_OFF;
			
			attempted_start_counter =0;
			attempted_charging_counter = 0;
			state = BM_BATT_MONITOR;	
					
		break;

		case BM_BATT_MONITOR:	//check if battery voltage is lower than set_point.							
			if(battery_voltage < batt_monitor_setting)
			{
				ten_ms_timer[SHORT_DELAY_TMR] = 1000; //10s
				state = BM_START_ENGINE;			
			}
			else
			{
				attempted_charging_counter = 0;
			}
		break;

		case BM_START_ENGINE:	
			if(ten_ms_timer[SHORT_DELAY_TMR])
			{  //detected low battery is less than 10s. go back to continually monitor batt v
				if(battery_voltage > batt_monitor_setting)
				{
					ten_ms_timer[SHORT_DELAY_TMR] = 0;
					state = BM_BATT_MONITOR;	
				}
			}
			else  //10s elapsed
			{//detected low battery has been more than 10s
				attempted_charging_counter++;
				if(attempted_charging_counter > 3)  //changed to 3 from 2 on 1-24-2014
				{							
					attempted_charging_counter = 0; //reset counter
					state = BM_ERROR_PROCESS;		//display error				
				}
				else
				{
					op_state_previous = op_state; 	// so the program'll be able to come back to battery monitor mode
					op_state = ENGINE_START_STATE;
					engine_start_state = ES_GLOWPLUG_ON;
					//control_status = WARMING_UP;	//so the standby error won't display OFF when standby is +12V at start up
					attempted_start_counter=0;
				}				
			}			
		break;

		case BM_CHARGING: //program comes back to this state after engine started   
			one_minute_timer[CHARGING_BATT_TMR] = 30; //30  charging 30 minutes
			control_status = CHARGING;
			state = BM_BATT_STABLE_2MIN;	
		break;

		case BM_BATT_STABLE_2MIN:  
			if(one_minute_timer[CHARGING_BATT_TMR]==0)
			{//after charged 30min
				Fuel_Pump = OFF;
				Cool_Mode = OFF;
				control_status  = CONTROL_OFF; //OFF status
				one_second_timer[BATT_STABLE_TMR] = 120;//waiting 2 minutes
				state = BM_BATT_CHECK;	
			}
		break;
		
		case BM_BATT_CHECK:	
			if(one_second_timer[BATT_STABLE_TMR]==0)
			{
				state = BM_BATT_MONITOR;  //go back to check battery voltage
			}
		break;
		
		case BM_ERROR_PROCESS: //after two failed charging cycle, shut down  
				//DISPLAY "Charge System Failure"
			 op_state = ERROR_SHUTDOWN_STATE;
			 error_state = LOW_BATTERY;	//screen13
		break;

		default:
		break;
	}//end of switch(state)

		//monitor the engine temperature and oil pressure all the time
	if(discrete_inputs[ENGINE_TEMP].debounced_state == NOK)
	{//engine temperature is too high, go to shut down the system and display HIGH ENGINE TEMPERATURE
		error_state = HIGH_ENGINE_TEMPERATURE;
		op_state = ERROR_SHUTDOWN_STATE;
	}
	else if((FUEL_PUMP_STATE == ON) && (discrete_inputs[OIL_PRESSURE].debounced_state == NOK))
	{//oil pressure is low, go to shut down the system and display LOW OIL
		error_state = LOW_OIL_PRESSURE;
		op_state = ERROR_SHUTDOWN_STATE;
	}

#ifdef TRUCK_ENGINE_INTERRUPT
	if((stand_by_overide_flag == FALSE)&&(control_status != OFF))
	{
		if(discrete_inputs[TRUCK_ENGINE_STATE].debounced_state == ON)
		{//the truck engine is on
		 //reset all flags
			attempted_charging_counter = 0;	
			op_state_previous = BATTERY_MONITOR_STATE;
			error_state = STANDBY;
			op_state = ERROR_SHUTDOWN_STATE;	
		}
	}
	else
	{//Reset the override flag in the case of the +12V voltage is lost after overriden the stand-by
		if(get_truck_engine_state()==OFF)
			stand_by_overide_flag = FALSE;
	}
#endif		
}//end of void BatteryMonitorMode(void)

void ColdStorageMode(void)
{
	switch(state)
	{
		case CS_START:
			temp_dspl_state = REAL_TIME_TEMP;
			attempted_charging_counter = 0;
			storage_charging_batt_flag = 0;
			ten_ms_timer[SHORT_DELAY_TMR] = 100;  //1s,
			control_status = CONTROL_OFF;
			state = CS_MONITOR;
		break;
		case CS_MONITOR: 
			if(ten_ms_timer[SHORT_DELAY_TMR] == 0)
			{	
				if(battery_voltage < storage_v_setting)
				{
					ten_ms_timer[SHORT_DELAY_TMR] = 1000; //10s
					state = CS_LV_START_ENGINE;				
				}			
				else
				{
					attempted_charging_counter = 0;
					storage_charging_batt_flag = 0;			
					if (ext_temp_sensor_state == ON)
					{ //active by coolant temperature sensor
						if(external_temperature < storage_t_setting)
						{//Calling Heat			  
							state = CS_LT_START_ENGINE;	//start engine				
						} 
					}
					else
					{//active by cabin temperature sensor
						if(cabin_temperature < storage_t_setting)
						{//Calling Heat			  
							state = CS_LT_START_ENGINE;	//start engine				
						} 
					}
				}
			}
		break;		
		case CS_LV_START_ENGINE:	//from state 0--low battery CS_LV_START_ENGINE
			if(ten_ms_timer[SHORT_DELAY_TMR])	//10s
			{  
				if(battery_voltage > storage_v_setting)
				{//detected low battery is less than 10s. go back to monitor v and t				
					state = CS_MONITOR; 
				}
			}
			else  //10s elapsed
			{//detected low battery has been more than 10s			
				if(attempted_charging_counter >= 2)
				{							
					attempted_charging_counter = 0; //reset counter
					state = CS_LV_BATT_FAIL;	//display charging failure	
					storage_charging_batt_flag = 0;
				}
				else
				{ //start engine to charge
					op_state_previous = op_state; 	// so the program'll be able to come back to battery monitor mode
					op_state = ENGINE_START_STATE;		
					engine_start_state = ES_GLOWPLUG_ON;
					//control_status = WARMING_UP;//so the standby error won't display OFF when standby is +12V at start up
					attempted_start_counter = 0;
					storage_charging_batt_flag = 1;	//flag engine start to charge battery
					attempted_charging_counter++;
				}				
			}			
		break;

		case CS_LT_START_ENGINE:
			if(FUEL_PUMP_STATE == OFF)
			{
				op_state_previous = op_state; // so the program will come back 
				op_state = ENGINE_START_STATE;
				engine_start_state = ES_GLOWPLUG_ON;
				//control_status = WARMING_UP;//so the standby error won't display OFF when standby is +12V at start up
				attempted_start_counter = 0;
				//go to state=3 after engine starts
			}
			else
			{//engine is running
				state = CS_LV_LT_ENGINE_ON;	 //climate cotrol state  1
			}				
		break;
	
		case CS_LV_LT_ENGINE_ON:		
			if(storage_charging_batt_flag)
			{//charging
				one_minute_timer[CHARGING_BATT_TMR] = 30; //30  charging 30 minutes			
				state = CS_LV_CHARGING;
				control_status = CHARGING;
			}
//================1/12/2015=========================================================
			else if(ext_temp_sensor_state == ON)
			{ //running engine only
				state = CS_EXT_LT_RUNNING;
				control_status = RUNNING;
			}
//==================================================================================
			else
			{//starts heating 
				if(COOL_MODE_STATE == ON) //
				{ //cool mode is on
					Cool_Mode = OFF;  //turn cool mode off
					ten_ms_timer[SHORT_DELAY_TMR] = HEAT_COOL_TRANS_TIME; //500; //wait 5s to turn on the heat fan
					state = CS_LT_HEATING_ON;	//turn on heat
				}
				else
				{
					Heat_Mode = ON; //turn on the heat mode relay
					state = CS_LT_COMP_ON;	 //go to turn on the compressor
				}
			}		
		break;

		case CS_LT_HEATING_ON:	//heating starts CS_LT_HEATING_ON
			if(ten_ms_timer[SHORT_DELAY_TMR]==0)
			{
				Heat_Mode = ON; //turn on the heat mode relay	
				state = CS_LT_COMP_ON;	 //go to turn on the compressor
			}
		break;
			
		case CS_LT_COMP_ON:	  //turn on the compressor CS_LT_COMP_ON
			if(compressor_off_timer >= 15)  // 30 timer of one second routine
			{
				Compressor_Clutch = ON; // turn on the compressor
				one_second_timer[COMP_EVAP_DELAY_TMR] = 0; //3; //start 10s timer to turn on evaporator fan			
				state = CS_LT_EVAP_ON;
			}
		break;

		case CS_LT_AC_LOW_PRES_RECHK:	 //low pressure is NOK 
			Compressor_Clutch = OFF; 	 // turn off the compressor
			refregerant_check_counter++;
			if(refregerant_check_counter > 10)
			{
				refregerant_check_counter = 0; //reset counter
				state = CS_LT_AC_LOW_PRES_FAIL;		//display A/C pressure failure			
			}
			else
			{  // pressure recheck
				state = CS_LT_COMP_ON;	
			}			
		break;

		case CS_LT_EVAP_ON:		//coolant pressure is normal routine,turn on evaporator fan
				if(one_second_timer[COMP_EVAP_DELAY_TMR] == 0) //10s
				{
					ac_high_pres_happened_flag = 0; //clear flag
					Evaporator_Fan = ON; //turn on the evaporator
					one_second_timer[EVAP_FORCED_ON_TMR] = 10;  //6-18-2015 Force the evap on for 10s
					one_minute_timer[DEFROST_CYCLE_TMR] = DEFROST_INTERVAL ;  //1hr
					state = CS_LT_CTRL_RUNNING;					
				}
		break;		

		case CS_LT_CTRL_RUNNING:	 //normal heating no AC pressure check. CS_LT_CTRL_RUNNING
			if(one_minute_timer[DEFROST_CYCLE_TMR] > 0)
			{													
				if (ext_temp_sensor_state == ON)
				{ 	//active by coolant temperature sensor
					if(external_temperature > (storage_t_setting + 10 ))
					{			  
						Compressor_Clutch = OFF;				
						state = CS_LT_CTRLS_OFF;	//go to turn off evaporator and engine				
					} 
				}
				else
				{		//active by cabin temperature sensor
					if(cabin_temperature > (storage_t_setting + 10))
					{//Calling Heat			  
						Compressor_Clutch = OFF;				
						state = CS_LT_CTRLS_OFF;	//go to turn off evaporator and engine					
					} 
				}
			}
			else
			{ //start defrost cycle			
				Compressor_Clutch = OFF;
				Heat_Mode = OFF; 
				one_second_timer[EVENT_INTERVAL_TMR] = 10; //10s					
				state = CS_LT_DEFROST;	 //heating cycle defrost
				control_status = DEFROST;	
			}
		break;

		case CS_LT_DEFROST:		//heating cycle defrost,from state 9 CS_LT_DEFROST
			if(one_second_timer[EVENT_INTERVAL_TMR] == 0)
			{//resume heating and compressor
				Compressor_Clutch = ON;
				Heat_Mode = ON; 
				one_minute_timer[DEFROST_CYCLE_TMR] = DEFROST_INTERVAL;  //reload defrost cycle time				
				state = CS_LT_CTRL_RUNNING;	 //go back to heating cycle				
			}
		break;

		case CS_LV_CHARGING:	 //charging battery from state 3. CS_LV_CHARGING
			if(one_minute_timer[CHARGING_BATT_TMR] == 0)
			{//after charged 30min
				Fuel_Pump = OFF;
				Cool_Mode = OFF;
				control_status  = CONTROL_OFF; //OFF status
				one_second_timer[BATT_STABLE_TMR] = 120;//waiting 2 minutes
				state = CS_LV_STABLIZING;	
			}
		break;
		
		case CS_LV_STABLIZING:	//stable battery reading CS_LV_STABLIZING
			if(one_second_timer[BATT_STABLE_TMR] == 0)
			{
				state = CS_MONITOR;	 //go back to check battery voltage
			}
		break;

		case CS_LT_CTRLS_OFF:	   // from state 9 CS_LT_CTRLS_OFF
			if(compressor_off_timer>=60)  //compressor has been off for 60s
			{
				Evaporator_Fan = OFF; //turn off evaporator fan
				Heat_Mode = OFF;  
				Fuel_Pump = OFF;  			
				state = CS_MONITOR;	 //go back to monitor the temperature and battery
				control_status = CONTROL_OFF;
			}		
		break;

		case CS_LT_AC_LOW_PRES_FAIL:	  //failure state  from state 7,CS_LT_AC_FAIL
			//send info to display REFRIGERANT_FAILED,
			op_state_previous = COLD_STORAGE_STATE;	
			error_state = AC_LOW_PRESSURE_FAILURE;
			op_state = ERROR_SHUTDOWN_STATE;
						
		break;

		case CS_LT_AC_HIGH_PRES_FAIL:
			op_state_previous = COLD_STORAGE_STATE;
			error_state = AC_HIGH_PRESSURE_FAILURE;
			op_state = ERROR_SHUTDOWN_STATE;
		break;

		case CS_LV_BATT_FAIL:	//from state 1. after two failed charging cycle, shut down CS_LV_BATT_FAIL
				 //DISPLAY "Charge System Failure"			 
			 error_state = LOW_BATTERY;//screen13
			 op_state = ERROR_SHUTDOWN_STATE;
		break;

		case CS_AC_HIGH_PRESSURE_CHK: //AC high pressure
			error_state = HIGH_AC_PRESSURE_ERROR; //to record in event log
			Compressor_Clutch = OFF;
			state = CS_WAIT_HIGH_PRESSURE_NORMAL;
		break;
		
		case CS_WAIT_HIGH_PRESSURE_NORMAL:  //added 4/30/2014
			//wait until high side pressure is back to normal
			if((discrete_inputs[H_SIDE_PRESSURE].debounced_state == OK))
			{	
				Compressor_Clutch = ON; // turn on the compressor	
				//in case the evap fan is not on yet		
				one_second_timer[COMP_EVAP_DELAY_TMR] = 0;	//3; //10//change to 3 on 6-16-2015						
				state = CS_LT_EVAP_ON;					
			}
		break;
//========================1/12/2015===============================================
		case CS_EXT_LT_RUNNING:
			if(external_temperature > (storage_t_setting + 10 ))
			{
				Fuel_Pump = OFF;
				Cool_Mode = OFF;
				control_status  = CONTROL_OFF; 	//OFF status
				ten_ms_timer[SHORT_DELAY_TMR] = 100;  //add some delay
				state = CS_MONITOR;
			}
		break;
//==================================================================================
		default:
		break;
	}//end of switch(state)

	if((COMPRESSOR_STATE == ON)&&(compressor_on_timer >=2))  //3
	{  //start to check refrigerant pressure after 2s compressor turned on
		if((discrete_inputs[L_SIDE_PRESSURE].debounced_state == NOK))
		{ // refrigerant pressure check failed					
			state = CS_LT_AC_LOW_PRES_RECHK;	
		}	
		else if((discrete_inputs[H_SIDE_PRESSURE].debounced_state == NOK))
		{ // refrigerant high pressure check
			state = CS_AC_HIGH_PRESSURE_CHK;
		}
		else  
		{  //pressure is normal
			refregerant_check_counter = 0; //reset counter				
			if((error_state == ENGINE_STALLED)||(error_state == HIGH_AC_PRESSURE_ERROR))
				error_state = NO_OP_ERROR;
		}
	}

	//monitor the engine temperature and oil pressure all the time
	if(discrete_inputs[ENGINE_TEMP].debounced_state == NOK)
	{//engine temperature is too high, go to shut down the system and display HIGH ENGINE TEMPERATURE
		error_state = HIGH_ENGINE_TEMPERATURE;
		op_state = ERROR_SHUTDOWN_STATE;
	}
	else if((FUEL_PUMP_STATE == ON) && (discrete_inputs[OIL_PRESSURE].debounced_state == NOK))
	{//oil pressure is low, go to shut down the system and display LOW OIL		
		error_state = LOW_OIL_PRESSURE;
		op_state = ERROR_SHUTDOWN_STATE;
	}

#ifdef TRUCK_ENGINE_INTERRUPT
	if((stand_by_overide_flag == FALSE)&&(control_status != OFF))
	{
		if(discrete_inputs[TRUCK_ENGINE_STATE].debounced_state == ON)
		{//the truck engine is on
		 //reset all flags									
			op_state_previous = COLD_STORAGE_STATE;
			error_state = STANDBY;
			op_state = ERROR_SHUTDOWN_STATE;	
		}
	}
	else
	{//Reset the override flag in the case of the +12V voltage is lost after overriden the stand-by
		if(get_truck_engine_state() == OFF)
			stand_by_overide_flag = FALSE;
	}
#endif	
	
}//end of void ColdStorageMode(void)
		
void ErrorShutdownMode(void)
{
	temp_dspl_state = REAL_TIME_TEMP;
	switch(error_state)
	{
		case NO_OP_ERROR:
			op_state = OFF_STATE;
			state = 0;
		break;

		case LOW_OIL_PRESSURE:
			Starter	= OFF;
			Compressor_Clutch = OFF;
			Heat_Mode = OFF;
			Cool_Mode = OFF;
			Glow_Plug = OFF;
			Evaporator_Fan = OFF;
			Fuel_Pump = OFF;
			
			engine_op_status = CONTROL_OFF;
 			control_status = CONTROL_OFF;
	
		break;

		case HIGH_ENGINE_TEMPERATURE: //screen11
			Starter	= OFF;
			Compressor_Clutch = OFF;
			Heat_Mode = OFF;
			Cool_Mode = OFF;
			Glow_Plug = OFF;
			Evaporator_Fan = OFF;
			Fuel_Pump = OFF;

			engine_op_status = CONTROL_OFF;
 			control_status = CONTROL_OFF;
			
		break ;

		case LOW_BATTERY:
			Starter	= OFF;
			Compressor_Clutch = OFF;
			Heat_Mode = OFF;
			Cool_Mode = OFF;
			Glow_Plug = OFF;
			Evaporator_Fan = OFF;
			Fuel_Pump = OFF;

			engine_op_status = CONTROL_OFF;
 			control_status = CONTROL_OFF;
	
		break;

		case AC_LOW_PRESSURE_FAILURE:	//screen 5
			//disable compressor, but the engine continues to run
			Compressor_Clutch = OFF;			
			//check if the override button was pressed	
			if(low_ac_overide_flag == TRUE)
			{				
				error_state = NO_OP_ERROR;
				op_state = op_state_previous;
				if(op_state == CLIMATE_CONTROL_MODE)
				{
					state = CC_COMP_ON;
				}
				low_ac_overide_flag = FALSE;//reset the flag
			}	
		break;

		case AC_HIGH_PRESSURE_FAILURE:
			Compressor_Clutch = OFF;
			//check if the override button was pressed					
			if(high_ac_overide_flag == TRUE)
			{
				error_state = NO_OP_ERROR;
				op_state = op_state_previous;
				if(op_state == CLIMATE_CONTROL_MODE)
				{
					state = CC_COMP_ON;
				}
				high_ac_overide_flag = FALSE; //reset the flag
			}
		break;
		
		case STARTING_FAILURE:  //screen 17
			Starter	= OFF;
			Compressor_Clutch = OFF;
			Heat_Mode = OFF;
			Cool_Mode = OFF;
			Glow_Plug = OFF;
			Evaporator_Fan = OFF;
			Fuel_Pump = OFF;
			
			engine_op_status = CONTROL_OFF;
 			control_status = CONTROL_OFF;
	
		break;

		case STANDBY:
			Starter	= OFF;
			Compressor_Clutch = OFF;
			Heat_Mode = OFF;
			Cool_Mode = OFF;
			Glow_Plug = OFF;
			Evaporator_Fan = OFF;
			Fuel_Pump = OFF;
			
			engine_op_status = CONTROL_OFF;  //to display engine status
			control_status = CONTROL_OFF;  //for displaying the status
			//continue to monitor the standby input. once the voltage is lost
			//or the user override the warning 
			//the APU should resume to the previous op mode.
			if((get_truck_engine_state()==OFF) || (stand_by_overide_flag == TRUE))
			{
				error_state = NO_OP_ERROR;
				op_state = op_state_previous;
				state = 0;
			}
			
		break;

		case NO_RPM_DETECTED:
			Starter	= OFF;
			Compressor_Clutch = OFF;
			Heat_Mode = OFF;
			Cool_Mode = OFF;
			Glow_Plug = OFF;
			Evaporator_Fan = OFF;
			Fuel_Pump = OFF;

			engine_op_status = CONTROL_OFF;
 			control_status = CONTROL_OFF;
		break;

		default:
			op_state = OFF_STATE;
			state = 0;
		break;
	}
}

void InitFactorySettings(void)
{
	BYTE temp;
	_delay(200); //delay 100 instruction cycles(12.5ms) to stablelize internal eeprom 
	CLRWDT();
	_delay(200);
	CLRWDT();

	temp = read_eeprom_byte(EEPROM_WRITTEN_FLAG);
	
	if(temp == 0x55)
	{
		clmt_temp_setting = read_eeprom_word(EE_CLIMATE_TEMP_SETTING);

		batt_monitor_setting = read_eeprom_word(EE_MONITOR_BATT_SETTING);
		//add bounary check to be able to switch between 12V and 24V power
		if(batt_monitor_setting > BATT_MONITOR_HIGH)
		{
			batt_monitor_setting = BATT_MONITOR_V_INIT;
			write_eeprom_word(EE_MONITOR_BATT_SETTING, BATT_MONITOR_V_INIT);
		}
		else if(batt_monitor_setting < BATT_MONITOR_LOW)
		{
			batt_monitor_setting = BATT_MONITOR_V_INIT;
			write_eeprom_word(EE_MONITOR_BATT_SETTING, BATT_MONITOR_V_INIT);
		}

		storage_t_setting = read_eeprom_word(EE_STORAGE_TEMP_SETTING);

		storage_v_setting = read_eeprom_word(EE_STORAGE_BATT_SETTING);
		if(storage_v_setting > STORE_BATT_HIGH)
		{
			storage_v_setting = STORAGE_V_INIT;
			write_eeprom_word(EE_STORAGE_BATT_SETTING, STORAGE_V_INIT);
		}
		else if(storage_v_setting < STORE_BATT_LOW)
		{
			storage_v_setting = STORAGE_V_INIT;
			write_eeprom_word(EE_STORAGE_BATT_SETTING, STORAGE_V_INIT);
		}
		evap_fan_speed = read_eeprom_byte(EE_EVAP_FAN_SPEED);
		temperature_unit = read_eeprom_byte(EE_TEMP_UNIT);

		vref_calibration = read_eeprom_word(EE_VREF_CALIBRATION); //ADC reference voltage
		temperature_calibration = read_eeprom_word(EE_TEMP_CALIBRATION);
		
	
	}
	else
	{ //write the initial value
		write_eeprom_word(EE_CLIMATE_TEMP_SETTING, CLMT_TEMP_INIT);
		clmt_temp_setting = CLMT_TEMP_INIT;
		write_eeprom_word(EE_MONITOR_BATT_SETTING, BATT_MONITOR_V_INIT);
		batt_monitor_setting = BATT_MONITOR_V_INIT;
		write_eeprom_word(EE_STORAGE_TEMP_SETTING, STORAGE_T_INIT);
		storage_t_setting = STORAGE_T_INIT;
		write_eeprom_word(EE_STORAGE_BATT_SETTING, STORAGE_V_INIT);
		storage_v_setting = STORAGE_V_INIT;
		write_eeprom_byte(EE_EVAP_FAN_SPEED,HIGH);
		evap_fan_speed = HIGH;
		write_eeprom_byte(EE_TEMP_UNIT,FAHRENHEIT);
        temperature_unit = FAHRENHEIT;		
		write_eeprom_byte(EE_CLND_START_ONOFF,OFF);	//calendar start is off
		write_eeprom_byte(EE_CLND_START_MODE,CLIMATE_CONTROL_MODE);	//calendar start mode
		write_eeprom_byte(EE_CLND_START_YEAR,0x13);	//calendar start year BCD
		write_eeprom_byte(EE_CLND_START_MONTH,0x01);	//calendar start month BCD
		CLRWDT();
		write_eeprom_byte(EE_CLND_START_DATE,0x10);	//calendar start date BCD
		write_eeprom_byte(EE_CLND_START_HOUR,0x09);	//calendar start hour BCD
		write_eeprom_byte(EE_CLND_START_MIN,0x00);	//calendar start minute BCD
		write_eeprom_byte(EE_CLND_START_AMPM,AM);	//calendar start am/pm
		
		write_eeprom_word(MACHINE_RUNTIME_START,0); //initialize timers
		write_eeprom_word(ENGINE_RUNTIME_START,0);
		write_eeprom_word(ENGINE_OILTIME_START,0);

		write_eeprom_word(EE_VREF_CALIBRATION,VREF_CAL_INIT); //ADC reference voltage initial valur
		vref_calibration = VREF_CAL_INIT;

		write_eeprom_word(EE_TEMP_CALIBRATION, TEMP_CAL_INIT);  //temperature calibration initial value
		temperature_calibration = TEMP_CAL_INIT;

		write_eeprom_word(EEPROM_WRITTEN_FLAG, 0x55);
	}
	

}
/*****************************************************************************
* interrupt service routine function: All_Int_Services()
* interupt function default to being high priority. To create a low-priority 
* interrupt function, use the qualifier low_priority interrupt in the 
* function definition
******************************************************************************/
void interrupt All_Int_Services(void)
{       
	BYTE i = 0;   
	if(TMR2IE && TMR2IF)  
	{//pic18F45k22

		PIR1bits.TMR2IF = 0; //clear interrupt flag	

		if(MB_SERVER_DISPLAY.modbus_timer == 1)
			MB_Display_ServiceModbusTimers((MODBUS_SERVER_t*) &MB_SERVER_DISPLAY);	
	}

	/************************************************************************
 	*	This interrupt gets fired when there is an unread character in the 
 	*  receive buffer 
 	************************************************************************/
	if( RC1IE && RC1IF ) //USART1 receive interrupts
	{
		BYTE data;
		modbus_errors_t error = NO_ERROR;
		if(RCSTA1bits.FERR==1)
		{
			BYTE dummy;
			Nop();
			dummy = RCREG1;
			error = SLAVE_FAILURE;
		}
		else if(RCSTA1bits.OERR == 1)	//If we had an overrun error (OERR)
		{	//toggle CREN to start it up again
			RCSTA1bits.CREN = 0;
			Nop();
			RCSTA1bits.CREN = 1;
			error = SLAVE_BUSY;
		}
		while(PIR1bits.RC1IF == 1)
		{
		//	MB_SERVER_DISPLAY.modbus_inactivity_timer = 4;
			data = RCREG1;
			MB_Display_CharacterReceived((MODBUS_SERVER_t*) &MB_SERVER_DISPLAY, data, 0); // disregard error
		}
	}//end of if(PIR1bits.RC1IF) //USART1 receive interrupts
	
	/************************************************************************
	 *	This interrupt gets fired when the transmit buffer is empty.
	 ************************************************************************/
	if(TX1IE && TX1IF)  //USART1 transmit interrupt
	{
		static UINT16 tx_buffer_ndx = 1;

	//	MB_SERVER_DISPLAY.modbus_inactivity_timer = 4;

		if(MB_SERVER_DISPLAY.tx_size > 0)
		{
		//*** send next byte, increment the ndx     ***//
		//*** PIR1bits.TX1IF is read only on pic18f ***//
		
			TXREG1 = MB_SERVER_DISPLAY.data[tx_buffer_ndx++];		
			MB_SERVER_DISPLAY.tx_size -= 1;
		}
		else
		{
			while(!TXSTA1bits.TRMT); //wait until TSR is empty

			PIE1bits.TX1IE = 0;     // Disable TX interrupt for USART 1
			TXSTA1bits.TXEN = 0;    // Transmitter off		
			tx_buffer_ndx = 1; //reset the ndx for next time
			MB_SERVER_DISPLAY.last_byte = 1;
			MB_SERVER_DISPLAY.sending_response = 0;			
			RCV_485();	//output low			
		}
	}//end of if(PIR1bits.TX1IF)

	/*****  RS232 port uses uart2 and tmer4 *****/

	if(TMR4IE && TMR4IF)  
	{//pic18F45k22

		PIR5bits.TMR4IF = 0; //clear interrupt flag	

		if(MB_SERVER_RS232.modbus_timer == 1)
			MB_RS232_ServiceModbusTimers((MODBUS_SERVER_t*) &MB_SERVER_RS232);	
	} //end of if(PIR5bits.TMR4IF)


	if(RC2IE && RC2IF) //USART2 receive interrupts
	{
		BYTE data;
		modbus_errors_t error = NO_ERROR;
		if(RCSTA2bits.FERR==1)
		{
			BYTE dummy;
			Nop();
			dummy = RCREG2;
			error = SLAVE_FAILURE;
		}
		else if(RCSTA2bits.OERR == 1)	//If we had an overrun error (OERR)
		{	//toggle CREN to start it up again
			RCSTA2bits.CREN = 0;
			Nop();
			RCSTA2bits.CREN = 1;
			error = SLAVE_BUSY;
		}
		while(PIR3bits.RC2IF == 1)
		{
		//	MB_SERVER_RS232.modbus_inactivity_timer = 4;
			data = RCREG2;
			MB_RS232_CharacterReceived((MODBUS_SERVER_t*) &MB_SERVER_RS232, data, 0); // disregard error
		}

	}//end of if(PIR3bits.RC2IF) //USART2 receive interrupts

	if(TX2IE&&TX2IF) //USART2 transmit interrupts
	{
		static UINT16 tx_buffer_ndx = 1;
//	MB_SERVER_RS232.modbus_inactivity_timer = 4;

		if(MB_SERVER_RS232.tx_size > 0)
		{
		//send next byte, increment the ndx
		//PIR1bits.TX1IF is read only on pic18f		
			TXREG2 = MB_SERVER_RS232.data[tx_buffer_ndx++];		
			MB_SERVER_RS232.tx_size -= 1;
		}
		else
		{
			while(!TXSTA2bits.TRMT); //wait until TSR is empty
			PIE3bits.TX2IE = 0;     // Disable TX interrupt for USART 1
			TXSTA2bits.TXEN = 0;    // Transmitter off		
			tx_buffer_ndx = 1; //reset the ndx for next time
			MB_SERVER_RS232.last_byte = 1;
			MB_SERVER_RS232.sending_response = 0;							
		}

	}//end of if(PIR3bits.TX2IF) //USART2 transmit interrupts

	/*general use timer*/
	if(TMR1IE && TMR1IF)
	{     /*timer1 overflow interrupt ,1ms */
 		PIR1bits.TMR1IF = 0; //clear interrupt flag
		TMR1H = 0xFC;  //Fosc = 32MHZ, 0xFC18+999 = 0xFFFF, 1ms
		TMR1L = 0x18; 
      
    	if(!divide_for_10ms) 
			do_10ms_flag = ON;
		else 
			divide_for_10ms--;

		if(!divide_for_50ms) 
			do_50ms_flag = ON;
		else 
			divide_for_50ms--;

		if(!divide_for_100ms) 
			do_100ms_flag = ON;
		else 
			divide_for_100ms--;	
	  
		if(!divide_for_1second) 
			do_1second_flag = ON;
		else 
			divide_for_1second--;

		if(!divide_for_5second)
			do_5second_flag = ON;
		else
			divide_for_5second--;

		if(!divide_for_1minute) 
			do_1minute_flag = ON;
		else 
			divide_for_1minute--;	  
		   	  
	      // 1ms code
		for(i=0; i<NUM_ONE_MS_TIMER; i++)
			if(one_ms_timer[i]) 
				one_ms_timer[i]--;
	#if(0)
    //test code
		TRISAbits.TRISA4 = 0; //RA4 output
		if(PORTAbits.RA4 ==0)
			LATAbits.LATA4 = 1;
		else
			LATAbits.LATA4 = 0;    
	#endif
	} //end of if(TMR1IE && TMR1IF)
  
} //end of interrupt function

void interrupt low_priority Low_IRS(void)
{

}

/*Production test-RS232*/
BYTE Process_MB_TestCmd(BYTE cmd)
{
	BYTE ret_val = 1;
	switch(cmd)
	{	
		case TURN_ON_FUEL_PUMP:		//0
			FUEL_PUMP_ON();
		break;
		case TURN_ON_GLOW_PLUG:		//1
			GLOW_PLUG_ON(); 
		break;
		case TURN_ON_STARTER:		//2
			STARTER_ON();
		break;
		case TRUN_ON_COMPRESSOR:	//3
			COMPRESSOR_CLUTCH_ON();
		break;
		case TURN_ON_HEAT:			//4
			HEAT_MODE_ON();
		break;
		case TURN_ON_COOL:			//5
			COOL_MODE_ON();
		break;
		case TURN_ON_EVAP_FAN:		//6
			EVAPORATOR_FAN_ON();
		break;
		case TURN_ON_SPARE:			//7
			SPARE_OUT_ON();
		break;
		case TURN_ON_EVAP_PWM:		//8
			EVAPORATOR_PWM_ON();
		break;
		case TURN_ON_CONDENSER_PWM:	//9
			CONDENSOR_PWM_ON();
		break;
		case TURN_ON_ALL:			//10

		break;
		case TURN_OFF_ALL:			//11
			TurnOffAllOutputs();
		break;

		case ENTER_PRODUCTION_TEST_MODE:	//111
			product_test_mod_enabled = 0xAA;
		break;

		case EXIT_PRODUCTION_TEST_MODE:		//222
				product_test_mod_enabled = 0;
		break;

		default:
			ret_val = 0;
		break;
	}
	
	return ret_val;
}

void TurnOffAllOutputs(void)
{
	FUEL_PUMP_OFF();	
	GLOW_PLUG_OFF();
	STARTER_OFF();
	COMPRESSOR_CLUTCH_OFF();
	HEAT_MODE_OFF();
	COOL_MODE_OFF();
	EVAPORATOR_FAN_OFF();
	SPARE_OUT_OFF();
	CONDENSOR_PWM_OFF();
	EVAPORATOR_PWM_OFF();
}


//====================10/17/2013==================================
/*****************************************************************
* CabTempAdjustment() is called by BackgroundTasks()
* Functionality: Once the gas pump is on, for each minute that passes 
* subtract one degree cab temp. Do this for one, two and three minutes
* past for a total of -3F after three minutes of gas pump is on.
* For each minute that passes after the fuel solenoid is tured off 
* after being on add one degree, do this for one and two minutes with 
* the third minute reading back to true reading.
*****************************************************************/
void CabTempAdjustment(void)
{	
	if(FUEL_PUMP_STATE == ON)
	{
		fuel_off_timer_start_flag = OFF;
		if(cab_temp_offset < 3 )	//3
		{
			if(fuel_on_timer_start_flag == OFF)
			{
				fuel_on_timer_start_flag = ON;
				one_second_timer[FUEL_PUMP_ONOFF_TIMER] = 60;  //60 seconds
			}
			else
			{				
				if(one_second_timer[FUEL_PUMP_ONOFF_TIMER] == 0)
				{
					cab_temp_offset++;
					fuel_on_timer_start_flag = OFF;					
				}			
			}
		}
		else
		{
			fuel_on_timer_start_flag = OFF;
		}		
	}
	else  
	{	//fuel pump is off
		fuel_on_timer_start_flag = OFF;
		if(cab_temp_offset > 0)
		{
			if(fuel_off_timer_start_flag == OFF)
			{
				fuel_off_timer_start_flag = ON;
				one_second_timer[FUEL_PUMP_ONOFF_TIMER]= 60;
			}
			else 
			{
				if( one_second_timer[FUEL_PUMP_ONOFF_TIMER] == 0)
				{
					cab_temp_offset--;
					fuel_off_timer_start_flag = OFF;
				}
			}
		}
		else
		{
			fuel_off_timer_start_flag = OFF;
		}
	}
} //end of  CabTempAdjustment(void);

//================================================================
