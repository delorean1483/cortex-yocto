/**
 *  file: analog.c
 **/

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/
#include "include_all.h"


analog_type analog_data[NUMBER_OF_ADCS]; 

extern WORD cabin_accum;
extern char cabin_count;
extern WORD cabin_average;
extern WORD cabin_data[8];
extern BYTE ext_temp_sensor_state;

extern UINT16 	cabin_temperature;
extern UINT16	engine_temperature;
extern INT16	external_temperature ;
extern UINT16	low_side_pressure;
extern UINT16	high_side_pressure;
extern UINT16	battery_voltage; 
extern UINT16  ext_temp_adcreading;

extern UINT16   vref_calibration;
extern signed int	temperature_calibration;

int tempo_globe;//debug only

/*************************************************************************
*   Application Specific Globals
**************************************************************************/
/****************************************************************
 * Sensor Temperature Table		    		                    *
 * See "thermistor.xls"    					                    *
 * Note: the maximum table entry needs to  be 14 in order to    *
 *       be compatable with previous software.                  *
 ****************************************************************/
#define MAX_TEMPERATURE_TABLE_ENTRY 14	//14 

/*Kohler engine coolant temp sensor table(data sheet's T2)*/
const long temperature_table[MAX_TEMPERATURE_TABLE_ENTRY][2] =
{//{Counts, Temperature(�F)
    {1020,0},	//(1023, thermister disconnected)
	{843,-4},	//2.06v,
	{579,20},
	{448,32},	//1.09v
	{345,50},
	{244,68},	//0.59v
	{210,80},
	{176,92},
	{143,104},	//0.35v
	{122,120},
	{96,140},	//0.23v
	{71,176}, 	//0.17v
	{60,212},	//0.15v
	{54,248}, 	//0.13v	
};

/*QT06024C-017 curve Z temp sensor table*/ 
//{//{Counts, Temperature(�F)
//	{1020,0},	//(1023, thermister disconnected)
//	{932,23},	// Approx. = 2.28V, 
//	{803,32},
//	{684,41},
//	{579,50},
//	{486,59},
//	{403,68},
//	{338,77},
//	{281,86},
//	{236,95},
//	{196,104},
//	{160,113},
//	{136,122},	
//	{115,131},  //0.277V

//}; // NOTE: 14 Elements


//#pragma code


int Read_ADC(unsigned char channel)
{     
    /*ADC initializtion*/     
	//ADCON2 = 0xBE;  //  // right justified, 20Tad, Fosc/64	   
	channel &= 0x1F;	// truncate channel to 5 bits
	ADCON0 &= 0x83;		// clear current channel select
	ADCON0 |= (channel<<2);		// apply the new channel select
	ADCON0bits.ADON = 1;           // Turn on ADC module	
	ADCON0bits.GO_DONE = 1;	// initiate conversion on the selected channel
	while(ADCON0bits.GO_DONE) {;}

	// return 10 bit of the result
	return (ADRESL + (ADRESH + ADRESH * 255));  //left justified	
}


/*
	read_and_store_analog function
	Reads and stores values read from ADC.
*/

void Read_And_Store_Analog(unsigned char channel,unsigned char adc_channel)
{	
	analog_data[channel].avg_accum += Read_ADC(adc_channel);	// Read the analog channel
	analog_data[channel].avg_count++;
	if(analog_data[channel].avg_count >= analog_data[channel].readings_to_average)
	{
		analog_data[channel].average_value = analog_data[channel].avg_accum / analog_data[channel].readings_to_average;
		analog_data[channel].avg_accum = 0;
		analog_data[channel].avg_count = 0;
	}
}

/*****************************************************************************
** Function name:  Read_And_Update_Cabin_Temp(). 
** Functionality: read ADC and update the average output at every excution. **
**				  This function should be called on a timely routine.
** Input: analog channel number
*****************************************************************************/

//this function was called at DO_5Second() rountine
void Read_And_Update_Cabin_Temp(unsigned char adc_channel)
{

	BYTE i;
	if(cabin_count >= 8)
		cabin_count = 0;

	cabin_data[cabin_count++]= Read_ADC(CABIN_TEMP_ANCH);
	cabin_accum=0;
	for(i=0; i < 8; ++i)
	{
		cabin_accum += cabin_data[i];
	}
	cabin_average = cabin_accum / 8;
}


	//Read_And_Store_Analog(INDEX_CABIN_TEMP,CABIN_TEMP_ANCH)         
    //analog_data[INDEX_CABIN_TEMP].average_value   //read cabin temperature          

//ReadAnalog() should be called in a timer routine. now it's called at Do_1second().
void ReadAnalog(void)  //Process_Analog_data
{
	// read cabin temperature was moved to 5second routine
    //unit F of cabin_temperature, the convertion to celsius will be in display micro.
	//cabin_temperature = (UINT16)Find_Cabin_Temperature();  
	
	// 204 is calculated from voltage divide of 10K/2.49K
    //battery_voltage =((unsigned long)analog_data[INDEX_BATTERY_V].average_value * (unsigned long)vref_calibration)/204 + DIODE_V_DROP; //Vref=2.5V
		
	//if the voltage divide is 30.1k/2.49K, then use the following formular
	//battery_voltage =((unsigned long)analog_data[INDEX_BATTERY_V].average_value * (unsigned long)vref_calibration)/78 + DIODE_V_DROP; //Rev.A PCB

	battery_voltage =((unsigned long)analog_data[INDEX_BATTERY_V].average_value * (unsigned long)vref_calibration)/78 ; //Rev.B PCB
	
 	//get non-processed ADC readings
	engine_temperature = analog_data[INDEX_ENGINE_TEMP].average_value;  //for future
	low_side_pressure = analog_data[INDEX_LOW_SIDE_P].average_value;	//for future
	high_side_pressure = analog_data[INDEX_HIGH_SIDE_P].average_value;	//for future	
	ext_temp_adcreading = analog_data[INDEX_EXT_TEMP].average_value;  //for testing 		
}



INT16 ReadNTCTemperature(void)
{
	INT16 temp_value = 0;

	temp_value = analog_data[INDEX_EXT_TEMP].average_value;	 //sampling every 100ms

//	temp_value = ((unsigned long)temp_value *vref_calibration) / 250; //calibration first
	
	if(temp_value > temperature_table[0][0])	// 1020 Sensor disconnected or reading below lowest temperature
	{		
		ext_temp_sensor_state = OFF; //no external temp sensor detected
		temp_value = (INT16)temperature_table[0][1];	// give the value of 0 (0�F),no display on status screen7
	}
	else if(temp_value == 0)		// Sensor shorted out
	{
		ext_temp_sensor_state = OFF;  
		temp_value = (INT16)temperature_table[0][1];	// give the value of 0 (0�F)
	//	error_state = Bad_Ext_Temp_Sensor;
	}
	else if(temp_value <= temperature_table[MAX_TEMPERATURE_TABLE_ENTRY - 1][0])
	{  // the temp. is over the max monitored temperature (248�F),
		//temp_value = (INT16)temperature_table[MAX_TEMPERATURE_TABLE_ENTRY - 1][1];
		//ext_temp_sensor_state = ON;

		//any temp above 248�F,read as no temp sensor detected
		ext_temp_sensor_state = OFF;  
		temp_value = (INT16)temperature_table[0][1];	// give the value of 0 (0�F)	
	}	
	else if(temp_value > temperature_table[1][0])  // reading is great than 843
	{
		temp_value = (INT16)temperature_table[1][1];	// display -4�F when temp is less than -4�F
		ext_temp_sensor_state = ON;	
	}
	else
	{
		temp_value = ((long)temp_value *vref_calibration) / 250; 	//calibration first
		temp_value = FindNTCTemperature(temp_value);
		ext_temp_sensor_state = ON;
	}

	return temp_value;
}

/*************************************************************************
* FindNTCTemperature()
*
* Use interpolation to determine the temperature in degrees Farenheit,
* given the ADC counts and the lookup tables.
*
* 1) The ADC counts will fall in between two elements in Counts_Table
*	  these will be prev and loop.
* 2) Determine the difference between these two (loop - Prev)
* 3) Determine the difference between counts and Prev
* 4) Apply the ratio of these two to the temperature_table to get the
*	  temperature value
**************************************************************************/
INT16 FindNTCTemperature(long counts)
{
	BYTE loop = 0;					// index to next highest element
	BYTE prev;				        // index to next lower element
	UINT16 interval;					// # of counts between the two
	UINT16 index;						// # of counts from the prev
	UINT16 temperature_interval;		// # of inches between 2 elements
	INT16 new_temperature;					// The signed distance
	
	while (counts <= temperature_table[loop][0])
		loop++;
	if (loop)
		prev = loop - 1;
	
	interval =(UINT16)(temperature_table[prev][0] - temperature_table[loop][0]);
	index = (UINT16)(temperature_table[prev][0] - counts);
	
	temperature_interval = (UINT16)(temperature_table[loop][1] - temperature_table[prev][1]);
	new_temperature =(INT16)(temperature_table[prev][1] + (((long)index * temperature_interval) / interval));	
	return new_temperature;
}


#if(0)
signed int Find_Cabin_Temperature(void)
{
	double counts;
	double slope;
	double offset;
	double temp_var;

	counts = cabin_average;

	counts = (counts * vref_calibration) / 250;	

//	counts = (((unsigned long) counts) * ((unsigned long) vref_calibration)) / 250;	// Vref+ is 2.5V

	if(counts <= 281)		//  281 ZONE I 140
	{
		slope = 80;		//80  //160
		offset = 232;
	}
	else if(counts <= 348)	// 348 ZONE II  174
	{
		slope = 67;   		//67  //134
		offset = 196;
	}
	else if(counts <= 423)	// 423 ZONE III 211
	{
		slope = 60;			//60  //120
		offset = 171;
	}
	else if(counts <= 508)	// 508 ZONE IV  254
	{
		slope = 53;			//53  //106
		offset = 141;
	}
	else if(counts <= 635)	// 635 ZONE V  317
	{
		slope = 47;			//47 //94
		offset = 110;
	}
	else if(counts <= 777 )	//  777 ZONE VI 388
	{
		slope = 42;			//42  //84
		offset = 78;
	}
	else					// Zone VII
	{
		slope = 38;			//38  //76
		offset = 47;
	}

	if(counts > 500)	// 500 Change to unsigned math so we don't overflow.250
	{
		temp_var = counts;
		counts = (((slope * temp_var)/100) - offset);  //convert counts to temperature in unit  F
	}
	else
	{
		counts = (((slope * counts)/100) - offset);   //convert counts to temperature in unit  F
	}

//	raw_temp = counts;
   tempo_globe = counts;//debug only
	counts = counts + temperature_calibration;	// Calibrate for offset in temp circuit


	if(counts > 302)
		counts = 302;
	if(counts < -67)
		counts = -67;		// Can't display anything less than -67.

	return (signed int)counts;	
}
#endif

signed int Find_Cabin_Temperature(void)
{
	signed int counts;
	unsigned int slope;
	unsigned int offset;
	unsigned int temp_var;

//	counts = analog_data[INDEX_CABIN_TEMP].average_value;
	counts = cabin_average;

	counts = (((unsigned long) counts) * ((unsigned long) vref_calibration)) / 250;	

//	counts = (((unsigned long) counts) * ((unsigned long) vref_calibration)) / 250;	// Vref+ is 2.5V

	if(counts <= 281)		//  281 ZONE I 140
	{
		slope = 80;		//80  //160
		offset = 232;
	}
	else if(counts <= 348)	// 348 ZONE II  174
	{
		slope = 67;   		//67  //134
		offset = 196;
	}
	else if(counts <= 423)	// 423 ZONE III 211
	{
		slope = 60;			//60  //120
		offset = 171;
	}
	else if(counts <= 508)	// 508 ZONE IV  254
	{
		slope = 53;			//53  //106
		offset = 141;
	}
	else if(counts <= 635)	// 635 ZONE V  317
	{
		slope = 47;			//47 //94
		offset = 110;
	}
	else if(counts <= 777 )	//  777 ZONE VI 388
	{
		slope = 42;			//42  //84
		offset = 78;
	}
	else					// Zone VII
	{
		slope = 38;			//38  //76
		offset = 47;
	}

	if(counts > 500)	// 500 Change to unsigned math so we don't overflow.250
	{
		temp_var = counts;
		if((slope * temp_var)%100 > 50)
			counts = (((slope * temp_var)/100) - offset)+1;
		else
			counts = (((slope * temp_var)/100) - offset);  //convert counts to temperature in unit  F
	}
	else
	{
		if((slope * counts)%100 > 50)
			counts = (((slope * counts)/100) - offset)+1;
		else
			counts = (((slope * counts)/100) - offset);   //convert counts to temperature in unit  F
	}

//	raw_temp = counts;
   tempo_globe = counts;//debug only
	counts = counts + temperature_calibration;	// Calibrate for offset in temp circuit

	if(counts > 302)
		counts = 302;
	if(counts < -67)
		counts = -67;		// Can't display anything less than -67.

	return counts;	
}


