/**
 *  file: analog.h
 **/

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef _ANALOG_H_
#define _ANALOG_H_

#define MAX_CABIN_TEMP_SAMPLE	8



//ADC input channels
#define CABIN_TEMP_ANCH		0	//AN0
#define ENGINE_TEMP_ANCH	1	//AN1
#define EXT_TEMP_ANCH		4	//AN4
#define HIGH_SIDE_P_ANCH	5	//AN5
#define LOW_SIDE_P_ANCH		6	//AN6
#define BATTERY_V_ANCH		7	//AN7

enum analog_input_list
{
	
	INDEX_ENGINE_TEMP = 0,
	INDEX_EXT_TEMP = 	1,
	INDEX_LOW_SIDE_P =	2,
	INDEX_HIGH_SIDE_P =	3,
	INDEX_BATTERY_V = 	4,
	INDEX_CABIN_TEMP = 	5,
	NUMBER_OF_ADCS
};


/*code sample*/


/*Read_And_Store_Analog() should be called in the timely routine, like in do_100ms()*/


typedef struct {
	WORD avg_accum;
    char avg_count;
	char readings_to_average;
	WORD average_value;
} analog_type;

extern analog_type analog_data[NUMBER_OF_ADCS];

 //WORD cabin_accum;

 //char cabin_count;
 //WORD cabin_average;
 //WORD cabin_data[8];



/************************************************************************************
*   Function prototypes
*************************************************************************************/


void Read_And_Store_Analog(unsigned char channel, unsigned char adc_channel);

int Read_ADC(unsigned char channel);

INT16 ReadNTCTemperature(void);
INT16 FindNTCTemperature(long);
signed int Find_Cabin_Temperature(void);
void ReadAnalog(void);

void Read_And_Update_Cabin_Temp(unsigned char);

#endif
