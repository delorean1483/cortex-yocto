/*********************************************************
*file name: main.h
*********************************************************/
/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef MAIN_H_
#define MAIN_H_

//#define USE_24VDC_BATTERY

#define TRUCK_ENGINE_INTERRUPT


//Bootloader works only on baudrate 9600

#define BAUD_RATE_RS485_DSPL   9600 //  only 9600 and 19200 work
#define BAUD_RATE_RS232_DSPL   9600 //  only 9600 and 19200 work

#define VREF_CAL_INIT	250	//245 //measurement of TP92 on board
#define TEMP_CAL_INIT  	0   //difference of on board sensor reading and calibration OMEGA meter 

#ifdef USE_24VDC_BATTERY
	#define CC_LOW_V_LIMIT			2340   	//23.4V
	#define OFF_LOW_V_LIMIT			2200	//22.0V
	//initial value
	#define BATT_MONITOR_V_INIT  	2400  	//24.0v
	#define STORAGE_V_INIT			2360	//23.6v

	//battery monitor mode setting limits
    #define BATT_MONITOR_HIGH       2560  //25.6v
    #define BATT_MONITOR_LOW        2200  //22.0v
	//cold storage mode battery voltage setting limits
	#define STORE_BATT_HIGH         2560  //25.6v
    #define STORE_BATT_LOW          2200  //22.0v

#else
	#define CC_LOW_V_LIMIT			1170   	//11.7V
	#define OFF_LOW_V_LIMIT			1100	//11.0V
	//initial value
	#define BATT_MONITOR_V_INIT  	1200  	//12.0v
	#define STORAGE_V_INIT			1180	//11.8v

	//battery monitor mode setting limits
    #define BATT_MONITOR_HIGH       1280  //12.8v //13.5v
    #define BATT_MONITOR_LOW        1100  //11.0v //10.8v
	//cold storage mode battery voltage setting limits
 	#define STORE_BATT_HIGH         1280  //12.8v //13.5v
    #define STORE_BATT_LOW          1100  //11.0v //10.8v

#endif

#define EVAPORATOR_PWM_PERIOD    	22  //22 milliseconds
#define EVAP_PWM_PULSE_WIDTH_LOW  	7   //7 milliseconds
#define EVAP_PWM_PULSE_WIDTH_MEDIUM 12  //12 milliseconds
#define EVAP_PWM_PULSE_WIDTH_HIGH   22  //22 milliseconds

#define DEFROST_INTERVAL  			30  //60 minutes
		
//oil change warning definition
#define HOURS_OIL_CHANGE_SOON		500
#define HOURS_OIL_CHANGE_NOW		580
#define HOURS_OIL_CHANGE_MISSED		700

#define ENGINE_RPM_LOW_LIMIT   		1000	//10-16-13	2700 //1900 7-25-2013

//initial values
#define CLMT_TEMP_INIT  70
#define STORAGE_T_INIT	30 			//50  changed 1/24/2014


#define CC_TEMP_OFFSET	       3    //2  //this is the value off the set point to start/stop the heating/cooling
#define HEAT_COOL_TRANS_TIME   6000	//3000 //500   //1000*10ms= 10s 
//#define DIODE_V_DROP	28 // there is .30V forward voltage drop on diode D1 Rev. A board only

//digital inputs
#define Oil_Pressure		PORTBbits.RB5
#define Truck_Engine_State	PORTBbits.RB1

#define Engine_RPM_State	PORTCbits.RC1

//digital outputs, read the pins
//#define Evaporator_PWM_State	PORTCbits.RC2



//write to the pins
#define EVAPORATOR_PWM_ON()		(LATCbits.LATC2 = 1)  	//
#define EVAPORATOR_PWM_OFF()	(LATCbits.LATC2 = 0)  	//logic was reversed on the output drive circuit

#define SPARE_OUT_ON()			(LATBbits.LATB3 = 1)
#define SPARE_OUT_OFF()			(LATBbits.LATB3 = 0)
#define CONDENSOR_PWM_ON()		(LATDbits.LATD1 = 1)
#define CONDENSOR_PWM_OFF()		(LATDbits.LATD1 = 0)

#define FUEL_PUMP_ON()			(LATDbits.LATD0 = 1)  	//Rev 1.
#define FUEL_PUMP_OFF()			(LATDbits.LATD0 = 0)
#define	STARTER_ON()			(LATDbits.LATD2 = 1)  	//Rev 1.
#define	STARTER_OFF()			(LATDbits.LATD2 = 0)
#define COMPRESSOR_CLUTCH_ON()	(LATDbits.LATD3 = 1)	//Rev 1.
#define COMPRESSOR_CLUTCH_OFF()	(LATDbits.LATD3 = 0)
#define HEAT_MODE_ON()			(LATDbits.LATD4 = 1)	//Rev 1.
#define HEAT_MODE_OFF()			(LATDbits.LATD4 = 0)
#define GLOW_PLUG_ON()			(LATDbits.LATD5 = 1)	//Rev 1.
#define GLOW_PLUG_OFF()			(LATDbits.LATD5 = 0)
#define EVAPORATOR_FAN_ON()		(LATCbits.LATC3 = 1)	//Rev 1.
#define EVAPORATOR_FAN_OFF()	(LATCbits.LATC3 = 0)
#define COOL_MODE_ON()			(LATCbits.LATC4 = 1)	//Rev 1.
#define COOL_MODE_OFF()			(LATCbits.LATC4 = 0)



#define XMIT_485()			(LATCbits.LATC5 = 1)
#define RCV_485()			(LATCbits.LATC5 = 0)

#define COMPRESSOR_STATE  	PORTDbits.RD3
#define COOL_MODE_STATE		PORTCbits.RC4
#define HEAT_MODE_STATE  	PORTDbits.RD4
#define EVAP_FAN_STATE		PORTCbits.RC3
#define FUEL_PUMP_STATE		PORTDbits.RD0
#define GLOW_PLUG_STATE     PORTDbits.RD5
#define STARTER_STATE		PORTDbits.RD2


/****************************************************************************
*   Global Peripheral Declarations
****************************************************************************/
//--------------------------------------------------------------------------
// Timer and counter defines														
//--------------------------------------------------------------------------

#define DIVIDE_FOR_10MS					9
#define DIVIDE_FOR_50MS					49			// The number of 1ms timer interrupts per 50 ms
#define DIVIDE_FOR_100MS				99			// The number of 1ms timer interrupts per 100 ms
#define DIVIDE_FOR_1SECOND				999			// The number of 1ms timer interrupts per 1 second
#define DIVIDE_FOR_5SECOND				1999			//5 second---4999
#define DIVIDE_FOR_1MIN					59999		// The number of 1ms timer interrupts per 1 minute

#define DEBOUNCE_TIME	               	10   //100ms	// 20ms-The number of 1ms timer interrupts per 10 ms
//#define BIN_EMPTY_DEBOUNCE_TIME	       	500			// The number of 1ms timer interrupts per 500 ms
#define SENSOR_AVG 						10 			// number of samples taken for avg

typedef union{
	unsigned char byte;
	struct{
		unsigned char _0 : 1;
	    unsigned char _1 : 1;
	    unsigned char _2 : 1;
	    unsigned char _3 : 1;
	    unsigned char _4 : 1;
	    unsigned char _5 : 1;
	    unsigned char _6 : 1;
	    unsigned char _7 : 1;
	} b;
} bittype;

extern bittype flag0,flag1,flag2;

#define do_10ms_flag		flag0.b._0
#define do_50ms_flag        flag0.b._1
#define do_100ms_flag       flag0.b._2              
#define do_1second_flag     flag0.b._3
#define do_5second_flag		flag0.b._4
#define do_1minute_flag		flag0.b._5

#define Fuel_Pump			flag1.b._0
#define Starter				flag1.b._1
#define Compressor_Clutch 	flag1.b._2
#define Glow_Plug			flag1.b._3
#define Heat_Mode			flag1.b._4
#define Cool_Mode			flag1.b._5
#define Evaporator_Fan		flag1.b._6
#define Spare_Out			flag1.b._7

#define storage_charging_batt_flag 	flag2.b._0 //indicate engine start to charge batt in storage mode
#define clmt_low_batt_tmr_flag 		flag2.b._1 //start the low battery timer in climate control mode

#define no_rpm_tmr_start_flag		flag2.b._2 //no rising edge on ccp2 timer starts flag

#define evap_fan_always_on_flag		flag2.b._3 //evaporator was set to always on.

#define fuel_on_timer_start_flag   	flag2.b._4 	// fuel pump is on, for cab temp offset 10/17/2013
#define fuel_off_timer_start_flag	flag2.b._5	//fuel pump is off, for cab temp offset 10/17/2013

#define low_rpm_tmr_start_flag		flag2.b._6  //rpm lower than set point  1/13/2014
#define ac_high_pres_happened_flag	flag2.b._7	//1/15/2014

enum one_ms_timer_list
{
	EVAP_PWM_PERIOD_TMR=0,
	EVAP_PWM_ON_TMR,
	NUM_ONE_MS_TIMER

};

enum ten_ms_timer_list
{
	SHORT_DELAY_TMR =0,
	RPM_STOP_TMR, 			//ten_ms_timer[RPM_STOP_TMR]
	NUM_TEN_MS_TIMER
};

enum one_hundred_ms_timer_list
{
	GLOW_PLUG_ON_TMR = 0,
	RPM_LOW_TMR,		//1/13/2014 one_hundred_ms_timer[RPM_LOW_TMR]
	NUM_100_MS_TIMER
};
	
enum one_second_timer_list
{
	POWER_UP_TMR =0,
	//GLOW_PLUG_ON_TMR,
	EVENT_INTERVAL_TMR,
	COMP_EVAP_DELAY_TMR,
	BATT_STABLE_TMR,
	COMPRESOR_OUT_TMR,
	FUEL_PUMP_ONOFF_TIMER,   //10/17/2013
    EVAP_FORCED_ON_TMR,	//6/18/2015
	NUM_ONE_SECOND_TIMER
	
};

enum one_minute_timer_list
{
	CHARGING_BATT_TMR=0,
	NEXT_OIL_WARNING_TMR,
	DEFROST_CYCLE_TMR,		//
	CLMT_LOW_BATT_TMR,
	CABIN_TEMP_WARMUP_TMR,
	NUM_ONE_MINUTE_TIMER
};

extern UINT16 one_ms_timer[NUM_ONE_MS_TIMER];
extern UINT16 ten_ms_timer[NUM_TEN_MS_TIMER];
extern UINT16 one_hundred_ms_timer[NUM_100_MS_TIMER];
extern UINT16 one_second_timer[NUM_ONE_SECOND_TIMER];
extern UINT16 one_minute_timer[NUM_ONE_MINUTE_TIMER];


/************************************************************************************
*	Switch processing routines
*	The following code implements switch objects which abstracts processing and
*	debouncing algorithms for switches.
*
*************************************************************************************/

typedef struct {
	unsigned char previous_state :1; //used internally by object
	unsigned char debounced_state :1; //debounced switch state read by application
	enum {
		SERVICE_NOT_NEEDED, SERVICE_NEEDED
	} service_state; //read by app
	unsigned int debounce_tmr; //used internally by object
	unsigned int debounce_time; //set initially by app, used internally
	unsigned int hold_timer;
	unsigned int release_timer;
} discrete_input_t;

enum temp_unit_list{
    FAHRENHEIT = 0,
    CELSIUS
};

enum switch_state_list		// Debounce routines
{
	SWITCH_OPEN = 0,
	SWITCH_CLOSED
};

enum evap_speed_list
{
	LOW = 0,
    MEDIUM,
    HIGH,
    //L_ALWAYS,
    //M_ALWAYS,
    //H_ALWAYS
};

enum pressure_state_list
{
	OK = 0,
	NOK =1
};

enum time_scale{
    AM=0,
    PM
};

//#define	ON	1
//#define	OFF	0

enum operation_mode_state_list
{
	OFF_MODE = 0,
	CLIMATE_CONTROL_MODE,
	BATTERY_MONITOR_MODE
	//COLD_STORAGE_MODE
};

enum error_message_state_list
{
	NO_OP_ERROR = 0,
	LOW_OIL_PRESSURE ,			//screen 15
	HIGH_ENGINE_TEMPERATURE,	//screen 11				
	LOW_BATTERY,				//screen 13--charge failure
	AC_LOW_PRESSURE_FAILURE,	//screen 5
	AC_HIGH_PRESSURE_FAILURE,
	STARTING_FAILURE,			//screen 17
	STANDBY,					//screen 22 -- key_switch interrupt	
	ENGINE_STALLED,				//low engine RPM detected,record the error to the error log only
	NO_RPM_DETECTED,			//no rpm detected.
	HIGH_AC_PRESSURE_ERROR		//AC pressure is high
};

enum oil_message_state_list
{
	OIL_GOOD = 0,
	OIL_CHANGE_SOON,			//screen 21,start at 500, warning appears every 20 hrs
	OIL_CHANGE_NEEDED,			//screen 19,start at 580, warning appears every 20 hrs
	OIL_CHANGE_PAST_DUE,		//screen 20, start at 700. warning appears every 5 hrs
	OIL_WARNING_DISMISSED		//oil change warning screen was manually dismissed
};

enum control_status_list  //engine, climate, battery monitor status
{
	CONTROL_OFF = 0,
	WARMING_UP,	//when glow plug is on
	STARTING,	//starter is on
	RUNNING,	//fuel is on but there is no heating or cooling
	DEFROST,  	//at climate control cycle
	CHARGING,	//battery monitor cycle
	COOLING,	//cooling
    CHILLIN     //neither heating nor cooling
};


enum engine_start_state_list
{
	ES_GLOWPLUG_ON = 0,	//0,entry state, cycle the glow plug,on-30s-off
	ES_HEAT_ON,			//1,cycle heat on-1s-off
	ES_FUEL_ON,			//2,turn on fuel pump 1s
	ES_STARTER_ON,		//3,cycle starter, on-2s-off
	ES_ENGINE_ON,		//4,engine on, wait 5s
	ES_CHECK_PRESSURE,	//5,check oil pressure
	ES_COOL_ON			//6,turn on cool
};

enum clmt_ctrl_state_list
{
	CC_START_SETTLE = 0,		//enter state, add 1 second for display to settle
	CC_START_ENGINE,  			// start the engine
	CC_MONITOR_TEMP, 			// monitor temperature
	CC_START_COOL,				// turn on cool mode
	CC_SWITCH_TO_COOL,			// switch to cool from heat
	CC_COMP_ON, 				// turn on compressor
	CC_AC_LOW_PRESSURE_RECHK,	// check coolant pressure
	CC_EVAP_ON,					// turn on evaporator
	CC_CTRL_RUNNING,			// heating or cooling is running
	CC_HEAT_DEFROST,			// heat cycle defrost
	CC_COOL_DEFROST_END,		// continue cooling cycle
	CC_HEAT_SWITCHFROM_COOL,		// all heating from cooling dynamically
	CC_EVAP_OFF,				// turn off evaporator,
	CC_AC_LOW_PRESSURE_FAIL,	// pressure failed.
	CC_AC_HIGH_PRESSURE_FAIL,	//
	CC_ANTI_STALL_STEP1,		// RPM anti_stall, start 5 mins compressor off time delay
	CC_ANTI_STALL_STEP2,		// turn compressor back on 
	CC_AC_HIGH_PRESSURE_RECHK,	// high pressure check
	CC_WAIT_HIGH_PRESSURE_NORMAL	//added on 4/30/2014
	
};

enum battery_monitor_state_list
{
	BM_START = 0,			//enter state
	BM_BATT_MONITOR,		//monitoring the battery
	BM_START_ENGINE,		//battery needs to charge, start engine
	BM_CHARGING,			//charging 30 minutes
	BM_BATT_STABLE_2MIN,	//battery rests 2minute after charge
	BM_BATT_CHECK,			//measure voltage
	BM_ERROR_PROCESS		//6 battery error 

};

enum cold_storage_state_list
{
	CS_START = 0,				//	add 1second to settle the display 
	CS_MONITOR,					//	monitor the battery and temperature
	CS_LV_START_ENGINE, 		//  start engine due to low battery 
	CS_LT_START_ENGINE,			//  start engine due to low temperature
	CS_LV_LT_ENGINE_ON, 		//  engine is on due to low battery or low temp
	CS_LT_HEATING_ON,			//  heating is on low temp
	CS_LT_COMP_ON,				//  compressor is on
	CS_LT_AC_LOW_PRES_RECHK,	//  recheck ac pressure
	CS_LT_EVAP_ON,				//  turn on evaporator
	CS_LT_CTRL_RUNNING,			//  heating
	CS_LT_DEFROST,				//  defrost
	CS_LV_CHARGING,				//  battery charging
	CS_LV_STABLIZING,			//  battery stablization
	CS_LT_CTRLS_OFF,			//  turn of controls
	CS_LT_AC_LOW_PRES_FAIL,		//  A/C pressure fail
	CS_LT_AC_HIGH_PRES_FAIL,
	CS_LV_BATT_FAIL, 			//  A/C battery fail
	CS_ANTI_STALL_STEP1,		// RPM anti_stall, start 5 mins compressor off time delay
	CS_ANTI_STALL_STEP2,		// turn compressor back on 
	CS_AC_HIGH_PRESSURE_CHK,		// AC high pressure check
	CS_WAIT_HIGH_PRESSURE_NORMAL, 	//added on 4/30/2014
	CS_EXT_LT_RUNNING				//added 1/12/2015

};

enum temp_disply_state_list
{
	REAL_TIME_TEMP = 0,
	CC_TEMP_SETTING,	//display climate setting
	CS_TEMP_SETTING	//display cold storage setting

};


//errors have a screen alert
//Pressure Fault (A/C Pressure Fault detected--Screen 5)
//High Engine Temp(Screen 11)
//Charge Failure  (screen 13)
//LOW oil Pressure(screen 15)
//Starting Failure(Engine failed to start screen 17)
//Oil Change Needed(oil_hour>500hours  screen 19)
//Oil Change past due(oil_hours > 700 hr screen 20)
//Oil Change Soon(oil_hour is approaching 500  screen 21)
//Standby(Key_switch interrupt active screen 22)

/**************************************************************************
 *   Application Specific Globals
 **************************************************************************/

enum discrete_input_list {
	OIL_PRESSURE = 0,			// 0
	TRUCK_ENGINE_STATE = 1,		// 1			
	H_SIDE_PRESSURE = 2,		// 2
	L_SIDE_PRESSURE = 3,		// 3
	ENGINE_TEMP = 4,			// 4

	NUMBER_OF_INPUTS
};
extern discrete_input_t discrete_inputs[NUMBER_OF_INPUTS];

typedef enum 
{
	POWER_UP_STATE =0,
	OFF_STATE,
	ENGINE_START_STATE,		
	CLIMATE_CONTROL_STATE,	
	BATTERY_MONITOR_STATE,	
	COLD_STORAGE_STATE,	
	ERROR_SHUTDOWN_STATE		
}op_type;

enum production_test_cmd_list{
	TURN_ON_FUEL_PUMP = 0,	//0
	TURN_ON_GLOW_PLUG,		//1
	TURN_ON_STARTER,		//2
	TRUN_ON_COMPRESSOR,		//3
	TURN_ON_HEAT,			//4
	TURN_ON_COOL,			//5
	TURN_ON_EVAP_FAN,		//6
	TURN_ON_SPARE,			//7
	TURN_ON_EVAP_PWM,		//8
	TURN_ON_CONDENSER_PWM,	//9
	TURN_ON_ALL,			//10
	TURN_OFF_ALL			//11
};

#define ENTER_PRODUCTION_TEST_MODE 111
#define EXIT_PRODUCTION_TEST_MODE  222

/************************************************************************************
*   Function prototypes
*************************************************************************************/
void InitializeTimerDivides(void);
void InitializeSystem(void);
void InitializeCCP_CaptureMode(void);
void Refresh_TRIS(void);
	void InitializeSwitchObjects(void);
		void InitializeSwitch(discrete_input_t *, unsigned int, unsigned char);
void CheckSwitches(void);
	void ServiceSwitch(discrete_input_t *, BYTE );

void UpdateSwitches(void);
void UpdateOutputs(void);
void CheckTimerInterrupts(void);
	void Do_10ms(void);
	void Do_50ms(void);
	void Do_100ms(void);
	void Do_1second(void);
	void Do_5second(void);
	void Do_1minute(void);
void BackGroundTasks(void);
	void ReadEngineRPM(void);

void StateMachine(void);
	void PowerUpMode(void);
	void OffMode(void);
	void EngineStartMode(void);
	
	void ClimateControlMode(void);
	void BatteryMonitorMode(void);
	void ColdStorageMode(void);		
	void ErrorShutdownMode(void);
void inc_long_term_counter(unsigned int,unsigned int );
unsigned long read_long_term_counter(unsigned int ,unsigned int );

void InitFactorySettings(void);

void interrupt All_Int_Services(void);
void interrupt low_priority Low_IRS(void);
//void Tmr1_IRQ_Handler (void);
BYTE Process_MB_TestCmd(BYTE cmd);

void TurnOffAllOutputs(void);

void CabTempAdjustment(void);	//10/17/2013

#endif /*MAIN_H_*/
