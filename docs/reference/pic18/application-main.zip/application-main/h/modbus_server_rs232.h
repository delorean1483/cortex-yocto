/*******************************************************************************
*	modbus_server_rs232.h
*	
*******************************************************************************/
/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/
#ifndef MB_MODBUS_RS232_H
#define MB_MODBUS_RS232_H

#include <include_all.h>

//Function prototypes for the modbus for the display
void MB_RS232_InitializeModbus(MODBUS_SERVER_t * pThis, BYTE);
void MB_RS232_ProcessModbus(MODBUS_SERVER_t * pThis);
void MB_RS232_CharacterReceived(MODBUS_SERVER_t * pThis, BYTE, BYTE);
void MB_RS232_ServiceModbusTimers(MODBUS_SERVER_t * pThis);

void MB_RS232_StartTimers(MODBUS_SERVER_t * pThis);
BYTE MB_RS232_ProcessFrame(MODBUS_SERVER_t * pThis);
BYTE MB_RS232_CheckFrame(MODBUS_SERVER_t * pThis);
UINT16 MB_RS232_GetCRC(MODBUS_SERVER_t * pThis, BYTE *buffer, BYTE buffer_size);
void MB_RS232_StopModbusTimer(MODBUS_SERVER_t * pThis); 
void MB_RS232_StopInterFrameTimer(MODBUS_SERVER_t * pThis);
void MB_RS232_StopInterCharTimer(MODBUS_SERVER_t * pThis);
void MB_RS232_ResetCounters(MODBUS_SERVER_t * pThis);


modbus_errors_t MB_Display_HoldingReg(MODBUS_SERVER_t * pThis, uint16_t regNumber, int16_t * data, uint8_t write);


#endif
