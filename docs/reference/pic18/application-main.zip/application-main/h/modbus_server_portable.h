/*
 * modbus_server_portable.h
 *
 */
/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef MODBUS_PORTABLE_H_
#define MODBUS_PORTABLE_H_

#define configCPU_CLOCK_HZ 8000000
#define MODBUS_SERVER_TIMER_PRESCALER 8
#define MODBUS_SERVER_BAUD 19200			//19200
#define MODBUS_SERVER_SYSCLK configCPU_CLOCK_HZ
#define MODBUS_SERVER_HALF_CHAR_TIMER_VALUE (MODBUS_SERVER_SYSCLK / MODBUS_SERVER_TIMER_PRESCALER * 10 / 2 / MODBUS_SERVER_BAUD)

	
#define _mbm_disable_interrupts_display()	TXSTA1bits.TXEN = 0; PIE1bits.RC1IE = 0; PIE1bits.TMR2IE = 0;TXSTA2bits.TXEN = 0; PIE3bits.RC2IE = 0; PIE5bits.TMR4IE = 0	//pic18F
#define _mbm_enable_interrupts_display()	TXSTA1bits.TXEN = 1; PIE1bits.RC1IE = 1; PIE1bits.TMR2IE = 1;TXSTA2bits.TXEN = 1; PIE3bits.RC2IE = 1; PIE5bits.TMR4IE = 1    //pic18F	


#define MB_USE_BULK_FILE
#define MB_USE_HOLDING_REG

#define MB_USE_INPUT_REG 

extern volatile MODBUS_SERVER_t	MB_SERVER_DISPLAY;

typedef enum
{
	TEST = 0,
	DISPLAY  = 1,
	MAX_INTERFACES
} eINTERFACE_t;



#ifdef MB_USE_HOLDING_REG
enum mb_bulk_file_list {
	//Bulf file commands
	BF_DO_NOTHING,
	BF_MODEL_NUMBER,
	BF_SERIAL_NUMBER,
	BF_CURRENT_DATE,		//this must stay at 3 to communicate to the display
	BF_RLY_BOOTLOAD,
	MAX_BULK_FILE_PARAMETER
};

#endif


typedef struct {
	uint16_t registerType;
	uint16_t registerNumber;
	uint16_t *data;

} MODBUS_SERVER_EVENT_t;



uint8_t BulkFileBlock_Display(
		uint8_t writeFlag,
		uint16_t file,
		uint16_t block,
		uint8_t * data,
		uint8_t * data_len);

void MB_Display_XmitFrame(MODBUS_SERVER_t * pThis);
void MB_Display_ResetModbusTimer(MODBUS_SERVER_t * pThis);

void MB_Display_TimerInit(int32_t baudRate);

void MB_Display_UARTInit(int32_t baudRate);

void U1_Rx_IRQ_Handler(void);
void U1_Tx_IRQ_Handler(void);
void Tmr2_IRQ_Handler (void);

#endif /* MODBUS_PORTABLE_H_ */
