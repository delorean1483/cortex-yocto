/*
 * include_all.h
 */

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef INCLUDE_ALL_H_
#define INCLUDE_ALL_H_

#include <p18cxxx.h>
#include<xc.h>

//#include <delays.h>
#include <math.h>


#include<p18f46k22.h>

#include "types.h"
#include "main.h"
#include "analog.h"
#include "eeprom.h"

#include "modbus_server.h"
#include "modbus_server_portable.h"
#include "parameters.h"

#include "modbus_server_rs232.h"
#include "modbus_server_portable_rs232.h"

#endif /* INCLUDE_ALL_H_ */
