/*
 * types.h
 */

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef TYPES_H_
#define TYPES_H_

#define _disable_interrupts()	SET_CPU_IPL(7)
#define _enable_interrupts()	SET_CPU_IPL(0)

#define uint8_t		unsigned char
#define uint16_t	unsigned int
#define uint32_t	unsigned long

#define UINT16	unsigned int
#define BYTE	unsigned char
#define UINT8   unsigned char

#define int8_t		char
#define int16_t		int
#define int32_t		long

#define INT16	int

#define float32_t	float
#define float64_t	(long double)

typedef signed int          INT;
typedef signed char         INT8;
typedef signed long int     INT32;
typedef signed long long    INT64;
typedef unsigned int        UINT;
typedef unsigned long int   UINT32;  // other name for 32-bit integer
typedef unsigned long long  UINT64;

//typedef enum _BOOL { FALSE = 0, TRUE } BOOL;	// Undefined size
#define WORD	unsigned int
#define BYTE	unsigned char
typedef unsigned long		DWORD;				// 32-bit unsigned
typedef unsigned long long	QWORD;				// 64-bit unsigned
typedef signed char			CHAR;				// 8-bit signed
typedef signed short int	SHORT;				// 16-bit signed
typedef signed long			LONG;				// 32-bit signed
typedef signed long long	LONGLONG;			// 64-bit signed


//8-bit bitfield
//example: bitfield8_t states;
//to access a bit: states.bit3 = 1;
//to access the entire byte: states.byte = 0x12;
typedef union
{
   uint8_t byte;
   struct
   {
      uint8_t bit0: 1;
      uint8_t bit1: 1;
      uint8_t bit2: 1;
      uint8_t bit3: 1;
      uint8_t bit4: 1;
      uint8_t bit5: 1;
      uint8_t bit6: 1;
      uint8_t bit7: 1;
   };

} bitfield8_t;

typedef union
{
   uint16_t word;
   bitfield8_t bytes[2];   //bytes[0] = lo_byte, bytes[1] = hi_byte
   struct
   {
      uint16_t bit0: 1;    //lo_byte.bit0
      uint16_t bit1: 1;    //lo_byte.bit1
      uint16_t bit2: 1;    //lo_byte.bit2
      uint16_t bit3: 1;    //lo_byte.bit3
      uint16_t bit4: 1;    //lo_byte.bit4
      uint16_t bit5: 1;    //lo_byte.bit5
      uint16_t bit6: 1;    //lo_byte.bit6
      uint16_t bit7: 1;    //hi_byte.bit7
      uint16_t bit8: 1;    //hi_byte.bit0
      uint16_t bit9: 1;    //hi_byte.bit1
      uint16_t bit10: 1;   //hi_byte.bit2
      uint16_t bit11: 1;   //hi_byte.bit3
      uint16_t bit12: 1;   //hi_byte.bit4
      uint16_t bit13: 1;   //hi_byte.bit5
      uint16_t bit14: 1;   //hi_byte.bit6
      uint16_t bit15: 1;   //hi_byte.bit7
   };

} bitfield16_t;

#define TRUE		1
#define FALSE		0
#define ON			1
#define OFF			0

/******************************************************************************
*   Macros
******************************************************************************/
#define SET_REG(REG,VAL)         (REG) = (VAL)
#define SET_BIT(REG,BIT)         (REG) |= (1 << (BIT))
#define CLEAR_BIT(REG,BIT)       (REG) &= ~(1 << (BIT))
#define BIT_IS_SET(REG,BIT)      ((REG) & (1 << (BIT)))
#define TOGGLE_BIT(REG,BIT)      (REG) ^= (1 << (BIT))
#define BIT_IS_CLEAR(REG,BIT)    (!((REG) & (1 << (BIT))))

#define LO_BYTE_OF_WORD(WORD)    ((uint8_t)WORD)
#define HI_BYTE_OF_WORD(WORD)    ((uint8_t)(WORD >> 8))

#define BYTE_TO_WORD_HI(BYTE)    ((uint16_t)BYTE << 8)
#define BYTE_TO_WORD_LO(BYTE)    ((uint16_t)BYTE)

#endif /* TYPES_H_ */
