/**
 * parameters.h
 */
/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef PARAMETERS_H_
#define PARAMETERS_H_

//it was in parameters.h
//////////////////////////////////
// Real Time Variable functions
//////////////////////////////////

UINT16 get_cabin_temperature(void);
UINT16 get_engine_temperature(void);
UINT16 get_ext_temperature(void);
UINT16 get_low_side_pressure(void);
UINT16 get_high_side_pressure(void);
UINT16 get_battery_voltage(void);
UINT16 get_op_mode_bttn_value(void);

UINT16 get_engine_run_time(void);
UINT8 set_engine_run_time(UINT16 value);

UINT16 get_ext_temp_adc(void);

UINT16 get_engine_oil_time(void);
UINT8  set_engine_oil_time(UINT16 value);

UINT16 get_machine_run_time(void);

UINT8  set_error_state(UINT16 value); //if the display overrides the error
UINT16 get_error_state(void);

UINT8  set_oil_state(UINT16 value);
UINT16 get_oil_pressure(void);

UINT16 get_truck_engine_state(void);
UINT16 get_engine_rpm_portstate(void);


UINT8 set_op_mode_bttn_value(UINT16 value);

UINT8 	set_evap_fan_speed(UINT16 value);
UINT16 	get_evap_fan_speed(void);

UINT8 	set_temp_setting(UINT16 value);		
UINT16 	get_temp_setting(void);

UINT8 	set_battery_setting(UINT16 value);			
UINT16 	get_battery_setting(void);

UINT8 	set_storage_temp(UINT16 value);
UINT16 	get_storage_temp(void);

UINT8 	set_storage_volt(UINT16 value);
UINT16 	get_storage_volt(void);

UINT16  get_oil_state(void);

UINT8	set_temperature_unit(UINT16 value);		
UINT16	get_temperature_uint(void);

UINT8 	set_clnd_start_state(UINT16 value);		
UINT16	get_clnd_start_state(void);

UINT8 	set_clnd_start_mode(UINT16 value);		
UINT16	get_clnd_start_mode(void);

UINT8 	set_clnd_start_year(UINT16 value);		
UINT16	get_clnd_start_year(void);

UINT8 	set_clnd_start_month(UINT16 value);		
UINT16	get_clnd_start_month(void);

UINT8 	set_clnd_start_date(UINT16 value);		
UINT16	get_clnd_start_date(void);

UINT8 	set_clnd_start_hour(UINT16 value);		
UINT16	get_clnd_start_hour(void);

UINT8 	set_clnd_start_min(UINT16 value);		
UINT16	get_clnd_start_min(void);

UINT8 	set_clnd_start_ampm(UINT16 value);		
UINT16	get_clnd_start_ampm(void);

UINT16 get_engine_status(void);
UINT16 get_control_status(void);

UINT8  set_standby_override_flag(UINT16 value);
UINT16 get_standby_override_flag(void);

UINT16 get_temperature_dspl_state(void);

UINT8 set_vref_calibration(UINT16 value);
UINT16 get_vref_calibration(void);

UINT8 set_temp_calibration(UINT16 value);
UINT16 get_temp_calibration(void);

UINT16 get_engine_rpm(void);

UINT16 get_relay_fmwr_rev(void);

UINT8 set_dspl_fmwr_rev(UINT16 value);
UINT16 get_dspl_fmwr_rev(void);

UINT16 get_prd_test_mode(void);

UINT8 set_rtcc_year(UINT16 value);
UINT16 get_rtcc_year(void);

UINT8 set_rtcc_month(UINT16 value);
UINT16 get_rtcc_month(void);

UINT8 set_rtcc_day(UINT16 value);
UINT16 get_rtcc_day(void);

UINT8 set_rtcc_weekday(UINT16 value);
UINT16 get_rtcc_weekday(void);

UINT8 set_rtcc_hour(UINT16 value);
UINT16 get_rtcc_hour(void);

UINT8 set_rtcc_minute(UINT16 value);
UINT16 get_rtcc_minute(void);

UINT8 set_rtcc_second(UINT16 value);
UINT16 get_rtcc_second(void);

UINT8 set_highac_override_flag(UINT16 value);		
UINT16 get_highac_override_flag(void);
		
UINT8 set_lowac_override_flag(UINT16 value);		
UINT16 get_lowac_override_flag(void);

UINT8 set_RTC_ID_flag(UINT16 value);
UINT16 get_RTC_ID_flag(void);

typedef enum {
	//The hardware level registers will start at 1 and end at 100
	HR_DSPL_CABIN_TEMP			= 1,	// Temperature to display, on board
	HR_DSPL_ENGINE_TEMP			= 2,	//J6_A4
    HR_DSPL_EXT_TEMP_ADC		= 3,	//J6_B10 raw adc reading
	
	HR_DSPL_LSIDE_PRESSURE		= 4,	//J6_A8
	HR_DSPL_HSIDE_PRESSURE		= 5,	//J6_B8
	HR_DSPL_BATT_VOLTAGE		= 6,	// on board
	HR_OIL_PRESSURE_STATE		= 7,	//ok/nok, J6_B4
	HR_TRUCK_ENGINE_STATE		= 8,	//on/off. APU stands by if truck engine is on J6_A5
	HR_ENGINE_RPM_PORTSTATE		= 9,  	//J6_B5 input

	HR_DSPL_OP_MODE				= 10,
	HR_DSPL_ENGINE_RUN_TIMER	= 11,  	//fuel pump on timer
	HR_EVAP_FAN_SPEED_SETTING	= 12,	//high/low
	HR_DSPL_BATT_SETTING		= 13,	//battery monitor mode
	HR_DSPL_TEMP_SETTING		= 14,	//climate control mode
	HR_STORAGE_T_SETTING        = 15,   //store_t_setting.word  cold storage mode
    HR_STORAGE_V_SETTING        = 16,   //store_v_setting.word	cold storage mode

	HR_DSPL_OP_ERROR_STATE		= 17,	//to trig the error screens
	HR_DSPL_OIL_CHANGE_STATE	= 18,	//to switch to 3 different warning screens
	HR_DSPL_TEMP_UNIT			= 19,	//F/C

	

	HR_DSPL_ENGINE_OIL_TIMER	= 20, 	//engine oil timer
	HR_DSPL_MACHINE_RUN_TIMER	= 21, 	//machine run timer, also called APU timer

	HR_DSPL_ENGINE_STATUS		= 22,   //RUNNING/OFF
	HR_DSPL_CLIMATE_STATUS		= 23,	//climate control mode status	

 	HR_DSPL_CLND_STATE			= 24,		
	HR_DSPL_CLND_MODE			= 25,		
 	HR_DSPL_CLND_START_YEAR		= 26,
	HR_DSPL_CLND_START_MONTH	= 27,
 	HR_DSPL_CLND_START_DATE		= 28,
 	HR_DSPL_CLND_START_HOUR		= 29,
 	HR_DSPL_CLND_START_MIN		= 30,
	HR_DSPL_CLND_START_AMPM		= 31,

	HR_STANDBY_OVERRIDE_FLAG	= 32,
	HR_TEMP_DSPLY_STATE			= 33,

	HR_RELAY_RESET_MICRO        = 34,
    HR_RELAY_START_BOOT         = 35,

	HR_CAL_VREF					= 36,
	HR_CAL_TEMPERATURE			= 37,

	HR_RELAY_ENGINE_RPM			= 38,
	
	HR_RELAY_FMWR_REV			= 39,
	HR_DSPL_FMWR_REV			= 40,

	HR_PRODUCTION_TEST_MODE		= 41,	//inform DSPL if it in test mode

	HR_RTCC_SET_YR				= 42,	//production set RTCC
	HR_RTCC_SET_MTH				= 43,	//production set RTCC
	HR_RTCC_SET_DAY				= 44,	//production set RTCC
	HR_RTCC_SET_WKD				= 45,	//production set RTCC
	HR_RTCC_SET_HR				= 46,	//production set RTCC
	HR_RTCC_SET_MIN				= 47,	//production set RTCC
	HR_RTCC_SET_SEC				= 48,	//production set RTCC

	HR_HIGHAC_OVERRIDE_F		= 49,	//High AC pressure
	HR_LOWAC_OVERRIDE_F			= 50,	//Low AC pressure

	HR_DSPL_EXTERNAL_TEMP		= 51,	//J6_B10
    HR_RTC_EE_FLAG              = 52,   //read MCP79410 EEPROM address 0x00

	MAX_HOLDING_REG_PARAMETER_DISP

}mb_holding_reg_disp_t;	//mb_input_reg_disp_t;


#endif /* PARAMETERS_H_ */


