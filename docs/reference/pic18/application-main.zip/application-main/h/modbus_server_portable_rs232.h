/*
 * modbus_server_portable_rs232.h
 *
 */

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef MODBUS_PORTABLE_RS232_H_
#define MODBUS_PORTABLE_RS232_H_

#define configCPU_CLOCK_HZ 8000000
#define MODBUS_SERVER_TIMER_PRESCALER 8
#define MODBUS_SERVER_BAUD 19200			//19200
#define MODBUS_SERVER_SYSCLK configCPU_CLOCK_HZ
#define MODBUS_SERVER_HALF_CHAR_TIMER_VALUE (MODBUS_SERVER_SYSCLK / MODBUS_SERVER_TIMER_PRESCALER * 10 / 2 / MODBUS_SERVER_BAUD)
	
#define _mbm_disable_interrupts_rs232()	TXSTA1bits.TXEN = 0; PIE1bits.RC1IE = 0; PIE1bits.TMR2IE = 0;TXSTA2bits.TXEN = 0; PIE3bits.RC2IE = 0; PIE5bits.TMR4IE = 0	//pic18F
#define _mbm_enable_interrupts_rs232()	TXSTA1bits.TXEN = 1; PIE1bits.RC1IE = 1; PIE1bits.TMR2IE = 1;TXSTA2bits.TXEN = 1; PIE3bits.RC2IE = 1; PIE5bits.TMR4IE = 1    //pic18F	

#define MB_USE_HOLDING_REG
#define MB_USE_INPUT_REG  	//  Some code treats HRegs & IRegs as one "feature".

extern volatile MODBUS_SERVER_t	MB_SERVER_RS232;


typedef struct {
	uint16_t registerType;
	uint16_t registerNumber;
	uint16_t *data;

} MODBUS_SERVER_EVENT_t;

void MB_RS232_XmitFrame(MODBUS_SERVER_t * pThis);
void MB_RS232_ResetModbusTimer(MODBUS_SERVER_t * pThis);

void MB_RS232_TimerInit(int32_t baudRate);
void MB_RS232_UARTInit(int32_t baudRate);

void U2_Rx_IRQ_Handler(void);
void U2_Tx_IRQ_Handler(void);
void Tmr4_IRQ_Handler (void);

#endif /* MODBUS_PORTABLE_H_ */
