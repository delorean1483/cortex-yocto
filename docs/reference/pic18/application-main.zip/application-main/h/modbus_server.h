/*******************************************************************************
*	modbus_server.h
*	
*******************************************************************************/

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef MB_MODBUS_H
#define MB_MODBUS_H

#include <include_all.h>

#define MAX_FRAME_SIZE   64        	/* 256 Maximum Modbus frame size */
#define INIT_REMAINDER   0xFFFF     /* For CRC calculation - DON'T CHANGE */
#define FINAL_XOR        0x0000	    /* For CRC calculation - DON"T CHANGE */

/*************************************************
*   Modbus Protocol defines
*************************************************/
/*Frame Field Defines*/
#define MB_SLAVE_ADDR_FIELD		0x00
#define MB_FUNCTION_FIELD		0x01
#define MB_START_ADDR_HI		0x02
#define MB_START_ADDR_LOW		0x03
#define MB_QTY_HI				0x04
#define MB_QTY_LOW				0x05
#define MB_MESSAGE_HEADER_SIZE	0x06	// Added 04/18/2011 - RCB


/* MODBUS exception response enum defines */
typedef enum	{
	NO_ERROR				=	0,
	ILLEGAL_FUNCTION    	=   1, // Unsupported Modbus function
	ILLEGAL_DATA_ADDRESS	=   2, // Coil or register number out of range
	ILLEGAL_DATA_VALUE      =	3, // Data value out of range
	SLAVE_FAILURE           =	4, // Slave error during processing
	ACKNOWLEDGE             =	5, // Long duration process, acknowledged to prevent master timeout
	SLAVE_BUSY              = 	6, // Slave is busy on another process, reprocess command at a later time
	NEGATIVE_ACKNOWLEDGE    =	7, // For programming download only, not implemented
	MEMORY_PARITY_ERROR		=	8  // NOT IMPLEMENTED
} modbus_errors_t;

#define ERROR_RESPONSE          0x80 // MSB set to indicate error

// Supported Modbus function defines
#define READ_COILS				0x01
#define READ_DISCRETE_INPUTS	0x02
#define READ_HOLDING_REG        0x03
#define READ_INPUT_REG          0x04
#define WRITE_SINGLE_COIL		0x05
#define WRITE_SINGLE_REG		0x06
#define READ_EXCEPTION_STATUS   0x07
#define DIAGNOSTICS             0x08
#define GET_COMM_EVENT_COUNTER	0x0B
#define GET_COMM_EVENT_LOG		0x0C
#define WRITE_MULTIPLE_COILS	0x0F
#define WRITE_MULTIPLE_REGS		0x10
#define REPORT_SLAVE_ID			0x11

//Special CPI modbus function codes
#define MB_READ_FILE			0x42
#define MB_WRITE_FILE			0x41
#define READ_32BIT_FLOAT_REG    0x43
#define WRITE_32BIT_FLOAT_REG   0x44

#define WRITE_BULK_FILE_BROADCAST 0x45
#define WRITE_HOLDING_REG_BROADCAST 0x48

//Diagnostic sub-functions (Specified by MODBUS Spec)
#define RETURN_QUERY_DATA		0x00
#define RESTART_COMM_OPTIONS	0x01
#define RETURN_DIAGNOSTIC_REG	0x02
#define FORCE_LISTEN_MODE		0x04
#define CLEAR_COUNTERS			0x0A
#define RTRN_BUS_MESSAGE_CNT	0x0B
#define RTRN_BUS_COMM_ERR_CNT	0x0C
#define RTRN_BUS_EXCEPTN_CNT	0x0D
#define RTRN_SLAVE_MSG_CNT		0x0E
#define RTRN_SLAVE_NO_RESP_CNT	0x0F
#define RTRN_SLAVE_NAK_CNT		0x10
#define RTRN_SLAVE_BUSY_CNT		0x11
#define RTRN_BUS_OVRRUN_CNT		0x12
#define CLR_OVERRUN_CNT_FLAG	0x14

#define PRODUCTION_TEST_MOD		111

#define MB_NUM_OF_COUNTERS 9  
#define MB_FIRST_COUNTER_OFFSET 0x0B //this is used for indexing the counter array


#define INTER_CHAR_MAX_TMR 3



#define INTER_FRAME_MAX_TMR 7	

#define MAX_BLOCK 1

//This enum defines the Modbus states (these are defined in the MODBUS spec)
typedef enum
{
	MB_IDLE,
	MB_INITIAL_STATE,
	MB_RECEPTION,
	MB_CNTRL_WAITING,
	MB_WAITING_TO_SEND
} mb_states;

//This enum holds status info on MODBUS frames
typedef enum
{
	MB_NEEDS_CHECKING = 0,
	MB_OK = 1,
	MB_NOK = 2
} mb_frame_states;

typedef struct {

	uint8_t uartId;

	uint16_t inter_char_timeout;
	uint16_t inter_frame_timeout;

	unsigned char sending_response;
	unsigned char last_byte;

	volatile unsigned char	modbus_timer;
	
	BYTE data[MAX_FRAME_SIZE];

	volatile BYTE rx_index;
    volatile BYTE tx_size;

    //frame state
    volatile mb_frame_states mb_frame_status;

    volatile mb_states mb_state;

    UINT16 mb_event_counter;
    UINT16 mb_status_word;
    BYTE mb_my_address;

    BYTE mb_inter_char_tmr;
    BYTE mb_inter_frame_tmr;

    BYTE mb_processing_pending;

    UINT16 mb_counter[MB_NUM_OF_COUNTERS];

} MODBUS_SERVER_t;


//Function prototypes for the modbus for the display
void MB_Display_InitializeModbus(MODBUS_SERVER_t * pThis, BYTE);
void MB_Display_ProcessModbus(MODBUS_SERVER_t * pThis);
void MB_Display_CharacterReceived(MODBUS_SERVER_t * pThis, BYTE, BYTE); 
void MB_Display_ServiceModbusTimers(MODBUS_SERVER_t * pThis);

void MB_Display_StartTimers(MODBUS_SERVER_t * pThis);
BYTE MB_Display_ProcessFrame(MODBUS_SERVER_t * pThis);
BYTE MB_Display_CheckFrame(MODBUS_SERVER_t * pThis);
UINT16 MB_Display_GetCRC(MODBUS_SERVER_t * pThis, BYTE *buffer, BYTE buffer_size);
void MB_Display_StopModbusTimer(MODBUS_SERVER_t * pThis);
void MB_Display_StopInterFrameTimer(MODBUS_SERVER_t * pThis);
void MB_Display_StopInterCharTimer(MODBUS_SERVER_t * pThis);
void MB_Display_ResetCounters(MODBUS_SERVER_t * pThis);


modbus_errors_t MB_disp_value_boundary_check_error(int16_t value, uint16_t regNumber);
modbus_errors_t MB_Display_HoldingReg(MODBUS_SERVER_t * pThis, uint16_t regNumber, int16_t * data, uint8_t write);

uint16_t  get_temperature_adc(void);
uint16_t  get_loadcell_offset_voltage(void);





#endif
