/**
 *  file: eeprom.h
 **/

/******************************************************************************
*******************************************************************************
 
* Copeland Corporation LLC
* COPYRIGHT (C) ALL RIGHTS RESERVED.
*******************************************************************************
* The reproduction, transmission or use of this
* document or its contents is not permitted without
* express written authority. Offenders will be liable
* for damages. All rights, including rights created
* by patent grant or registration of a utility model
* or design, are reserved.

******************************************************************************
*******************************************************************************/

#ifndef EEPROM_H
#define EEPROM_H

/*EE address assignment*/

#define EE_VREF_CALIBRATION	0  //word
#define EE_TEMP_CALIBRATION	2	//word

#define MACHINE_RUNTIME_START   10
#define MACHINE_RUNTIME_END  	11   //2 Bytes used
#define ENGINE_RUNTIME_START	12	
#define ENGINE_RUNTIME_END		13	//2 bytes used
#define ENGINE_OILTIME_START	14	
#define ENGINE_OILTIME_END		15	//2 bytes used

#define EE_CLIMATE_TEMP_SETTING		20	//word
#define EE_MONITOR_BATT_SETTING		22
#define EE_STORAGE_TEMP_SETTING		24
#define EE_STORAGE_BATT_SETTING		26

#define EE_EVAP_FAN_SPEED	30  //byte
#define EE_TEMP_UNIT		31  //byte


#define EEPROM_WRITTEN_FLAG		40

#define EE_CLND_START_ONOFF		50 	//on/off
#define EE_CLND_START_MODE		51	//climate/battery/storage
#define EE_CLND_START_YEAR		52	//BCD value
#define EE_CLND_START_MONTH		53	//BCD
#define EE_CLND_START_DATE		54	//BCD
#define EE_CLND_START_HOUR		55	//BCD
#define EE_CLND_START_MIN		56	//BCD	
#define EE_CLND_START_AMPM		57	

#define EE_BOOTLOADER_FLAG		200

/*function prototype*/

int read_eeprom_word(unsigned int address);
void write_eeprom_word(unsigned int address, int data);

unsigned char read_eeprom_byte(unsigned int address);
void write_eeprom_byte(unsigned int address, char data);


#endif 
